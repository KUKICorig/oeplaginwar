# RawWar — серверный плагин для Mindustry (v8, Build 160.7)

Командное PvP: две команды (Alpha/Bravo), классы юнитов из JSON, точки высадки,
меню выбора, сменные режимы (встроенный Team Deathmatch + внешние jar), сохранение данных.

## Сборка

Собирается Gradle'ом **против jar-файла вашего сервера** — никаких jitpack/Zelaux/Maven
Central, сборка полностью офлайн.

### 1. Файл сервера в `libs/`

```
libs/server-release.jar        # или Mindustry.jar — тот файл, которым запускаете сервер
```

Скачать нужный билд тем же собирщиком:

```bash
./gradlew fetchServerJar -PmindustryBuild=160.7
```

Подробности (что именно собирщик читает из этого jar) — в [libs/README.md](libs/README.md).

### 2. Сборка

```bash
./gradlew build        # проверка libs/ → компиляция → jar → проверка jar
./gradlew jar          # только jar
```

На выходе: **`build/libs/RawWar.jar`** — кладём в `config/mods/` сервера.

В начале сборки печатается, против чего компилируем:

```
 Файл сервера   libs/:  server-release.jar
 Mindustry      v8 build 160.7   -> minGameVersion=160
 Байткод        Java 17
 Запуск         server-release.jar
```

Если `libs/` пустой или там не Mindustry — сборка останавливается с внятным сообщением,
а не странными `cannot find symbol`.

### 3. Быстрая проверка на реальном сервере

```bash
./gradlew runServer                                     # сервер из libs/ + плагин в server/config/mods/
./gradlew runServer -PserverArgs="host adversary pvp"   # со своими аргументами сервера
```

`runServer` сам собирает jar, кладёт его в `server/config/mods/` и поднимает сервер из
`libs/`; рабочая папка — `server/` (удалить: `./gradlew cleanRun`). В консоли сервера
работают команды плагина: `rw mode list`, `rw reload`, `rw spawn list …`; выход — `exit`
или Ctrl-C. Если у вас уже есть свой сервер — просто скопируйте в него
`build/libs/RawWar.jar`.

### Задачи

| команда                | что делает                                                       |
|------------------------|------------------------------------------------------------------|
| `build`                | всё: проверка libs/ → компиляция → jar → проверка jar            |
| `jar`                  | только `build/libs/RawWar.jar`                                   |
| `checkServerJar`       | что за сервер в `libs/`: билд, байткод, можно ли запускать       |
| `verifyJar`            | в jar есть `plugin.json` в корне, класс `main`, нет классов игры |
| `deploy`               | копировать плагин в `server/config/mods/`                        |
| `runServer`            | собрать, задеплоить и поднять тестовый сервер                    |
| `fetchServerJar`       | скачать `server-release.jar` в `libs/` (опционально)             |
| `cleanRun`             | снести песочницу `server/`                                       |

### Настройки — `gradle.properties` (или `-Pимя=значение`)

| ключ             | по умолчанию | зачем                                                          |
|------------------|--------------|----------------------------------------------------------------|
| `pluginVersion`  | `1.0.0`      | версия в `plugin.json` (и в имени jar при `versionedJar=true`) |
| `serverJarDir`   | `libs`       | где лежит файл сервера                                          |
| `serverJarName`  | (авто)       | какой jar считать сервером, если их несколько                  |
| `minGameVersion` | (авто)       | вручную перебить `minGameVersion`, вычисленный из файла сервера |
| `javaRelease`    | (авто)       | вручную перебить `--release` для `javac`                       |
| `versionedJar`   | `false`      | `RawWar-1.0.0.jar` вместо `RawWar.jar`                          |
| `serverRunDir`   | `server`     | песочница для `runServer`/`deploy`                             |
| `serverArgs`     | (пусто)      | аргументы серверу (= команды его консоли)                       |
| `mindustryBuild` | `160.7`      | что качает `fetchServerJar`                                    |

### Требования

* JDK **17+** (Mindustry v8 — Java 17; версия байткода файла сервера проверяется при сборке).
* Gradle ставить не нужно — в репозитории wrapper (`./gradlew …`, на Windows — `gradlew.bat …`); он затягивает Gradle 9.9.1, но скрипт совместим и с Gradle 8.5+, если запускать установленным `gradle`.
* CI: [.github/workflows/build.yml](.github/workflows/build.yml) — собирает jar на push/PR;
  файл сервера скачивается тем же `fetchServerJar`, поэтому в репозитории его нет.
* Публичный релиз: Mindustry ищет jar в релизах и ориентируется на тег версии в названии,
  например **`RawWar [v160]`**.

### Структура

```
build.gradle              собирщик (Gradle, groovy DSL)
gradle.properties         все переключатели сборки
gradlew, gradlew.bat      wrapper (Gradle 9.9.1; хватит и установленного Gradle 8.5+)
plugin.json               metadata мода; version/minGameVersion дописываются при сборке
libs/                     ← ФАЙЛ СЕРВЕРА (jar в .gitignore, README.md — в репозитории)
src/main/java/rawwar/     исходники
src/main/resources/       бандлы/спрайты мода (если появятся)
server/                   песочница runServer (в .gitignore)
```

### Что изменилось по сравнению со старым `build.gradle`

* зависимости Mindustry/Arc с jitpack+Zelaux → `compileOnly` на jar из `libs/`; сборка не требует сети;
* добавлена `options.encoding = 'UTF-8'` — раньше кириллица в исходниках ломала компиляцию
  (`error: unmappable character for encoding US-ASCII`);
* версия байткода и `minGameVersion` берутся из файла сервера, а не из `mindustryVersion=v146`;
* `plugin.json` больше не дублируется (был и в корне, и в ресурсах → два одинаковых entry в jar);
* jar воспроизводим (одинаковые входы → одинаковые байты) и проверяется задачей `verifyJar`;
* добавлены `runServer`/`deploy`/`fetchServerJar`/`checkServerJar` с внятными ошибками.

В исходниках подчищены четыре расхождения API под Build 160.7 (см. «Известные ограничения»).

## Первый запуск

- Создаётся каталог `config/rawwar/` (config, players, units, modes, statistics, backups).
- Впишите свой UUID в `config/rawwar/config/settings.json` → `ownerUuid` и выполните `rw reload` в консоли.
- Встаньте в нужное место и выполните `/rw spawn set alpha` и `/rw spawn set bravo`.
- `/rw mode start` (консоль: `rw mode start`).

## Команды

Игроки: `/rw`, `/rw unit`, `/rw stats`, `/rw info`, `/rw team [switch]`, `/rw help`  (алиасы `/war`, `/rwar`)
Админы: `/rw team set <игрок> <alpha|bravo>`, `/rw team balance`, `/rw spawn set|list|remove <команда>`,
`/rw mode list|select <id>|start|stop`, `/rw reload`
Создатель: `/rw owner reload|debug|data|modes|units|admin add|remove <игрок>`

## Свои режимы

Папка `config/rawwar/modes/<Имя>/` с `mode.json`:
`{"id":"Elimination","main":"my.pkg.Elimination","jar":"Elimination.jar"}`
Класс реализует `rawwar.modes.GameMode` (RawWar.jar — зависимость compileOnly). Режим может
добавлять кнопки в меню (`core.menus.addMainEntry`), разрешать строительство (`allowBuilding`),
ограничивать юниты (`allowUnit`) и завершать матч (`core.modes.endMatch`).

## Юниты

`units/combat|builder/*.json` (формат из ТЗ; допустимо `canBuild`). Баланс — только через JSON.
Здоровье применяется точно; скорость/урон — приближённо (опция `units.statusMultipliers`),
т.к. в Mindustry постоянные множители задаются статус-эффектами.

## Известные ограничения

- Код под Build 160.7 требует четырёх правок API — они внесены, иначе сборка не проходит:
  `Unit.isNull()` → `dead()`/`isAdded()` (`TeamManager`, `UnitManager`);
  `Vars.netServer.assignTeam = …` → `Vars.netServer.assigner = …`
  (`mindustry.core.NetServer.TeamAssigner#assign(Player, Iterable<Player>)`);
  `Groups.build.findAll(…)` → `Groups.build.each(фильтр, …)` со сбором в список
  (`GameEventListener.applyRules`, заодно removes не ломает обход `Groups.build`).
  Дальнейшие расхождения теперь видны как обычные ошибки компиляции, а не как падения
  мода на сервере.
- Строительство блокируется action-фильтром (`placeBlock/breakBlock`), если не разрешено режимом.
- Режим `removeCores` может завершить игру встроенной проверкой победы; по умолчанию выключен —
  стандартные юниты ядра заменяются выбранным классом.
## Про `RawWar.zip`

Исходники лежат в дереве репозитория (`src/`), поэтому архив `RawWar.zip` из первого коммита
из дерева убран: он содержит устаревшие `build.gradle`/`gradle.properties` с jitpack-зависимостями.
Вернуть, если нужен: `git checkout HEAD -- RawWar.zip`.

## Сборка без Gradle
Нужен только JDK 17+ и рабочий `libs/server-release.jar`:

```
./compile.sh                 # Linux/macOS
compile.bat                  # Windows
./compile.sh путь/к/server-release.jar
```
Результат: `build/libs/RawWar.jar`. Пустые файлы-заглушки в `libs/` (0 байт) игнорируются.
