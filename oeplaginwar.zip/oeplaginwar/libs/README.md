# libs/ — файл сервера Mindustry

Собирщик компилирует плагин **против jar-файла сервера, который лежит здесь**.
Никаких jitpack / Zelaux / Maven Central для сборки не нужно — она работает офлайн.

## Что положить

| файл                       | что это                                                                      |
|----------------------------|------------------------------------------------------------------------------|
| `server-release.jar`       | headless-сервер Mindustry v8 из релиза Anuken/Mindustry — **нужен этот**      |
| `Mindustry.jar`            | полный клиент+сервер: API подходит, но `runServer` с ним не стартует         |
| `dependencies.jar`, `assets.jar` | к компиляции отношения не имеют, в `libs/` их класть не надо           |

Можно взять jar прямо с вашего сервера — тот самый файл, которым вы его запускаете
(`java -jar server.jar`). Имя не важно: собирщик сам найдёт jar, в котором есть
`version.properties` + `mindustry/mod/Plugin.class`. Если в папке несколько подходящих
jar — укажите основной:

```properties
# gradle.properties
serverJarName=server-release.jar
```

Если своего файла нет под рукой:

```bash
./gradlew fetchServerJar -PmindustryBuild=160.7
```

(или вручную: `https://github.com/Anuken/Mindustry/releases/download/v160.7/server-release.jar`)

## Что собирщик вытаскивает из файла сервера

| откуда                          | что делает                                                                 |
|---------------------------------|----------------------------------------------------------------------------|
| `version.properties` → `build`  | `minGameVersion` в `plugin.json` при сборке (160.7 → 160)                  |
| `mindustry/mod/Plugin.class`    | версия байткода → `--release` для `javac` (у v8 это Java 17)                |
| `MANIFEST.MF` → `Main-Class`    | можно ли этим jar'ом поднять сервер (`runServer`)                          |

Проверить, что именно нашлось:

```bash
./gradlew checkServerJar
```

```
----------------------------------------------------------------------
 Файл сервера   libs/:  server-release.jar
 Mindustry      v8 build 160.7   -> minGameVersion=160
 Байткод        Java 17
 Запуск         server-release.jar
----------------------------------------------------------------------
```

## Почему jar не в git

19 МБ бинарника в истории репозитория не нужны, плюс он является файлом другой
игры. `.gitignore` исключает `libs/*.jar`; если вам принципиально, чтобы репозиторий
собирался вообще без лишних движений — закоммитьте force-add'ом:

```bash
git add -f libs/server-release.jar
```
