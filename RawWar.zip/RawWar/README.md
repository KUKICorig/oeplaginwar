# RawWar — серверный плагин для Mindustry (v8, Build 160.7)

Командное PvP: две команды (Alpha/Bravo), классы юнитов из JSON, точки высадки,
меню выбора, сменные режимы (встроенный Team Deathmatch + внешние jar), сохранение данных.

## Сборка
1. В `gradle.properties` укажите `mindustryVersion` (тег jitpack под вашу сборку Mindustry/Arc).
2. `gradle jar` → `build/libs/RawWar.jar`.
3. Положите jar в `config/mods/` сервера.

## Первый запуск
- Создаётся каталог `config/rawwar/` (config, players, units, modes, statistics, backups).
- Впишите свой UUID в `config/rawwar/config/settings.json` → `ownerUuid` и выполните `rw reload` в консоли.
- Встаньте в нужное место и выполните `/rw spawn set alpha` и `/rw spawn set bravo`.
- `/rw mode start` (консоль: `rw mode start`).

## Команды
Игроки: `/rw`, `/rw unit`, `/rw stats`, `/rw info`, `/rw team [switch]`, `/rw help`  (алиасы `/war`, `/rwar`)
Админы: `/rw team set <игрок> <alpha|bravo>`, `/rw team balance`, `/rw spawn set|list|remove <команда>`,
`/rw mode list|select <id>|start|stop`, `/rw reload`
Создатель: `/rw owner reload|debug|data|modes|units|admin add|remove <игрок>`

## Свои режимы
Папка `config/rawwar/modes/<Имя>/` с `mode.json`:
`{"id":"Elimination","main":"my.pkg.Elimination","jar":"Elimination.jar"}`
Класс реализует `rawwar.modes.GameMode` (RawWar.jar — зависимость compileOnly). Режим может
добавлять кнопки в меню (`core.menus.addMainEntry`), разрешать строительство (`allowBuilding`),
ограничивать юниты (`allowUnit`) и завершать матч (`core.modes.endMatch`).

## Юниты
`units/combat|builder/*.json` (формат из ТЗ; допустимо `canBuild`). Баланс — только через JSON.
Здоровье применяется точно; скорость/урон — приближённо (опция `units.statusMultipliers`),
т.к. в Mindustry постоянные множители задаются статус-эффектами.

## Известные ограничения
- Код написан по API Mindustry v7/v8 без возможности скомпилировать в среде, где он создавался:
  при сборке возможны мелкие несовпадения имён API под Build 160.7 — исправляются точечно.
- Строительство блокируется action-фильтром (`placeBlock/breakBlock`), если не разрешено режимом.
- Режим `removeCores` может завершить игру встроенной проверкой победы; по умолчанию выключен —
  стандартные юниты ядра заменяются выбранным классом.
