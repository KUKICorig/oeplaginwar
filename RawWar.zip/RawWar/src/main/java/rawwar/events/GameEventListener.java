package rawwar.events;

import arc.util.Log;
import arc.util.Timer;
import mindustry.Vars;
import mindustry.game.EventType;
import mindustry.gen.Groups;
import mindustry.gen.Player;
import mindustry.gen.Unit;
import mindustry.net.Administration;
import rawwar.core.CoreManager;
import rawwar.data.PlayerData;
import rawwar.teams.RwTeam;

/** Event System: преобразует события Mindustry в вызовы подсистем RawWar. */
public class GameEventListener {
    private final CoreManager core;
    private boolean filterInstalled;

    public GameEventListener(CoreManager core) { this.core = core; }

    public void register() {
        core.events.on(EventType.PlayerJoin.class, e -> onJoin(e.player));
        core.events.on(EventType.PlayerLeave.class, e -> onLeave(e.player));
        core.events.on(EventType.UnitDestroyEvent.class, e -> onUnitDestroyed(e.unit));
        core.events.on(EventType.UnitBulletDestroyEvent.class, e -> onUnitKilledByBullet(e.unit, e.bullet == null ? null : e.bullet.owner));
        core.events.on(EventType.WorldLoadEvent.class, e -> Timer.schedule(this::applyRules, 1f));

        // Серверные команды: клиент не может самостоятельно назначить себе юнит/команду
        if (!filterInstalled) {
            filterInstalled = true;
            Vars.netServer.admins.addActionFilter(action -> {
                if (!core.config.settings.plugin.enabled) return true;
                if (action.type == Administration.ActionType.placeBlock || action.type == Administration.ActionType.breakBlock) {
                    return action.player == null || core.modes.allowBuilding(action.player);
                }
                return true;
            });
        }
        // Распределение новых игроков по командам
        Vars.netServer.assignTeam = (player, players) -> {
            RwTeam t = core.teams.assign(player);
            return t.team;
        };
        applyRules();
    }

    /** Применение игровых ограничений (рассчитано на централизованное переопределение режимами). */
    public void applyRules() {
        try {
            Vars.state.rules.pvp = true;
            Vars.state.rules.attackMode = false;
            if (core.config.settings.removeCores) {
                for (mindustry.world.blocks.storage.CoreBlock.CoreBuild c : new java.util.ArrayList<>(Groups.build.<mindustry.world.blocks.storage.CoreBlock.CoreBuild>findAll(b -> b instanceof mindustry.world.blocks.storage.CoreBlock.CoreBuild))) {
                    c.tile.setNet(mindustry.content.Blocks.air);
                }
            }
        } catch (Throwable t) {
            Log.err("[RawWar] applyRules: " + t);
        }
    }

    private void onJoin(Player p) {
        core.teams.assign(p);
        PlayerData d = core.data.get(p.uuid(), p.plainName());
        core.data.markDirty(p.uuid());
        if (core.config.settings.units.enabled && core.config.settings.units.selectionRequired) {
            Timer.schedule(() -> { if (p.con != null && p.con.isConnected()) core.menus.open(p); }, 1.5f);
        }
        core.modes.playerJoin(p);
    }

    private void onLeave(Player p) {
        core.menus.close(p);
        core.units.release(p);
        core.teams.remove(p);
        core.data.unloadPlayer(p.uuid());
    }

    private void onUnitDestroyed(Unit u) {
        if (core.units.consumeIgnored(u)) return;
        Player p = u.getPlayer();
        if (p == null) return;
        if (!core.units.isOwnUnit(p, u)) return;
        core.units.release(p);
        PlayerData d = core.data.get(p.uuid(), p.plainName());
        d.deaths++;
        core.data.markDirty(p.uuid());
        core.modes.playerDeath(p);
        if (core.config.settings.units.selectionRequired) {
            Timer.schedule(() -> { if (p.con != null && p.con.isConnected()) core.menus.open(p); }, 2f);
        }
    }

    private void onUnitKilledByBullet(Unit victim, Object owner) {
        if (!(owner instanceof Unit)) return;
        Player killer = ((Unit) owner).getPlayer();
        Player vp = victim.getPlayer();
        if (killer == null || vp == null || killer == vp) return;
        RwTeam kt = core.teams.of(killer), vt = core.teams.of(vp);
        if (kt == null || vt == null || kt == vt) return;
        PlayerData d = core.data.get(killer.uuid(), killer.plainName());
        d.kills++;
        core.data.markDirty(killer.uuid());
        core.modes.kill(killer, vp);
    }
}
