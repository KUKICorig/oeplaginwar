package rawwar.config;

/** Структура settings.json. */
public class Settings {
    public static class PluginCfg { public String name = "RawWar"; public String version = "1.0.0"; public boolean enabled = true; }
    public static class TeamsCfg {
        public boolean enabled = true;
        public int maxPlayersPerTeam = 20;
        public boolean autoBalance = true;
        public boolean allowTeamSwitch = false;
        public String alphaName = "Alpha", bravoName = "Bravo";
        public String alphaTeam = "sharded", bravoTeam = "crux";
    }
    public static class UnitsCfg { public boolean enabled = true; public boolean selectionRequired = true; public boolean allowChangeUnit = true; public boolean statusMultipliers = false; }
    public static class SpawnCfg { public boolean enabled = true; public boolean randomSpawn = false; public int searchRadius = 6; }
    public static class BuildingCfg { public boolean enabled = false; }

    public PluginCfg plugin = new PluginCfg();
    public TeamsCfg teams = new TeamsCfg();
    public UnitsCfg units = new UnitsCfg();
    public SpawnCfg spawn = new SpawnCfg();
    public BuildingCfg building = new BuildingCfg();

    /** UUID создателя плагина (даёт доступ к /rw owner ...). */
    public String ownerUuid = "";
    public String activeMode = "TeamDeathmatch";
    public boolean autoStartMode = false;
    public boolean removeCores = false;
    public int dataSaveIntervalSeconds = 120;
    public boolean debug = false;
}
