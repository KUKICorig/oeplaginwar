package rawwar.config;

import rawwar.core.CoreManager;
import rawwar.data.JsonIO;

/** Configuration System. */
public class ConfigManager {
    private final CoreManager core;
    public Settings settings = new Settings();

    public ConfigManager(CoreManager core) { this.core = core; }

    public void load() {
        settings = JsonIO.read(core.root.child("config").child("settings.json"), Settings.class, Settings::new);
    }

    public void save() { JsonIO.write(core.root.child("config").child("settings.json"), settings); }
}
