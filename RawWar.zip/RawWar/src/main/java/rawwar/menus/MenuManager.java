package rawwar.menus;

import arc.func.Cons;
import mindustry.gen.Call;
import mindustry.gen.Player;
import mindustry.ui.Menus;
import rawwar.core.CoreManager;
import rawwar.data.PlayerData;
import rawwar.teams.RwTeam;
import rawwar.units.UnitClass;
import rawwar.units.UnitConfig;

import java.util.*;

/** Menu System: многоуровневое меню выбора юнита. Состояние хранится на сервере. */
public class MenuManager {
    private enum Stage { MAIN, CLASSES, UNITS, INFO, STATS, INFOTEXT }

    private static class State {
        Stage stage = Stage.MAIN;
        String type, cls, unitId;
        List<Runnable> actions = new ArrayList<>();
    }

    /** Пункты главного меню, добавленные режимами. */
    private static class Extra { String label; Cons<Player> action; }

    private final CoreManager core;
    private final Map<String, State> states = new HashMap<>();
    private final List<Extra> extras = new ArrayList<>();
    private int menuId = -1;

    public MenuManager(CoreManager core) { this.core = core; }

    public void load() {
        if (menuId == -1) menuId = Menus.registerMenu(this::onChoice);
    }

    /** Позволяет режимам добавлять собственные кнопки в главное меню. */
    public void addMainEntry(String label, Cons<Player> action) {
        Extra e = new Extra();
        e.label = label;
        e.action = action;
        extras.add(e);
    }

    public void clearExtras() { extras.clear(); }

    public void open(Player p) {
        State s = new State();
        states.put(p.uuid(), s);
        show(p, s);
    }

    public void close(Player p) {
        states.remove(p.uuid());
        Call.hideFollowUpMenu(p.con, menuId);
    }

    private void onChoice(Player p, int option) {
        State s = states.get(p.uuid());
        if (s == null || option < 0 || option >= s.actions.size()) { return; } // закрыто игроком
        s.actions.get(option).run();
    }

    private void show(Player p, State s) {
        s.actions = new ArrayList<>();
        List<String[]> rows = new ArrayList<>();
        String title, text;
        RwTeam team = core.teams.of(p);

        switch (s.stage) {
            case CLASSES: {
                title = s.type.equals("combat") ? "БОЕВЫЕ ЮНИТЫ" : "СТРОИТЕЛЬНЫЕ ЮНИТЫ";
                text = "Выберите класс:";
                for (String cls : core.units.classesOf(s.type)) {
                    row(rows, s, UnitClass.title(cls), () -> { s.cls = cls; s.stage = Stage.UNITS; show(p, s); });
                }
                row(rows, s, "Назад", () -> { s.stage = Stage.MAIN; show(p, s); });
                break;
            }
            case UNITS: {
                title = UnitClass.title(s.cls).toUpperCase();
                text = "Доступные юниты:";
                for (UnitConfig c : core.units.byClass(s.type, s.cls)) {
                    int free = core.units.freeSlots(c, team);
                    String label = c.name + (free < 0 ? "" : "  [" + free + "]");
                    row(rows, s, label, () -> { s.unitId = c.id; s.stage = Stage.INFO; show(p, s); });
                }
                row(rows, s, "Назад", () -> { s.stage = Stage.CLASSES; show(p, s); });
                break;
            }
            case INFO: {
                UnitConfig c = core.units.get(s.unitId);
                title = c.name.toUpperCase();
                int free = core.units.freeSlots(c, team);
                text = c.description + "\n\n"
                        + "Тип: " + (c.isBuilder() ? "Строительный" : "Боевой") + "\n"
                        + "Класс: " + UnitClass.title(c.unitClass) + "\n"
                        + "Здоровье: " + pct(c.healthMultiplier) + "\n"
                        + "Скорость: " + pct(c.speedMultiplier) + "\n"
                        + "Урон: " + pct(c.damageMultiplier) + "\n"
                        + (c.canBuild ? "Может строить: да\n" : "")
                        + "\nСвободных мест: " + (free < 0 ? "без ограничений" : String.valueOf(free));
                row(rows, s, "Выбрать", () -> {
                    String err = core.units.give(p, c);
                    if (err != null) { p.sendMessage("[scarlet]" + err); show(p, s); }
                    else { states.remove(p.uuid()); p.sendMessage("[lime]Вы выбрали: [white]" + c.name); }
                });
                row(rows, s, "Назад", () -> { s.stage = Stage.UNITS; show(p, s); });
                break;
            }
            case STATS: {
                PlayerData d = core.data.get(p.uuid(), p.plainName());
                title = "СТАТИСТИКА";
                text = "Убийств: " + d.kills + "\nСмертей: " + d.deaths + "\nПобед: " + d.wins + "\nПоражений: " + d.losses
                        + "\nМатчей: " + d.matches + "\nРейтинг: " + d.rating;
                row(rows, s, "Назад", () -> { s.stage = Stage.MAIN; show(p, s); });
                break;
            }
            case INFOTEXT: {
                title = "ИНФОРМАЦИЯ";
                text = core.modes.describe();
                row(rows, s, "Назад", () -> { s.stage = Stage.MAIN; show(p, s); });
                break;
            }
            default: {
                title = "RAW WAR";
                text = "Выбор игрового класса" + (team != null ? "\nВаша команда: " + team.name : "");
                row(rows, s, "Боевые юниты", () -> { s.type = "combat"; s.stage = Stage.CLASSES; show(p, s); });
                row(rows, s, "Строительные юниты", () -> { s.type = "builder"; s.stage = Stage.CLASSES; show(p, s); });
                row(rows, s, "Информация", () -> { s.stage = Stage.INFOTEXT; show(p, s); });
                row(rows, s, "Статистика", () -> { s.stage = Stage.STATS; show(p, s); });
                for (Extra e : extras) row(rows, s, e.label, () -> { states.remove(p.uuid()); e.action.get(p); });
                break;
            }
        }
        Call.menu(p.con, menuId, title, text, rows.toArray(new String[0][]));
    }

    private void row(List<String[]> rows, State s, String label, Runnable action) {
        rows.add(new String[]{label});
        s.actions.add(action);
    }

    private static String pct(float m) { return Math.round(m * 100) + "%"; }
}
