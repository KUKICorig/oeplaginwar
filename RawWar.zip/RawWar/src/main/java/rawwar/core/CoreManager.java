package rawwar.core;

import arc.files.Fi;
import arc.util.Log;
import mindustry.Vars;
import rawwar.commands.CommandManager;
import rawwar.config.ConfigManager;
import rawwar.data.DataManager;
import rawwar.events.GameEventListener;
import rawwar.menus.MenuManager;
import rawwar.modes.ModeManager;
import rawwar.spawn.SpawnManager;
import rawwar.teams.TeamManager;
import rawwar.units.UnitManager;

/** Core System: создаёт подсистемы и управляет их жизненным циклом. */
public class CoreManager {
    public Fi root;
    public final SystemManager systems = new SystemManager();
    public final EventManager events = new EventManager();

    public ConfigManager config;
    public DataManager data;
    public TeamManager teams;
    public UnitManager units;
    public SpawnManager spawns;
    public MenuManager menus;
    public ModeManager modes;
    public CommandManager commands;
    public GameEventListener listener;

    public void start() {
        root = Vars.dataDirectory.child("rawwar");
        root.mkdirs();
        for (String d : new String[]{"config", "players", "units", "modes", "statistics", "logs", "backups"}) root.child(d).mkdirs();

        config = new ConfigManager(this);
        data = new DataManager(this);
        teams = new TeamManager(this);
        units = new UnitManager(this);
        spawns = new SpawnManager(this);
        menus = new MenuManager(this);
        modes = new ModeManager(this);
        commands = new CommandManager(this);
        listener = new GameEventListener(this);

        systems.add("Configuration", config::load, null);
        systems.add("Data", data::load, data::stop);
        systems.add("Teams", teams::load, null);
        systems.add("Units", units::load, units::clearAll);
        systems.add("Spawns", spawns::load, null);
        systems.add("Menus", menus::load, null);
        systems.add("Modes", modes::load, modes::stopAll);
        systems.add("Events", listener::register, events::clear);
        systems.startAll();

        if (!config.settings.plugin.enabled) { Log.warn("[RawWar] Плагин выключен в settings.json"); events.clear(); return; }
        Log.info("[RawWar] Запущен. Версия " + config.settings.plugin.version);
    }

    /** Перезагрузка конфигураций, юнитов, точек и режимов без перезапуска сервера. */
    public void reload() {
        data.saveAll();
        data.backup();
        config.load();
        data.load();
        teams.load();
        units.load();
        spawns.load();
        modes.load();
        listener.applyRules();
        Log.info("[RawWar] Конфигурация перезагружена");
    }

    public void stop() { systems.stopAll(); }

    // ---------- права ----------
    public boolean isOwner(mindustry.gen.Player p) {
        String o = config.settings.ownerUuid;
        return o != null && !o.isEmpty() && o.equals(p.uuid());
    }

    public boolean isAdmin(mindustry.gen.Player p) {
        return p.admin || isOwner(p) || data.server.admins.contains(p.uuid());
    }
}
