package rawwar;

import arc.util.CommandHandler;
import arc.util.Log;
import mindustry.gen.Player;
import mindustry.mod.Plugin;
import rawwar.core.CoreManager;

/** Точка входа плагина RawWar. */
public class RawWarPlugin extends Plugin {
    private CoreManager core;

    @Override
    public void init() {
        core = new CoreManager();
        try {
            core.start();
        } catch (Throwable t) {
            Log.err("[RawWar] Не удалось запустить плагин", t);
        }
    }

    @Override
    public void registerServerCommands(CommandHandler handler) {
        handler.register("rw", "[sub] [a] [b] [c]", "RawWar: консольное управление", args -> {
            if (core != null) core.commands.handleConsole(args);
        });
    }

    @Override
    public void registerClientCommands(CommandHandler handler) {
        for (String name : new String[]{"rw", "war", "rwar"}) {
            handler.<Player>register(name, "[sub] [a] [b] [c]", "RawWar: главное меню и команды", (args, player) -> {
                if (core != null) core.commands.handle(player, args);
            });
        }
    }
}
