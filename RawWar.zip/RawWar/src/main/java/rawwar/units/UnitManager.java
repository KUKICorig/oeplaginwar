package rawwar.units;

import arc.files.Fi;
import arc.util.Log;
import arc.util.serialization.JsonReader;
import arc.util.serialization.JsonValue;
import mindustry.Vars;
import mindustry.content.StatusEffects;
import mindustry.gen.Player;
import mindustry.gen.Unit;
import mindustry.type.UnitType;
import rawwar.core.CoreManager;
import rawwar.data.PlayerData;
import rawwar.teams.RwTeam;

import java.util.*;

/** Unit System: реестр юнитов, лимиты, выдача юнитов игрокам. */
public class UnitManager {
    private final CoreManager core;
    private final Map<String, UnitConfig> configs = new LinkedHashMap<>();
    /** uuid -> id выбранного юнита */
    private final Map<String, String> selected = new HashMap<>();
    /** uuid -> id сущности юнита, выданного плагином */
    private final Map<String, Integer> activeUnit = new HashMap<>();
    private final Set<Integer> ignoredDeaths = new HashSet<>();

    public UnitManager(CoreManager core) { this.core = core; }

    // ---------- загрузка ----------
    public void load() {
        configs.clear();
        Fi combat = core.root.child("units").child("combat");
        Fi builder = core.root.child("units").child("builder");
        if (!combat.exists() && !builder.exists()) writeDefaults(combat, builder);
        for (Fi dir : new Fi[]{combat, builder}) {
            if (!dir.exists()) continue;
            for (Fi f : dir.findAll(x -> x.extension().equalsIgnoreCase("json"))) {
                try {
                    UnitConfig c = UnitConfig.parse(new JsonReader().parse(f));
                    if (c.id == null) throw new IllegalStateException("нет id");
                    if (Vars.content.unit(c.unit) == null) { Log.warn("[RawWar] " + f.name() + ": неизвестный юнит '" + c.unit + "'"); continue; }
                    configs.put(c.id, c);
                } catch (Throwable t) {
                    Log.err("[RawWar] Ошибка в " + f.path() + ": " + t);
                }
            }
        }
        Log.info("[RawWar] Загружено юнитов: " + configs.size());
    }

    private void writeDefaults(Fi combat, Fi builder) {
        d(combat, "assault-alpha", "Штурмовик", "Наступательный юнит со сбалансированными характеристиками.", "combat", "assault", "dagger", 1f, 1f, 1f, 10, 5, false);
        d(combat, "scout-alpha", "Разведчик", "Быстрый и хрупкий юнит для разведки.", "combat", "scout", "flare", 0.8f, 1f, 1.2f, 4, 2, false);
        d(combat, "sniper-alpha", "Снайпер", "Дальний бой, низкая прочность.", "combat", "sniper", "mace", 0.9f, 1.1f, 0.95f, 4, 2, false);
        d(combat, "heavy-alpha", "Тяжёлый боец", "Медленный, прочный, большой урон.", "combat", "heavy", "fortress", 1f, 1f, 1f, 4, 2, false);
        d(combat, "support-alpha", "Поддержка", "Лечит союзные постройки и поддерживает команду.", "combat", "support", "nova", 1f, 1f, 1f, 6, 3, false);
        d(combat, "artillery-alpha", "Артиллерия", "Дальняя поддержка огнём.", "combat", "artillery", "atrax", 1f, 1f, 1f, 3, 2, false);
        d(builder, "engineer-alpha", "Инженер", "Строит и ремонтирует (если режим разрешает).", "builder", "engineer", "poly", 1f, 1f, 1f, 4, 2, true);
        d(builder, "repair-alpha", "Ремонтник", "Чинит союзные постройки.", "builder", "repair", "mono", 1f, 1f, 1f, 4, 2, false);
    }

    private void d(Fi dir, String id, String name, String desc, String type, String cls, String unit, float h, float dmg, float sp, int max, int team, boolean build) {
        dir.mkdirs();
        String json = "{\n  \"id\": \"" + id + "\",\n  \"name\": \"" + name + "\",\n  \"description\": \"" + desc + "\",\n  \"type\": \"" + type + "\",\n  \"class\": \"" + cls + "\",\n  \"unit\": \"" + unit + "\",\n  \"enabled\": true,\n  \"canBuild\": " + build + ",\n  \"stats\": {\n    \"healthMultiplier\": " + h + ",\n    \"damageMultiplier\": " + dmg + ",\n    \"speedMultiplier\": " + sp + "\n  },\n  \"restrictions\": {\n    \"maxPlayers\": " + max + ",\n    \"teamLimit\": " + team + "\n  }\n}\n";
        dir.child(id + ".json").writeString(json);
    }

    // ---------- запросы ----------
    public Collection<UnitConfig> all() { return configs.values(); }
    public UnitConfig get(String id) { return configs.get(id); }

    public List<UnitConfig> byType(String type) {
        List<UnitConfig> l = new ArrayList<>();
        for (UnitConfig c : configs.values()) if (c.enabled && c.type.equalsIgnoreCase(type)) l.add(c);
        return l;
    }

    public List<String> classesOf(String type) {
        LinkedHashSet<String> s = new LinkedHashSet<>();
        for (UnitConfig c : byType(type)) s.add(c.unitClass);
        return new ArrayList<>(s);
    }

    public List<UnitConfig> byClass(String type, String cls) {
        List<UnitConfig> l = new ArrayList<>();
        for (UnitConfig c : byType(type)) if (c.unitClass.equalsIgnoreCase(cls)) l.add(c);
        return l;
    }

    public int usedGlobal(String unitId) {
        int n = 0;
        for (String id : selected.values()) if (id.equals(unitId)) n++;
        return n;
    }

    public int usedInTeam(String unitId, RwTeam t) {
        int n = 0;
        for (Map.Entry<String, String> e : selected.entrySet())
            if (e.getValue().equals(unitId) && t.members.contains(e.getKey())) n++;
        return n;
    }

    /** Свободные места (-1 = без ограничений). */
    public int freeSlots(UnitConfig c, RwTeam t) {
        int free = Integer.MAX_VALUE;
        if (c.maxPlayers > 0) free = Math.min(free, c.maxPlayers - usedGlobal(c.id));
        if (c.teamLimit > 0 && t != null) free = Math.min(free, c.teamLimit - usedInTeam(c.id, t));
        return free == Integer.MAX_VALUE ? -1 : Math.max(0, free);
    }

    public String selectedId(Player p) { return selected.get(p.uuid()); }

    // ---------- выдача ----------
    /** Пытается выдать юнит. Возвращает null при успехе или текст причины отказа. */
    public String give(Player p, UnitConfig c) {
        if (!c.enabled) return "Юнит отключён.";
        RwTeam t = core.teams.of(p);
        if (t == null) return "Вы не состоите в команде.";
        String current = selected.get(p.uuid());
        if (c.id.equals(current)) return "Этот юнит уже выбран.";
        if (freeSlots(c, t) == 0) return "Свободных мест нет.";
        if (core.modes.active() != null && !core.modes.allowUnit(p, c)) return "Режим не разрешает этот юнит.";

        UnitType type = Vars.content.unit(c.unit);
        if (type == null) return "Неизвестный тип юнита.";

        Unit old = p.unit();

        Unit u = type.create(t.team);
        if (!core.spawns.placeAt(p, u, t)) { return "Нет доступной точки появления (/rw spawn set <команда>)."; }
        release(p);
        u.maxHealth = type.health * c.healthMultiplier;
        u.health = u.maxHealth;
        u.add();
        p.unit(u);
        applyMultipliers(u, c);

        if (old != null && !old.isNull() && old != u && old.spawnedByCore) {
            ignoredDeaths.add(old.id);
            old.kill();
        }

        selected.put(p.uuid(), c.id);
        activeUnit.put(p.uuid(), u.id);
        PlayerData d = core.data.get(p.uuid(), p.plainName());
        d.unitId = c.id;
        d.unitClass = c.unitClass;
        core.data.markDirty(p.uuid());
        return null;
    }

    private void applyMultipliers(Unit u, UnitConfig c) {
        if (!core.config.settings.units.statusMultipliers) return;
        // Скорость/урон: постоянный множитель в Mindustry задаётся только статус-эффектом.
        // Реализовано через готовые эффекты как грубое приближение (см. README).
        if (c.speedMultiplier > 1.05f || c.damageMultiplier > 1.05f) u.apply(StatusEffects.overdrive, 60f * 60f * 24f);
    }

    /** Освобождает слот игрока (смена юнита, выход, смерть). */
    public void release(Player p) {
        selected.remove(p.uuid());
        activeUnit.remove(p.uuid());
    }

    public boolean isOwnUnit(Player p, Unit u) {
        Integer id = activeUnit.get(p.uuid());
        return id != null && id == u.id;
    }

    /** true, если смерть юнита вызвана самим плагином (замена юнита) и должна игнорироваться. */
    public boolean consumeIgnored(Unit u) { return ignoredDeaths.remove(u.id); }

    public void clearAll() { selected.clear(); activeUnit.clear(); }
}
