package rawwar.units;

/** Описание класса (отображаемое имя). Классы выводятся из конфигов юнитов, это лишь справочник названий. */
public final class UnitClass {
    private UnitClass() {}

    public static String title(String cls) {
        switch (cls.toLowerCase()) {
            case "assault": return "Штурмовик";
            case "scout": return "Разведчик";
            case "sniper": return "Снайпер";
            case "heavy": return "Тяжёлый боец";
            case "support": return "Поддержка";
            case "artillery": return "Артиллерия";
            case "air": return "Авиация";
            case "engineer": return "Инженер";
            case "repair": return "Ремонтник";
            case "builder": return "Строитель";
            case "supply": return "Снабженец";
            default: return cls;
        }
    }
}
