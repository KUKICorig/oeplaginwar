package rawwar.units;

import arc.util.serialization.JsonValue;

/** Конфигурация одного юнита (units/combat|builder/*.json). */
public class UnitConfig {
    public String id, name, description = "", type = "combat", unitClass = "assault", unit = "dagger";
    public boolean enabled = true;
    public float healthMultiplier = 1f, damageMultiplier = 1f, speedMultiplier = 1f;
    public int maxPlayers = 0;  // 0 = без ограничения
    public int teamLimit = 0;   // 0 = без ограничения
    public boolean canBuild = false;

    public boolean isBuilder() { return "builder".equalsIgnoreCase(type); }

    public static UnitConfig parse(JsonValue v) {
        UnitConfig c = new UnitConfig();
        c.id = v.getString("id");
        c.name = v.getString("name", c.id);
        c.description = v.getString("description", "");
        c.type = v.getString("type", "combat");
        c.unitClass = v.getString("class", "assault");
        c.unit = v.getString("unit", "dagger");
        c.enabled = v.getBoolean("enabled", true);
        c.canBuild = v.getBoolean("canBuild", false);
        JsonValue s = v.get("stats");
        if (s != null) {
            c.healthMultiplier = s.getFloat("healthMultiplier", 1f);
            c.damageMultiplier = s.getFloat("damageMultiplier", 1f);
            c.speedMultiplier = s.getFloat("speedMultiplier", 1f);
        }
        JsonValue r = v.get("restrictions");
        if (r != null) {
            c.maxPlayers = r.getInt("maxPlayers", 0);
            c.teamLimit = r.getInt("teamLimit", 0);
        }
        return c;
    }
}
