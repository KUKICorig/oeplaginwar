package rawwar.data;

/** Постоянные данные игрока. */
public class PlayerData {
    public String uuid = "";
    public String name = "";
    public String unitId = "";
    public String unitClass = "";
    public int kills, deaths, wins, losses, matches;
    public int xp, rating = 1000; // задел на будущее

    public PlayerData() {}
    public PlayerData(String uuid, String name) { this.uuid = uuid; this.name = name; }
}
