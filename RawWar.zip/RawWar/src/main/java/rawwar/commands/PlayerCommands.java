package rawwar.commands;

import mindustry.gen.Player;
import rawwar.core.CoreManager;
import rawwar.data.PlayerData;
import rawwar.teams.RwTeam;

/** Игровые команды (/rw unit, stats, info, team, help). */
public class PlayerCommands {
    private final CoreManager core;
    PlayerCommands(CoreManager core) { this.core = core; }

    void run(Player p, String sub, String[] a) {
        switch (sub) {
            case "unit":
                if (core.units.selectedId(p) != null && !core.config.settings.units.allowChangeUnit) {
                    p.sendMessage("[scarlet]Смена юнита запрещена настройками сервера.");
                    return;
                }
                core.menus.open(p);
                break;
            case "stats": {
                PlayerData d = core.data.get(p.uuid(), p.plainName());
                p.sendMessage("[accent]Убийств: [white]" + d.kills + " [accent]Смертей: [white]" + d.deaths
                        + " [accent]Побед: [white]" + d.wins + " [accent]Поражений: [white]" + d.losses + " [accent]Матчей: [white]" + d.matches);
                break;
            }
            case "info":
                p.sendMessage("[accent]" + core.modes.describe());
                break;
            case "help":
            default:
                p.sendMessage("[accent]RawWar:[white] /rw (меню), /rw unit, /rw stats, /rw info, /rw team, /rw help"
                        + (core.isAdmin(p) ? "\n[accent]Админ:[white] /rw admin, /rw team set <игрок> <команда>, /rw team balance, /rw spawn set|list|remove <команда>, /rw mode list|select|start|stop, /rw reload" : ""));
        }
    }

    void team(Player p, String[] a) {
        RwTeam t = core.teams.of(p);
        if (t == null) { p.sendMessage("[scarlet]Вы не в команде."); return; }
        StringBuilder sb = new StringBuilder("[accent]Команда: [white]" + t.name + " [accent]Игроков: [white]" + t.size() + " [accent]Счёт: [white]" + t.score + "\n");
        for (Player m : core.teams.players(t)) sb.append(m.plainName()).append(", ");
        p.sendMessage(sb.toString());
        RwTeam other = core.teams.other(t);
        if (a.length > 0 && a[0].equalsIgnoreCase("switch")) {
            if (core.teams.canSwitch(p, other)) {
                core.teams.set(p, other);
                core.units.release(p);
                core.menus.open(p);
            } else p.sendMessage("[scarlet]Смена команды сейчас недоступна.");
        }
    }
}
