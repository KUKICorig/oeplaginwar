package rawwar.commands;

import mindustry.gen.Player;
import rawwar.core.CoreManager;
import rawwar.units.UnitConfig;

/** Команды создателя (определяется по UUID из settings.json). */
public class OwnerCommands {
    private final CoreManager core;
    OwnerCommands(CoreManager core) { this.core = core; }

    private static String arg(String[] a, int i) { return CommandManager.arg(a, i); }

    void run(Player p, String[] a) {
        switch (arg(a, 0).toLowerCase()) {
            case "reload":
                core.reload();
                p.sendMessage("[lime]Полная перезагрузка выполнена.");
                break;
            case "debug":
                core.config.settings.debug = !core.config.settings.debug;
                core.config.save();
                p.sendMessage("debug = " + core.config.settings.debug);
                break;
            case "data":
                core.data.saveAll();
                core.data.backup();
                p.sendMessage("[lime]Данные сохранены, резервная копия создана. Побед Alpha/Bravo/ничьих: "
                        + core.data.server.alphaWins + "/" + core.data.server.bravoWins + "/" + core.data.server.draws);
                break;
            case "modes":
                core.modes.all().values().forEach(m -> p.sendMessage(m.getId() + (m == core.modes.active() ? " (активен)" : "")));
                break;
            case "units":
                for (UnitConfig c : core.units.all()) p.sendMessage(c.id + " [" + c.type + "/" + c.unitClass + "] " + c.unit + (c.enabled ? "" : " (выкл.)") + " использ.: " + core.units.usedGlobal(c.id));
                break;
            case "admin": {
                Player t = AdminCommands.findPlayer(arg(a, 2));
                if (t == null) { p.sendMessage("Использование: /rw owner admin add|remove <игрок>"); return; }
                if (arg(a, 1).equalsIgnoreCase("add")) { if (!core.data.server.admins.contains(t.uuid())) core.data.server.admins.add(t.uuid()); }
                else core.data.server.admins.remove(t.uuid());
                core.data.saveServer();
                p.sendMessage("OK");
                break;
            }
            default:
                p.sendMessage("[accent]/rw owner[white] reload | debug | data | modes | units | admin add|remove <игрок>");
        }
    }
}
