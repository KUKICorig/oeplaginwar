package rawwar.commands;

import mindustry.gen.Player;
import rawwar.core.CoreManager;

/** Command System: единая точка входа для /rw, проверка прав на стороне сервера. */
public class CommandManager {
    public final CoreManager core;
    private final PlayerCommands player;
    private final AdminCommands admin;
    private final OwnerCommands owner;

    public CommandManager(CoreManager core) {
        this.core = core;
        this.player = new PlayerCommands(core);
        this.admin = new AdminCommands(core);
        this.owner = new OwnerCommands(core);
    }

    static String arg(String[] a, int i) { return i < a.length && a[i] != null ? a[i] : ""; }

    /** args: [sub] [a] [b] [c] */
    public void handle(Player p, String[] args) {
        String sub = arg(args, 0).toLowerCase();
        String[] rest = args.length > 1 ? java.util.Arrays.copyOfRange(args, 1, args.length) : new String[0];
        switch (sub) {
            case "":
                core.menus.open(p);
                return;
            case "owner":
                if (!core.isOwner(p)) { p.sendMessage("[scarlet]Нет доступа."); return; }
                owner.run(p, rest);
                return;
            case "admin":
            case "reload":
            case "mode":
                if (!core.isAdmin(p)) { p.sendMessage("[scarlet]Нет доступа."); return; }
                admin.run(p, sub, rest);
                return;
            case "spawn":
                if (!core.isAdmin(p)) { p.sendMessage("[scarlet]Нет доступа."); return; }
                admin.run(p, sub, rest);
                return;
            case "team":
                // /rw team — для всех; /rw team set|balance — только админам
                if (rest.length > 0 && (rest[0].equalsIgnoreCase("set") || rest[0].equalsIgnoreCase("balance"))) {
                    if (!core.isAdmin(p)) { p.sendMessage("[scarlet]Нет доступа."); return; }
                    admin.run(p, sub, rest);
                } else player.team(p, rest);
                return;
            default:
                player.run(p, sub, rest);
        }
    }

    /** Консольная команда: полный доступ (консоль сервера доверенная). */
    public void handleConsole(String[] args) {
        String sub = arg(args, 0).toLowerCase();
        String[] rest = args.length > 1 ? java.util.Arrays.copyOfRange(args, 1, args.length) : new String[0];
        if (sub.equals("reload")) { core.reload(); arc.util.Log.info("OK"); return; }
        if (sub.equals("mode")) { admin.runConsoleMode(rest); return; }
        arc.util.Log.info("rw reload | rw mode list|select <id>|start|stop");
    }
}
