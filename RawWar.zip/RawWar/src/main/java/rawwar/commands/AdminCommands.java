package rawwar.commands;

import arc.util.Log;
import mindustry.gen.Groups;
import mindustry.gen.Player;
import rawwar.core.CoreManager;
import rawwar.modes.GameMode;
import rawwar.spawn.SpawnPoint;
import rawwar.teams.RwTeam;

import java.util.List;

/** Административные команды. Права проверяются в CommandManager (на сервере). */
public class AdminCommands {
    private final CoreManager core;
    AdminCommands(CoreManager core) { this.core = core; }

    private static String arg(String[] a, int i) { return CommandManager.arg(a, i); }

    void run(Player p, String sub, String[] a) {
        switch (sub) {
            case "admin":
                p.sendMessage("[accent]Админ-меню (текстовое): [white]/rw mode list | /rw team balance | /rw spawn list | /rw reload");
                break;
            case "reload":
                core.reload();
                p.sendMessage("[lime]Конфигурация перезагружена.");
                break;
            case "team":
                team(p, a);
                break;
            case "spawn":
                spawn(p, a);
                break;
            case "mode":
                mode(s -> p.sendMessage(s), a);
                break;
            default:
        }
    }

    private void team(Player p, String[] a) {
        String op = arg(a, 0).toLowerCase();
        if (op.equals("balance")) {
            p.sendMessage("[lime]Перенесено игроков: " + core.teams.balance());
        } else if (op.equals("set")) {
            Player target = findPlayer(arg(a, 1));
            RwTeam t = core.teams.byId(arg(a, 2));
            if (target == null || t == null) { p.sendMessage("[scarlet]Использование: /rw team set <игрок> <alpha|bravo>"); return; }
            core.teams.set(target, t);
            core.units.release(target);
            core.menus.open(target);
            p.sendMessage("[lime]" + target.plainName() + " -> " + t.name);
        }
    }

    private void spawn(Player p, String[] a) {
        String op = arg(a, 0).toLowerCase();
        RwTeam t = core.teams.byId(arg(a, 1));
        switch (op) {
            case "set":
                if (t == null) { p.sendMessage("[scarlet]Использование: /rw spawn set <alpha|bravo>"); return; }
                core.spawns.add(t.id, p.tileX(), p.tileY());
                p.sendMessage("[lime]Точка команды " + t.name + " добавлена: " + p.tileX() + ", " + p.tileY());
                break;
            case "list": {
                List<SpawnPoint> l = core.spawns.list(t == null ? null : t.id);
                if (l.isEmpty()) { p.sendMessage("Точек нет."); return; }
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < l.size(); i++) sb.append(i).append(") ").append(l.get(i).team).append(" ").append(l.get(i).x).append(",").append(l.get(i).y).append("\n");
                p.sendMessage(sb.toString());
                break;
            }
            case "remove":
                if (t == null) { p.sendMessage("[scarlet]Использование: /rw spawn remove <alpha|bravo> [номер]"); return; }
                int n = a.length > 2 ? core.spawns.removeAt(t.id, parse(arg(a, 2))) : core.spawns.remove(t.id);
                p.sendMessage("Удалено точек: " + n);
                break;
            default:
                p.sendMessage("/rw spawn set|list|remove <alpha|bravo>");
        }
    }

    void mode(java.util.function.Consumer<String> out, String[] a) {
        switch (arg(a, 0).toLowerCase()) {
            case "list":
                for (GameMode m : core.modes.all().values()) out.accept((m == core.modes.active() ? "* " : "  ") + m.getId() + " — " + m.getName());
                break;
            case "select":
                out.accept(core.modes.select(arg(a, 1), true) ? "Режим выбран." : "Режим не найден.");
                break;
            case "start":
                out.accept(core.modes.start() ? "Запущено." : "Не удалось (режим не выбран или уже идёт матч).");
                break;
            case "stop":
                core.modes.stop();
                out.accept("Остановлено.");
                break;
            default:
                out.accept("/rw mode list|select <id>|start|stop");
        }
    }

    void runConsoleMode(String[] a) { mode(s -> Log.info(s), a); }

    static Player findPlayer(String name) {
        for (Player p : Groups.player) if (p.plainName().equalsIgnoreCase(name) || p.name.equalsIgnoreCase(name)) return p;
        return null;
    }

    private static int parse(String s) { try { return Integer.parseInt(s); } catch (Exception e) { return -1; } }
}
