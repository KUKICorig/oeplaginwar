package rawwar.spawn;

import mindustry.Vars;
import mindustry.gen.Player;
import mindustry.gen.Unit;
import mindustry.world.Tile;
import rawwar.core.CoreManager;
import rawwar.data.JsonIO;
import rawwar.teams.RwTeam;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** Spawn System: точки высадки команд, проверка свободного места. */
public class SpawnManager {
    public static class SpawnFile { public ArrayList<SpawnPoint> points = new ArrayList<>(); }

    private final CoreManager core;
    private SpawnFile file = new SpawnFile();
    private final Random rnd = new Random();
    private int rr = 0;

    public SpawnManager(CoreManager core) { this.core = core; }

    public void load() {
        file = JsonIO.read(core.root.child("config").child("spawns.json"), SpawnFile.class, SpawnFile::new);
    }

    private void save() { JsonIO.write(core.root.child("config").child("spawns.json"), file); }

    public List<SpawnPoint> list(String teamId) {
        List<SpawnPoint> l = new ArrayList<>();
        String mode = core.modes.activeId();
        for (SpawnPoint s : file.points) {
            if (teamId != null && !s.team.equalsIgnoreCase(teamId)) continue;
            if (!s.mode.isEmpty() && !s.mode.equalsIgnoreCase(mode)) continue;
            l.add(s);
        }
        return l;
    }

    public void add(String teamId, int x, int y) { file.points.add(new SpawnPoint(teamId, x, y)); save(); }

    public int remove(String teamId) {
        int before = file.points.size();
        file.points.removeIf(s -> s.team.equalsIgnoreCase(teamId));
        save();
        return before - file.points.size();
    }

    public int removeAt(String teamId, int index) {
        List<SpawnPoint> l = list(teamId);
        if (index < 0 || index >= l.size()) return 0;
        file.points.remove(l.get(index));
        save();
        return 1;
    }

    private boolean free(Tile t, Unit u) {
        if (t == null) return false;
        if (u.type.flying) return true;
        return !t.solid() && !t.floor().isDeep();
    }

    /** Размещает юнит у точки команды. */
    public boolean placeAt(Player p, Unit u, RwTeam team) {
        if (!core.config.settings.spawn.enabled) return true; // остаётся на месте
        List<SpawnPoint> pts = list(team.id);
        if (pts.isEmpty()) return false;
        SpawnPoint sp = core.config.settings.spawn.randomSpawn ? pts.get(rnd.nextInt(pts.size())) : pts.get(rr++ % pts.size());
        int radius = Math.max(1, core.config.settings.spawn.searchRadius);
        for (int r = 0; r <= radius; r++) {
            for (int dx = -r; dx <= r; dx++) {
                for (int dy = -r; dy <= r; dy++) {
                    if (Math.max(Math.abs(dx), Math.abs(dy)) != r) continue;
                    Tile t = Vars.world.tile(sp.x + dx, sp.y + dy);
                    if (free(t, u)) {
                        u.set(t.worldx(), t.worldy());
                        return true;
                    }
                }
            }
        }
        return false;
    }
}
