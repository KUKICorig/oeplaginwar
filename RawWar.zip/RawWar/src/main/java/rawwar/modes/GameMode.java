package rawwar.modes;

import mindustry.gen.Player;
import rawwar.core.CoreManager;
import rawwar.units.UnitConfig;

/** Интерфейс игрового режима. Режимы подключаются как отдельные jar из RawWar/modes/. */
public interface GameMode {
    String getId();
    String getName();

    /** Вызывается загрузчиком перед onLoad: даёт доступ к системам RawWar. */
    default void attach(CoreManager core) {}

    void onLoad();
    void onStart();
    void onPlayerJoin(Player player);
    void onPlayerDeath(Player player);
    /** Вызывается раз в секунду во время матча. */
    void onUpdate();
    void onEnd();
    void onUnload();

    // --- необязательные хуки ---
    default void onKill(Player killer, Player victim) {}
    default boolean allowBuilding(Player player) { return false; }
    default boolean allowUnit(Player player, UnitConfig unit) { return true; }
    default String describe() { return getName(); }
}
