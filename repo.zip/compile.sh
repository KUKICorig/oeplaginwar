#!/usr/bin/env bash
# RawWar: сборка БЕЗ Gradle (нужен только JDK 17+).  ./compile.sh [путь/к/server-release.jar]
set -euo pipefail
cd "$(dirname "$0")"

die() { echo "ОШИБКА: $*" >&2; exit 1; }
command -v javac >/dev/null || die "javac не найден: установите JDK 17+ и добавьте в PATH."
command -v jar   >/dev/null || die "утилита jar не найдена (нужен JDK, не JRE)."

# --- 1. файл сервера ---------------------------------------------------
CANDIDATES=()
if [ $# -ge 1 ]; then CANDIDATES=("$1"); else for j in libs/*.jar; do [ -s "$j" ] && CANDIDATES+=("$j"); done; fi
SERVER=""
for j in "${CANDIDATES[@]:-}"; do
  [ -n "$j" ] && [ -s "$j" ] || continue
  if jar tf "$j" 2>/dev/null | grep -qx 'version.properties' && jar tf "$j" | grep -qx 'mindustry/mod/Plugin.class'; then SERVER="$j"; break; fi
done
[ -n "$SERVER" ] || die "в libs/ нет рабочего server-release.jar (пустые файлы пропускаются). Положите jar сервера Mindustry в libs/ или передайте путь аргументом."

TMP=build/tmp; rm -rf build; mkdir -p "$TMP" build/classes build/meta build/libs
SERVER_ABS="$(cd "$(dirname "$SERVER")" && pwd)/$(basename "$SERVER")"
( cd "$TMP" && jar xf "$SERVER_ABS" version.properties mindustry/mod/Plugin.class )
BUILD=$(grep -E '^build=' "$TMP/version.properties" | cut -d= -f2 | tr -d '\r')
MAJOR=${BUILD%%.*}
# версия байткода = байты 6-7 заголовка класса (major_version)
CLASSV=$(od -An -tu1 -j6 -N2 "$TMP/mindustry/mod/Plugin.class" | awk '{print $1*256+$2}')
RELEASE=$((CLASSV - 44)); [ "$RELEASE" -ge 8 ] || RELEASE=17
JAVA_NOW=$(javac -version 2>&1 | sed -E 's/javac ([0-9]+).*/\1/')
[ "$JAVA_NOW" -ge "$RELEASE" ] || die "сервер собран под Java $RELEASE, а у вас JDK $JAVA_NOW."
echo "Сервер: $SERVER (Mindustry build $BUILD), байткод Java $RELEASE"

# --- 2. компиляция -----------------------------------------------------
# Класспуть = все рабочие jar из libs/ (arc, mindustry уже внутри server-release.jar)
CP="$SERVER"
for j in libs/*.jar; do [ -s "$j" ] && [ "$j" != "$SERVER" ] && CP="$CP:$j"; done
find src/main/java -name '*.java' > build/sources.txt
[ -s build/sources.txt ] || die "в src/main/java нет .java файлов."
javac --release "$RELEASE" -encoding UTF-8 -Xlint:deprecation -cp "$CP" -d build/classes @build/sources.txt

# --- 3. plugin.json и jar ---------------------------------------------
VER=$(grep -E '^pluginVersion=' gradle.properties | cut -d= -f2 | tr -d '\r '); VER=${VER:-1.0.0}
sed -E "s/\"version\"[[:space:]]*:[[:space:]]*\"[^\"]*\"/\"version\": \"$VER\"/; s/\"minGameVersion\"[[:space:]]*:[[:space:]]*\"[^\"]*\"/\"minGameVersion\": \"$MAJOR\"/" plugin.json > build/meta/plugin.json
[ -d src/main/resources ] && cp -r src/main/resources/. build/classes/ 2>/dev/null || true
jar --create --file build/libs/RawWar.jar -C build/classes . -C build/meta plugin.json

# --- 4. проверка -------------------------------------------------------
MAIN=$(grep -E '"main"' plugin.json | sed -E 's/.*"main"[[:space:]]*:[[:space:]]*"([^"]+)".*/\1/' | tr . /)
jar tf build/libs/RawWar.jar | grep -qx "$MAIN.class" || die "в jar нет класса $MAIN.class"
jar tf build/libs/RawWar.jar | grep -qx 'plugin.json' || die "в jar нет plugin.json"
if jar tf build/libs/RawWar.jar | grep -E '^(mindustry|arc)/' >/dev/null; then die "в jar попали классы игры"; fi
rm -rf "$TMP"
echo "OK: build/libs/RawWar.jar ($(jar tf build/libs/RawWar.jar | grep -c '\.class$') классов). Положите в config/mods/ сервера."
