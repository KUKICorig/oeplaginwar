@echo off
rem RawWar: сборка БЕЗ Gradle (нужен JDK 17+).  compile.bat [путь\к\server-release.jar]
setlocal enabledelayedexpansion
chcp 65001 >nul
cd /d "%~dp0"

where javac >nul 2>nul || (echo ОШИБКА: javac не найден, установите JDK 17+ & exit /b 1)

set "SERVER=%~1"
if "%SERVER%"=="" set "SERVER=libs\server-release.jar"
if not exist "%SERVER%" (echo ОШИБКА: нет файла %SERVER% & exit /b 1)
for %%F in ("%SERVER%") do if %%~zF==0 (echo ОШИБКА: %SERVER% пустой - положите настоящий server-release.jar & exit /b 1)

if exist build rmdir /s /q build
mkdir build\classes build\meta build\libs

dir /s /b src\main\java\*.java > build\sources.txt
javac --release 17 -encoding UTF-8 -Xlint:deprecation -cp "%SERVER%" -d build\classes @build\sources.txt || (echo ОШИБКА компиляции & exit /b 1)

rem minGameVersion/version берутся из plugin.json как есть
copy /y plugin.json build\meta\plugin.json >nul
if exist src\main\resources xcopy /e /y /q src\main\resources\* build\classes\ >nul

jar --create --file build\libs\RawWar.jar -C build\classes . -C build\meta plugin.json || exit /b 1
echo OK: build\libs\RawWar.jar  - положите в config\mods\ сервера.
