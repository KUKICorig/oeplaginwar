package rawwar.spawn;

import mindustry.Vars;
import mindustry.gen.Call;
import mindustry.gen.Player;
import mindustry.gen.Unit;
import mindustry.world.Tile;
import rawwar.core.CoreManager;
import rawwar.data.JsonIO;
import rawwar.teams.RwTeam;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * Spawn System: точки высадки команд (config/spawns.json) и их редактор.
 * Редактировать можно командами (/rw spawn add|remove|clear), меню (/rw spawn)
 * и «режимом тапа» (/rw spawn edit <команда>): нажатие на карту добавляет точку,
 * повторное нажатие рядом с точкой — удаляет её.
 * Номера точек в списках — с 1, в пределах команды и активного режима.
 */
public class SpawnManager {
    public static class SpawnFile { public ArrayList<SpawnPoint> points = new ArrayList<>(); }

    private static final float LABEL_SECONDS = 15f;
    private static final int LIST_LIMIT = 20;

    private final CoreManager core;
    private SpawnFile file = new SpawnFile();
    private final Random rnd = new Random();
    private int rr = 0;
    /** uuid админа -> id команды, для которой включён режим тапа */
    private final Map<String, String> editing = new HashMap<>();

    public SpawnManager(CoreManager core) { this.core = core; }

    public void load() {
        file = JsonIO.read(core.root.child("config").child("spawns.json"), SpawnFile.class, SpawnFile::new);
    }

    private void save() { JsonIO.write(core.root.child("config").child("spawns.json"), file); }

    // ---------- список ----------
    public List<SpawnPoint> list(String teamId) {
        List<SpawnPoint> l = new ArrayList<>();
        String mode = core.modes.activeId();
        for (SpawnPoint s : file.points) {
            if (teamId != null && !s.team.equalsIgnoreCase(teamId)) continue;
            if (!s.mode.isEmpty() && !s.mode.equalsIgnoreCase(mode)) continue;
            l.add(s);
        }
        return l;
    }

    public int count(String teamId) { return list(teamId).size(); }

    // ---------- изменение ----------
    /** Добавляет точку. Возвращает null при успехе или текст ошибки. */
    public String addPoint(String teamId, int x, int y) {
        RwTeam t = core.teams.byId(teamId);
        if (t == null) return "Неизвестная команда. Используйте a или b.";
        if (Vars.world == null || Vars.world.width() <= 0) return "Карта не загружена.";
        if (x < 0 || y < 0 || x >= Vars.world.width() || y >= Vars.world.height())
            return "Координаты вне карты (допустимо 0.." + (Vars.world.width() - 1) + ", 0.." + (Vars.world.height() - 1) + ").";
        for (SpawnPoint s : list(t.id))
            if (s.x == x && s.y == y) return "Здесь уже есть точка команды " + t.name + ".";
        file.points.add(new SpawnPoint(t.id, x, y));
        save();
        return null;
    }

    /** Заменяет все точки новыми (генератор карты): старые точки всех команд и режимов удаляются. */
    public void replaceAll(List<SpawnPoint> points) {
        file.points = new ArrayList<>(points);
        save();
    }

    /** Предупреждение о непроходимом тайле ("" если всё нормально). */
    public String tileWarning(int x, int y) {
        Tile t = Vars.world == null ? null : Vars.world.tile(x, y);
        if (t == null) return "";
        if (t.solid() || t.floor().isDeep())
            return " [orange](тайл непроходим: наземные юниты появятся рядом, радиус поиска "
                    + Math.max(1, core.config.settings.spawn.searchRadius) + ")";
        return "";
    }

    /** Удаляет все точки команды (во всех режимах). */
    public int remove(String teamId) {
        int before = file.points.size();
        file.points.removeIf(s -> s.team.equalsIgnoreCase(teamId));
        save();
        return before - file.points.size();
    }

    /** Удаляет точку по индексу (с 0) в списке list(teamId). */
    public int removeAt(String teamId, int index) {
        List<SpawnPoint> l = list(teamId);
        if (index < 0 || index >= l.size()) return 0;
        file.points.remove(l.get(index));
        save();
        return 1;
    }

    /** Удаляет последнюю точку команды. Возвращает удалённую или null. */
    public SpawnPoint removeLast(String teamId) {
        List<SpawnPoint> l = list(teamId);
        if (l.isEmpty()) return null;
        SpawnPoint sp = l.get(l.size() - 1);
        file.points.remove(sp);
        save();
        return sp;
    }

    /** Удаляет ближайшую точку в пределах radius тайлов от (x, y). Возвращает удалённую или null. */
    public SpawnPoint removeNear(String teamId, int x, int y, int radius) {
        for (SpawnPoint s : list(teamId)) {
            if (Math.max(Math.abs(s.x - x), Math.abs(s.y - y)) <= radius) {
                file.points.remove(s);
                save();
                return s;
            }
        }
        return null;
    }

    // ---------- вывод ----------
    /** Нумерованный список точек команды (для чата/меню). */
    public String describe(String teamId) {
        List<SpawnPoint> l = list(teamId);
        if (l.isEmpty()) return "[scarlet]Точек нет — игроки этой команды не смогут появиться.";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < l.size() && i < LIST_LIMIT; i++) {
            SpawnPoint sp = l.get(i);
            sb.append("[accent]").append(i + 1).append(") [white]").append(sp.x).append(", ").append(sp.y);
            if (!sp.mode.isEmpty()) sb.append(" [gray][").append(sp.mode).append("]");
            sb.append("\n");
        }
        if (l.size() > LIST_LIMIT) sb.append("[gray]... и ещё ").append(l.size() - LIST_LIMIT).append("\n");
        return sb.toString().trim();
    }

    /** Подписи с номерами над точками на карте у игрока (teamId == null — обе команды). */
    public void show(Player p, String teamId) {
        if (p == null || p.con == null) return;
        for (RwTeam t : new RwTeam[]{core.teams.alpha, core.teams.bravo}) {
            if (teamId != null && !t.id.equalsIgnoreCase(teamId)) continue;
            List<SpawnPoint> l = list(t.id);
            for (int i = 0; i < l.size(); i++) {
                SpawnPoint sp = l.get(i);
                Call.label(p.con, "[accent]" + t.name + " #" + (i + 1), LABEL_SECONDS, sp.x * Vars.tilesize, sp.y * Vars.tilesize);
            }
        }
    }

    // ---------- режим тапа ----------
    public String editingTeam(Player p) { return editing.get(p.uuid()); }

    /** Включает режим тапа для команды (teamId == null — выключает). */
    public void setEdit(Player p, String teamId) {
        if (teamId == null) editing.remove(p.uuid()); else editing.put(p.uuid(), teamId);
    }

    public void leave(Player p) { editing.remove(p.uuid()); }

    /** Обработчик нажатия на карту (EventType.TapEvent). */
    public void onTap(Player p, Tile tile) {
        if (p == null || tile == null) return;
        String teamId = editing.get(p.uuid());
        if (teamId == null) return;
        if (!core.isAdmin(p)) { editing.remove(p.uuid()); return; }
        RwTeam t = core.teams.byId(teamId);
        if (t == null) { editing.remove(p.uuid()); return; }

        SpawnPoint removed = removeNear(t.id, tile.x, tile.y, 1);
        if (removed != null) {
            p.sendMessage("[orange]Точка удалена: [white]" + removed.x + ", " + removed.y + "[orange]. Осталось: [white]" + count(t.id));
        } else {
            String err = addPoint(t.id, tile.x, tile.y);
            if (err != null) p.sendMessage("[scarlet]" + err);
            else p.sendMessage("[lime]Точка #" + count(t.id) + " команды " + t.name + ": [white]" + tile.x + ", " + tile.y + tileWarning(tile.x, tile.y));
        }
        show(p, t.id);
    }

    // ---------- высадка ----------
    /** Размещает юнит (например, бота) у случайной точки команды. false — у команды нет подходящей точки. */
    public boolean placeNear(Unit u, RwTeam team) {
        List<SpawnPoint> pts = list(team.id);
        if (pts.isEmpty()) return false;
        return placeAtPoint(u, pts.get(rnd.nextInt(pts.size())));
    }

    private boolean placeAtPoint(Unit u, SpawnPoint sp) {
        int radius = Math.max(1, core.config.settings.spawn.searchRadius);
        for (int r = 0; r <= radius; r++) {
            for (int dx = -r; dx <= r; dx++) {
                for (int dy = -r; dy <= r; dy++) {
                    if (Math.max(Math.abs(dx), Math.abs(dy)) != r) continue;
                    Tile t = Vars.world.tile(sp.x + dx, sp.y + dy);
                    if (free(t, u)) {
                        u.set(t.worldx(), t.worldy());
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private boolean free(Tile t, Unit u) {
        if (t == null) return false;
        if (u.type.flying) return true;
        return !t.solid() && !t.floor().isDeep();
    }

    /** Размещает юнит у точки команды. */
    public boolean placeAt(Player p, Unit u, RwTeam team) {
        if (!core.config.settings.spawn.enabled) {
            // точки выключены: новый юнит появляется там, где стоял прежний
            Unit cur = p.unit();
            if (cur != null && !cur.dead()) u.set(cur.x, cur.y);
            return true;
        }
        List<SpawnPoint> pts = list(team.id);
        if (pts.isEmpty()) return false;
        SpawnPoint sp = core.config.settings.spawn.randomSpawn ? pts.get(rnd.nextInt(pts.size())) : pts.get(rr++ % pts.size());
        int radius = Math.max(1, core.config.settings.spawn.searchRadius);
        for (int r = 0; r <= radius; r++) {
            for (int dx = -r; dx <= r; dx++) {
                for (int dy = -r; dy <= r; dy++) {
                    if (Math.max(Math.abs(dx), Math.abs(dy)) != r) continue;
                    Tile t = Vars.world.tile(sp.x + dx, sp.y + dy);
                    if (free(t, u)) {
                        u.set(t.worldx(), t.worldy());
                        return true;
                    }
                }
            }
        }
        return false;
    }
}
