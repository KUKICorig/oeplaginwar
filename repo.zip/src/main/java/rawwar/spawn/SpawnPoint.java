package rawwar.spawn;

/** Точка появления (координаты в тайлах). */
public class SpawnPoint {
    public String team = "alpha";
    public String mode = ""; // "" = для всех режимов
    public int x, y;

    public SpawnPoint() {}
    public SpawnPoint(String team, int x, int y) { this.team = team; this.x = x; this.y = y; }
}
