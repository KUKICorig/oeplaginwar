package rawwar.mapgen;

/** Простой детерминированный шум значений (без зависимостей от Mindustry/Arc). Результат 0..1. */
final class Noise {
    private Noise() {}

    private static float hash(long seed, int x, int y) {
        long h = seed * 0x9E3779B97F4A7C15L + x * 0xC2B2AE3D27D4EB4FL + y * 0x165667B19E3779F9L;
        h ^= h >>> 29;
        h *= 0xBF58476D1CE4E5B9L;
        h ^= h >>> 32;
        return (h & 0xFFFFFFL) / (float) 0x1000000;
    }

    static float value(long seed, float x, float y) {
        int x0 = (int) Math.floor(x), y0 = (int) Math.floor(y);
        float fx = x - x0, fy = y - y0;
        float u = fx * fx * (3f - 2f * fx), v = fy * fy * (3f - 2f * fy);
        float a = hash(seed, x0, y0), b = hash(seed, x0 + 1, y0);
        float c = hash(seed, x0, y0 + 1), d = hash(seed, x0 + 1, y0 + 1);
        float top = a + (b - a) * u, bottom = c + (d - c) * u;
        return top + (bottom - top) * v;
    }

    /** Несколько октав, нормировано в 0..1. */
    static float fbm(long seed, float x, float y, int octaves) {
        float sum = 0f, amp = 1f, norm = 0f, f = 1f;
        for (int i = 0; i < octaves; i++) {
            sum += value(seed + i * 101L, x * f, y * f) * amp;
            norm += amp;
            amp *= 0.5f;
            f *= 2f;
        }
        return sum / norm;
    }

    /** Случайное число 0..1 для целочисленной точки. */
    static float rand(long seed, int x, int y) { return hash(seed, x, y); }
}
