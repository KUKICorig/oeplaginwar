package rawwar.mapgen;

import rawwar.spawn.SpawnPoint;

import java.util.ArrayList;
import java.util.List;

/**
 * Раскладка карты: центральный шестиугольник и satellites дополнительных, расставленных по кругу
 * через равные углы (3 шт. = 120°), поэтому расстояния от центра до каждого из них и между соседними
 * дополнительными одинаковы. Только арифметика — не зависит от Mindustry.
 */
public final class HexLayout {
    public static final String ALPHA = "alpha", BRAVO = "bravo";

    public static final class Hex {
        public final int index;
        public final boolean center;
        public final int cx, cy;       // центр шестиугольника (тайлы)
        public int spawnX, spawnY;     // точка спавна
        public String team = "";       // "" = без точки спавна
        public final double angle;     // направление от центра (радианы), для центрального — 0

        Hex(int index, boolean center, int cx, int cy, double angle) {
            this.index = index; this.center = center; this.cx = cx; this.cy = cy; this.angle = angle;
            this.spawnX = cx; this.spawnY = cy;
        }
    }

    public final List<Hex> hexes = new ArrayList<>();
    public final List<String> warnings = new ArrayList<>();
    public int width, height;
    public double distance;            // центр → центр дополнительного
    public boolean autoSize, autoDistance, fits = true;
    private MapGenConfig cfg;

    private HexLayout() {}

    public static HexLayout compute(MapGenConfig c) {
        HexLayout l = new HexLayout();
        l.cfg = c;
        double R = c.radius, sq = c.squash;
        int n = c.satellites;

        double[] ang = new double[n];
        for (int i = 0; i < n; i++) ang[i] = Math.toRadians(c.angle + 360.0 * i / n);

        // расстояние от центра до дополнительных
        l.autoDistance = c.distance <= 0;
        if (l.autoDistance) {
            double rmax = 0;
            for (double a : ang) rmax = Math.max(rmax, HexShape.boundaryRadius(R, sq, a));
            l.distance = 2.0 * rmax + c.gap;
        } else {
            l.distance = c.distance;
        }

        // смещения центров относительно центрального и охватывающий прямоугольник
        double[] ox = new double[n + 1], oy = new double[n + 1];
        double minX = -R, maxX = R, minY = -R / sq, maxY = R / sq;
        for (int i = 0; i < n; i++) {
            ox[i + 1] = l.distance * Math.cos(ang[i]);
            oy[i + 1] = l.distance * Math.sin(ang[i]);
            minX = Math.min(minX, ox[i + 1] - R);
            maxX = Math.max(maxX, ox[i + 1] + R);
            minY = Math.min(minY, oy[i + 1] - R / sq);
            maxY = Math.max(maxY, oy[i + 1] + R / sq);
        }
        double bw = maxX - minX, bh = maxY - minY;

        l.autoSize = c.width <= 0 || c.height <= 0;
        l.width = c.width > 0 ? c.width : (int) Math.ceil(bw) + 2 * c.margin;
        l.height = c.height > 0 ? c.height : (int) Math.ceil(bh) + 2 * c.margin;
        l.width = Math.max(50, Math.min(1000, l.width));
        l.height = Math.max(50, Math.min(1000, l.height));
        l.fits = bw + 2 <= l.width && bh + 2 <= l.height;
        if (!l.fits) l.warnings.add("Шестиугольники не помещаются в карту " + l.width + "x" + l.height
                + " (нужно минимум " + (int) Math.ceil(bw + 2) + "x" + (int) Math.ceil(bh + 2) + "). Поставьте width/height 0 (авто).");

        double midX = (minX + maxX) / 2.0, midY = (minY + maxY) / 2.0;
        for (int i = 0; i <= n; i++) {
            int cx = (int) Math.round(l.width / 2.0 + ox[i] - midX);
            int cy = (int) Math.round(l.height / 2.0 + oy[i] - midY);
            l.hexes.add(new Hex(i, i == 0, cx, cy, i == 0 ? 0 : ang[i - 1]));
        }

        // точки спавна: сдвиг наружу и команда
        for (Hex h : l.hexes) {
            if (h.center) continue;
            h.spawnX = h.cx + (int) Math.round(Math.cos(h.angle) * c.spawnOffset * R);
            h.spawnY = h.cy + (int) Math.round(Math.sin(h.angle) * c.spawnOffset * R / sq);
        }
        l.assignTeams();
        for (String t : new String[]{ALPHA, BRAVO}) {
            if (l.count(t) == 0) l.warnings.add("У команды " + t + " нет точек спавна — измените teamAssign или centerSpawn.");
        }
        return l;
    }

    private void assignTeams() {
        String mode = cfg.teamAssign;
        int k = 0;
        for (Hex h : hexes) {
            if (h.center && !cfg.centerSpawn) { h.team = ""; continue; }
            switch (mode) {
                case "ring_vs_center": h.team = h.center ? BRAVO : ALPHA; break;
                case "alternate": h.team = (k++ % 2 == 0) ? ALPHA : BRAVO; break;
                default: h.team = h.center ? ALPHA : BRAVO;
            }
        }
    }

    public int count(String team) {
        int n = 0;
        for (Hex h : hexes) if (team.equals(h.team)) n++;
        return n;
    }

    /** Точки спавна для SpawnManager (для всех режимов). */
    public List<SpawnPoint> spawns() {
        List<SpawnPoint> out = new ArrayList<>();
        for (Hex h : hexes) if (!h.team.isEmpty()) out.add(new SpawnPoint(h.team, h.spawnX, h.spawnY));
        return out;
    }

    /** Проходы: пары индексов шестиугольников, которые соединяются. */
    public List<int[]> corridors() {
        List<int[]> out = new ArrayList<>();
        if (cfg.corridorWidth <= 0) return out;
        int n = hexes.size() - 1;
        for (int i = 1; i <= n; i++) out.add(new int[]{0, i});
        if (cfg.ringCorridors && n >= 2) {
            for (int i = 1; i <= n; i++) {
                int j = i % n + 1;
                if (n == 2 && i == 2) break; // для двух — одна связь, не две одинаковых
                out.add(new int[]{i, j});
            }
        }
        return out;
    }

    /** Расстояние между соседними дополнительными шестиугольниками (хорда окружности). */
    public double ringSpacing() {
        int n = hexes.size() - 1;
        if (n < 2) return 0;
        return 2.0 * distance * Math.sin(Math.PI / n);
    }
}
