package rawwar.mapgen;

/**
 * Настройки генератора карты (config/mapgen.json).
 * Меняются командой /mapgen set <ключ> <значение>, меню /mapgen или правкой файла + /rw reload.
 * Ключи, диапазоны и описания — в MapGenManager.PARAMS (/mapgen keys).
 */
public class MapGenConfig {
    public String help = "Генератор карты: шестиугольник в центре и satellites шестиугольников вокруг него, "
            + "равномерно по кругу (3 штуки = через 120 градусов), в каждом точка спавна. "
            + "Настройка: /mapgen (меню), /mapgen set <ключ> <значение>, /mapgen keys. Запуск: /mapgen generate.";

    // ---- размер карты ----
    /** Размер карты в тайлах; 0 = подобрать автоматически по раскладке. */
    public int width = 0, height = 0;
    /** Отступ от краёв шестиугольников до границы карты (при авторазмере). */
    public int margin = 12;

    // ---- шестиугольники ----
    /** Радиус шестиугольника по горизонтали, тайлы (от центра до острой вершины). */
    public int radius = 36;
    /** Сплющивание по вертикали: 1.15 ≈ правильный шестиугольник, больше — площе, меньше — выше. */
    public float squash = 1.15f;
    /** Сколько шестиугольников добавить вокруг центрального (1..6). */
    public int satellites = 3;
    /** Расстояние от центра до центров дополнительных шестиугольников; 0 = авто (касание + gap). */
    public int distance = 0;
    /** Зазор между краями шестиугольников при авто-расстоянии (тайлы). */
    public int gap = 10;
    /** Направление на первый дополнительный шестиугольник, градусы (0 = вправо, 90 = вверх). */
    public float angle = 90f;
    /** Ширина проходов между шестиугольниками (0 = без проходов, шестиугольники изолированы). */
    public int corridorWidth = 10;
    /** Соединить проходами и соседние дополнительные шестиугольники друг с другом. */
    public boolean ringCorridors = false;

    // ---- точки спавна ----
    /** Точка спавна в центральном шестиугольнике. */
    public boolean centerSpawn = true;
    /** Раздача точек командам: center_vs_ring, ring_vs_center, alternate. */
    public String teamAssign = "center_vs_ring";
    /** Сдвиг точки от центра шестиугольника наружу, доли радиуса (0 = ровно в центре). */
    public float spawnOffset = 0f;
    /** Ставить ядро на точки спавна (без ядра у игроков враги не знают, куда идти). */
    public boolean coresAtSpawns = true;
    /** Чьи точки спавна получают ядро: alpha (игроки в «Выживании»), bravo или both. */
    public String coreTeam = "alpha";
    /** Заменить существующие точки спавна сгенерированными. */
    public boolean replaceSpawns = true;

    // ---- рельеф ----
    public String floor = "stone";
    public String floorAlt = "basalt";
    /** Доля альтернативного пола 0..1. */
    public float floorAltShare = 0.35f;
    public String wall = "stone-wall";
    public String outsideFloor = "stone";
    /** Пол под точкой спавна (круг радиусом 4); пусто = не рисовать. */
    public String padFloor = "metal-floor";
    /** Плотность препятствий (стен-пятен) внутри шестиугольников, 0 = нет. */
    public float obstacles = 0.16f;
    /** Размер пятен препятствий, тайлы. */
    public int obstacleScale = 9;
    /** Радиус свободной зоны вокруг точки спавна (тайлы). */
    public int spawnClear = 12;
    /** Неровность краёв шестиугольников, 0 = идеально ровные. */
    public float edgeRoughness = 0.22f;
    /** Руды в каждом шестиугольнике: «руда:скоплений:размер», через запятую. */
    public String ores = "ore-copper:3:5,ore-lead:3:5,ore-coal:2:4,ore-titanium:1:4,ore-scrap:1:3";
    /** Пол у краёв арен и проходов (переход к стенам); пусто = не рисовать. */
    public String rimFloor = "darksand";
    /** Плотность валунов-украшений на полу, 0 = нет. */
    public float decor = 0.012f;
    /** Зерно генерации; 0 = случайное при каждом запуске. */
    public long seed = 0;

    /** Приводит значения к допустимым (после ручной правки файла). */
    public void sanitize() {
        width = clamp(width, 0, 800);
        height = clamp(height, 0, 800);
        margin = clamp(margin, 2, 100);
        radius = clamp(radius, 8, 150);
        squash = clamp(squash, 0.5f, 3f);
        satellites = clamp(satellites, 1, 6);
        distance = clamp(distance, 0, 600);
        gap = clamp(gap, 0, 100);
        corridorWidth = clamp(corridorWidth, 0, 40);
        spawnOffset = clamp(spawnOffset, 0f, 0.9f);
        floorAltShare = clamp(floorAltShare, 0f, 1f);
        obstacles = clamp(obstacles, 0f, 0.5f);
        obstacleScale = clamp(obstacleScale, 3, 30);
        spawnClear = clamp(spawnClear, 2, 40);
        edgeRoughness = clamp(edgeRoughness, 0f, 0.5f);
        if (teamAssign == null) teamAssign = "center_vs_ring";
        teamAssign = teamAssign.toLowerCase();
        if (!teamAssign.equals("center_vs_ring") && !teamAssign.equals("ring_vs_center") && !teamAssign.equals("alternate"))
            teamAssign = "center_vs_ring";
        if (floor == null || floor.isEmpty()) floor = "stone";
        if (wall == null || wall.isEmpty()) wall = "stone-wall";
        if (outsideFloor == null || outsideFloor.isEmpty()) outsideFloor = floor;
        if (floorAlt == null) floorAlt = "";
        if (padFloor == null) padFloor = "";
        if (rimFloor == null) rimFloor = "";
        decor = clamp(decor, 0f, 0.1f);
        if (coreTeam == null) coreTeam = "alpha";
        coreTeam = coreTeam.toLowerCase();
        if (!coreTeam.equals("alpha") && !coreTeam.equals("bravo") && !coreTeam.equals("both")) coreTeam = "alpha";
        if (ores == null) ores = "";
    }

    private static int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }
    private static float clamp(float v, float lo, float hi) { return Math.max(lo, Math.min(hi, v)); }
}
