package rawwar.mapgen;

import mindustry.gen.Call;
import mindustry.gen.Player;
import mindustry.ui.Menus;
import rawwar.core.CoreManager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Меню генератора карты (/mapgen): основные параметры кнопками «−/+», переключатели, пресеты размера и запуск.
 * Остальные настройки — командой /mapgen set <ключ> <значение> (список: /mapgen keys).
 */
public class MapGenMenu {
    private static class State {
        List<Runnable> actions = new ArrayList<>();
        boolean confirm;
        String notice = "";
    }

    private final CoreManager core;
    private final Map<String, State> states = new HashMap<>();
    private int menuId = -1;

    public MapGenMenu(CoreManager core) { this.core = core; }

    public void load() {
        if (menuId == -1) menuId = Menus.registerMenu(this::onChoice);
    }

    public void open(Player p) {
        if (!core.isAdmin(p)) { p.sendMessage("[scarlet]Нет доступа."); return; }
        State s = new State();
        states.put(p.uuid(), s);
        show(p, s);
    }

    /** Закрыть без скрытия окна (при выходе игрока). */
    public void forget(Player p) { states.remove(p.uuid()); }

    private void onChoice(Player p, int option) {
        State s = states.get(p.uuid());
        if (s == null || option < 0 || option >= s.actions.size()) return; // окно закрыто игроком
        if (!core.isAdmin(p)) { states.remove(p.uuid()); return; }
        s.actions.get(option).run();
    }

    private void again(Player p, State s) { s.confirm = false; show(p, s); }

    private void show(Player p, State s) {
        s.actions = new ArrayList<>();
        List<String[]> rows = new ArrayList<>();
        MapGenManager mg = core.mapgen;
        String title, text;

        if (s.confirm) {
            title = "СОЗДАТЬ КАРТУ?";
            text = "[scarlet]Текущая карта будет заменена, матч остановится, все игроки перезагрузят мир.\n"
                    + "[accent]Точки спавна " + (mg.cfg.replaceSpawns ? "будут заменены" : "будут добавлены") + " сгенерированными.\n\n"
                    + mg.summary();
            rows.add(new String[]{"[lime]Да, создать"});
            s.actions.add(() -> {
                String err = mg.generate(null);
                if (err != null) { s.notice = "[scarlet]" + err + "\n"; again(p, s); return; }
                states.remove(p.uuid());
                p.sendMessage(mg.lastInfo());
            });
            rows.add(new String[]{"Отмена"});
            s.actions.add(() -> again(p, s));
        } else {
            title = "ГЕНЕРАТОР КАРТЫ";
            text = s.notice + mg.summary() + "\n[gray]Остальные настройки: /mapgen keys";
            s.notice = "";
            rows.add(new String[]{"[lime]Сгенерировать карту"});
            s.actions.add(() -> { s.confirm = true; show(p, s); });

            for (String key : MapGenManager.MENU_KEYS) {
                final MapGenManager.Param pr = MapGenManager.param(key);
                if (pr == null) continue;
                rows.add(new String[]{"[-]", "[accent]" + shortLabel(key) + ": [white]" + mg.value(pr), "[+]"});
                s.actions.add(() -> { mg.adjust(key, -1); again(p, s); });
                s.actions.add(() -> again(p, s));
                s.actions.add(() -> { mg.adjust(key, +1); again(p, s); });
            }

            rows.add(new String[]{"Команды: " + mg.value(MapGenManager.param("teamAssign"))});
            s.actions.add(() -> { mg.cycle("teamAssign"); again(p, s); });
            rows.add(new String[]{"Спавн в центре: " + mg.value(MapGenManager.param("centerSpawn")),
                    "Ядра на спавнах: " + mg.value(MapGenManager.param("coresAtSpawns"))});
            s.actions.add(() -> { mg.cycle("centerSpawn"); again(p, s); });
            s.actions.add(() -> { mg.cycle("coresAtSpawns"); again(p, s); });

            rows.add(new String[]{"Малая", "Средняя", "Большая"});
            s.actions.add(() -> { mg.preset("small"); again(p, s); });
            s.actions.add(() -> { mg.preset("medium"); again(p, s); });
            s.actions.add(() -> { mg.preset("large"); again(p, s); });

            rows.add(new String[]{"Сбросить настройки"});
            s.actions.add(() -> { mg.reset(); again(p, s); });
            rows.add(new String[]{"Закрыть"});
            s.actions.add(() -> states.remove(p.uuid()));
        }
        Call.menu(p.con, menuId, title, text, rows.toArray(new String[0][]));
    }

    private static String shortLabel(String key) {
        switch (key) {
            case "radius": return "Радиус";
            case "squash": return "Сплющ.";
            case "satellites": return "Доп.";
            case "distance": return "Дистанц.";
            case "corridorWidth": return "Проход";
            case "obstacles": return "Препятств.";
            case "spawnOffset": return "Сдвиг спавна";
            default: return key;
        }
    }
}
