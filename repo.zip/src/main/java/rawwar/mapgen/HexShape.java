package rawwar.mapgen;

/**
 * Геометрия сплюснутого шестиугольника (плоская вершина сверху/снизу, острые углы слева/справа).
 *
 * Основана на isInsideHexagonSquashed: координаты точки переводятся в кубические координаты гекс-сетки,
 * расстояние = (|x| + |y| + |z|) / 2. Здесь считается без округления до целых, поэтому края получаются
 * симметричными (с целочисленным (int) и Math.round фигура немного «плывёт» на нечётных размерах).
 *
 * Размеры фигуры при радиусе R и сплющивании s:
 *   по горизонтали — от -R до +R (острые вершины);
 *   по вертикали — от -R/s до +R/s.
 * s = 1.1547 (2/sqrt(3)) даёт правильный шестиугольник, s больше — более плоский, меньше — более вытянутый.
 */
public final class HexShape {
    private HexShape() {}

    /** Расстояние от центра в «шагах гекс-сетки»: &lt;= radius — внутри, = radius — на границе. */
    public static float hexDistance(float cx, float cy, float x, float y, float squash) {
        float dx = x - cx;
        float dy = (y - cy) * squash;

        float q = -dy;            // кубическая X
        float r = dx + dy / 2f;   // кубическая Z
        float s = -q - r;         // кубическая Y
        return (Math.abs(q) + Math.abs(r) + Math.abs(s)) / 2f;
    }

    /** Проверяет, находится ли точка внутри сплюснутого шестиугольника. */
    public static boolean isInsideHexagonSquashed(int cx, int cy, int radius, int x, int y, float squash) {
        return hexDistance(cx, cy, x, y, squash) <= radius;
    }

    /** Расстояние от центра до границы шестиугольника в направлении angleRad (в тайлах). */
    public static double boundaryRadius(double radius, double squash, double angleRad) {
        double ca = Math.cos(angleRad), sa = Math.sin(angleRad);
        double dy = sa * squash;
        double m = Math.max(Math.abs(dy), Math.max(Math.abs(ca + dy / 2.0), Math.abs(ca - dy / 2.0)));
        return m <= 1e-9 ? radius : radius / m;
    }

    /** Расстояние от точки (px, py) до отрезка (ax, ay)-(bx, by). */
    public static float distToSegment(float px, float py, float ax, float ay, float bx, float by) {
        float vx = bx - ax, vy = by - ay;
        float len2 = vx * vx + vy * vy;
        float t = len2 <= 1e-6f ? 0f : ((px - ax) * vx + (py - ay) * vy) / len2;
        t = Math.max(0f, Math.min(1f, t));
        float qx = ax + vx * t, qy = ay + vy * t;
        float ex = px - qx, ey = py - qy;
        return (float) Math.sqrt(ex * ex + ey * ey);
    }
}
