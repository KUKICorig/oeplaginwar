package rawwar.mapgen;

import arc.util.Log;
import mindustry.Vars;
import mindustry.content.Blocks;
import mindustry.world.Block;
import mindustry.world.Tile;
import mindustry.world.Tiles;
import mindustry.world.blocks.environment.Floor;
import mindustry.world.blocks.environment.OverlayFloor;
import rawwar.core.CoreManager;
import rawwar.teams.RwTeam;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;

/**
 * Заполняет тайлы карты по раскладке HexLayout: шестиугольные арены, проходы между ними, препятствия,
 * руды, площадки под точками спавна и (по желанию) ядра. Вызывается внутри World.loadGenerator.
 */
public final class MapGenerator {
    private MapGenerator() {}

    private static final int PAD_RADIUS = 4;

    private static final class OreSpec {
        final Block block; final int clusters, size;
        OreSpec(Block block, int clusters, int size) { this.block = block; this.clusters = clusters; this.size = size; }
    }

    private static final class Cluster {
        final int x, y, r; final Block ore;
        Cluster(int x, int y, int r, Block ore) { this.x = x; this.y = y; this.r = r; this.ore = ore; }
    }

    // ---------- разбор блоков ----------
    private static Block find(String name) {
        if (name == null || name.trim().isEmpty()) return null;
        return Vars.content.block(name.trim());
    }

    private static Block floorOf(String name, Block def) {
        Block b = find(name);
        if (b == null || !(b instanceof Floor)) {
            if (name != null && !name.trim().isEmpty()) Log.warn("[RawWar] mapgen: '" + name + "' — не пол, использую " + (def == null ? "ничего" : def.name));
            return def;
        }
        return b;
    }

    private static Block wallOf(String name, Block def) {
        Block b = find(name);
        if (b == null) {
            Log.warn("[RawWar] mapgen: неизвестный блок стены '" + name + "', использую " + def.name);
            return def;
        }
        return b;
    }

    /** Разбор строки ores. Неверные записи пропускаются; ошибки добавляются в errors (может быть null). */
    static List<OreSpec> parseOres(String s, List<String> errors) {
        List<OreSpec> out = new ArrayList<>();
        if (s == null || s.trim().isEmpty()) return out;
        for (String part : s.split(",")) {
            String p = part.trim();
            if (p.isEmpty()) continue;
            String[] f = p.split(":");
            Block b = find(f[0]);
            if (b == null || !(b instanceof OverlayFloor)) {
                if (errors != null) errors.add("руда '" + f[0] + "' не найдена");
                continue;
            }
            int clusters = 2, size = 4;
            try {
                if (f.length > 1) clusters = Integer.parseInt(f[1].trim());
                if (f.length > 2) size = Integer.parseInt(f[2].trim());
            } catch (NumberFormatException e) {
                if (errors != null) errors.add("в записи '" + p + "' нужны числа (руда:скоплений:размер)");
                continue;
            }
            out.add(new OreSpec(b, Math.max(0, Math.min(20, clusters)), Math.max(1, Math.min(20, size))));
        }
        return out;
    }

    /** Проверка названий блоков из настроек: список проблем (пустой = всё в порядке). */
    public static List<String> check(MapGenConfig c) {
        List<String> errors = new ArrayList<>();
        if (Vars.content == null) return errors;
        if (!(find(c.floor) instanceof Floor)) errors.add("floor '" + c.floor + "' не найден (пример: stone, sand-floor, grass, basalt)");
        if (!c.floorAlt.isEmpty() && !(find(c.floorAlt) instanceof Floor)) errors.add("floorAlt '" + c.floorAlt + "' не найден");
        if (!(find(c.outsideFloor) instanceof Floor)) errors.add("outsideFloor '" + c.outsideFloor + "' не найден");
        if (!c.padFloor.isEmpty() && !(find(c.padFloor) instanceof Floor)) errors.add("padFloor '" + c.padFloor + "' не найден");
        if (find(c.wall) == null) errors.add("wall '" + c.wall + "' не найден (пример: stone-wall, dirt-wall, sand-wall)");
        parseOres(c.ores, errors);
        return errors;
    }

    // ---------- генерация ----------
    /**
     * Заполняет tiles (карта уже изменена до нужного размера).
     * Форма арен и проходов искажается крупным шумом (края органичные, не по линейке), у краёв — переходный пол,
     * руды растут неровными пятнами, на полу разбросаны валуны. Ядра ставятся не здесь, а после загрузки мира
     * (MapGenManager.ensureCores) — так они гарантированно регистрируются в игре.
     */
    public static void fill(Tiles tiles, MapGenConfig c, HexLayout lay, long seed, CoreManager core) {
        final int W = lay.width, H = lay.height;
        final float R = c.radius, sq = c.squash;

        final Block floor = floorOf(c.floor, Blocks.stone);
        final Block floorAlt = c.floorAltShare <= 0f ? null : floorOf(c.floorAlt, null);
        final Block outside = floorOf(c.outsideFloor, floor);
        final Block pad = floorOf(c.padFloor, null);
        final Block rim = floorOf(c.rimFloor, null);
        final Block wall = wallOf(c.wall, Blocks.stoneWall);
        final Block boulder = c.decor > 0f ? find("boulder") : null;
        final Block air = Blocks.air;

        // отрезки проходов
        List<float[]> segs = new ArrayList<>();
        for (int[] pair : lay.corridors()) {
            HexLayout.Hex a = lay.hexes.get(pair[0]), b = lay.hexes.get(pair[1]);
            segs.add(new float[]{a.cx, a.cy, b.cx, b.cy});
        }
        final float halfCorridor = c.corridorWidth / 2f;
        // крупное искажение формы: чем больше edgeRoughness, тем сильнее «плывут» края (в тайлах)
        final float warp = c.edgeRoughness * R * 0.35f;

        // руды: скопления вокруг центров шестиугольников, вдали от точек спавна
        List<Cluster> clusters = new ArrayList<>();
        Random rnd = new Random(seed ^ 0xC0FFEEL);
        for (OreSpec o : parseOres(c.ores, null)) {
            for (HexLayout.Hex h : lay.hexes) {
                for (int k = 0; k < o.clusters; k++) {
                    for (int attempt = 0; attempt < 14; attempt++) {
                        double a = rnd.nextDouble() * Math.PI * 2.0, f = 0.25 + rnd.nextDouble() * 0.55;
                        int px = (int) Math.round(h.cx + Math.cos(a) * f * R);
                        int py = (int) Math.round(h.cy + Math.sin(a) * f * R / sq);
                        if (HexShape.hexDistance(h.cx, h.cy, px, py, sq) / R > 0.8f) continue;
                        if (nearSpawn(lay, px, py, c.spawnClear + o.size + 2)) continue;
                        clusters.add(new Cluster(px, py, o.size, o.block));
                        break;
                    }
                }
            }
        }

        for (int y = 0; y < H; y++) {
            for (int x = 0; x < W; x++) {
                // искажённые координаты: арены и проходы получаются неровными
                float wx = x, wy = y;
                if (warp > 0f) {
                    wx += (Noise.fbm(seed ^ 0x1111L, x / 22f, y / 22f, 3) - 0.5f) * 2f * warp;
                    wy += (Noise.fbm(seed ^ 0x2222L, x / 22f + 57f, y / 22f + 57f, 3) - 0.5f) * 2f * warp;
                }

                float dMin = Float.MAX_VALUE;
                for (HexLayout.Hex h : lay.hexes) dMin = Math.min(dMin, HexShape.hexDistance(h.cx, h.cy, wx, wy, sq) / R);

                float cd = Float.MAX_VALUE;
                for (float[] s : segs) cd = Math.min(cd, HexShape.distToSegment(wx, wy, s[0], s[1], s[2], s[3]));
                boolean inCorridor = c.corridorWidth > 0 && cd <= halfCorridor;

                // мелкая «рваность» края поверх крупного искажения
                float rough = c.edgeRoughness > 0f ? (Noise.fbm(seed ^ 0x5151L, x / 9f, y / 9f, 3) - 0.5f) * c.edgeRoughness : 0f;
                float edge = dMin + rough;            // <= 1 — внутри арены
                boolean inHex = edge <= 1f;
                boolean open = inHex || inCorridor;

                Block f = open ? floor : outside;
                Block w = open ? air : wall;
                int ore = air.id;

                if (open) {
                    if (floorAlt != null) {
                        float fn = Noise.fbm(seed ^ 0x7777L, x / 14f, y / 14f, 3);
                        if (c.floorAltShare >= 1f || fn > 0.8f - c.floorAltShare * 0.6f) f = floorAlt;
                    }
                    // переход к стенам: у самого края арены и у границы прохода — другой пол
                    if (rim != null) {
                        boolean nearEdge = inHex ? edge > 0.88f : cd > halfCorridor * 0.7f;
                        if (nearEdge) f = rim;
                    }
                    if (pad != null && nearTeamSpawn(lay, x, y, PAD_RADIUS)) f = pad;

                    if (inHex && !inCorridor && c.obstacles > 0f && dMin < 0.92f
                            && (c.corridorWidth <= 0 || cd > halfCorridor + 3f)
                            && !nearSpawn(lay, x, y, c.spawnClear)) {
                        float n = Noise.fbm(seed ^ 0xA5A5L, x / (float) c.obstacleScale, y / (float) c.obstacleScale, 3);
                        if (n > 0.78f - c.obstacles * 0.6f) w = wall;
                    }

                    if (w == air) {
                        for (Cluster cl : clusters) {
                            int dx = x - cl.x, dy = y - cl.y;
                            // неровное пятно вместо идеального круга
                            float rr = cl.r * (0.6f + 0.8f * Noise.fbm(seed ^ 0x3333L, x / 4f, y / 4f, 2));
                            if (dx * dx + dy * dy <= rr * rr && Noise.rand(seed ^ 0x0E0EL, x, y) < 0.9f) { ore = cl.ore.id; break; }
                        }
                    }

                    // валуны: только на чистом полу, не в проходах и не у спавнов
                    if (w == air && ore == air.id && boulder != null && !inCorridor
                            && !nearSpawn(lay, x, y, c.spawnClear)
                            && Noise.rand(seed ^ 0xB0B0L, x, y) < c.decor) {
                        w = boulder;
                    }
                }
                tiles.set(x, y, new Tile(x, y, f.id, ore, w.id));
            }
        }
    }

    private static boolean nearSpawn(HexLayout lay, int x, int y, int r) {
        for (HexLayout.Hex h : lay.hexes) {
            int dx = x - h.spawnX, dy = y - h.spawnY;
            if (dx * dx + dy * dy <= r * r) return true;
        }
        return false;
    }

    private static boolean nearTeamSpawn(HexLayout lay, int x, int y, int r) {
        for (HexLayout.Hex h : lay.hexes) {
            if (h.team.isEmpty()) continue;
            int dx = x - h.spawnX, dy = y - h.spawnY;
            if (dx * dx + dy * dy <= r * r) return true;
        }
        return false;
    }

    /** Короткое описание для логов. */
    public static String describe(HexLayout lay) {
        return String.format(Locale.ROOT, "%dx%d, шестиугольников: %d", lay.width, lay.height, lay.hexes.size());
    }
}
