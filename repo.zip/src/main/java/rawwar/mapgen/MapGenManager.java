package rawwar.mapgen;

import arc.files.Fi;
import arc.util.Log;
import arc.util.Timer;
import mindustry.Vars;
import mindustry.content.Blocks;
import mindustry.game.Rules;
import mindustry.gen.Call;
import mindustry.gen.Groups;
import mindustry.gen.Player;
import rawwar.core.CoreManager;
import rawwar.data.JsonIO;
import rawwar.spawn.SpawnPoint;
import rawwar.teams.RwTeam;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Map Generator: настройки (config/mapgen.json), раскладка шестиугольников и пересоздание карты.
 * Команда: /mapgen (меню), /mapgen set|show|keys|preset|reset|generate.
 */
public class MapGenManager {

    public enum Kind { INT, LONG, FLOAT, BOOL, TEXT, CHOICE }

    /** Описание настройки: ключ = имя поля MapGenConfig. */
    public static final class Param {
        public final String key, label;
        public final Kind kind;
        public final double min, max, step;
        public final String[] options;
        public final boolean optional; // TEXT: можно очистить значением "-"

        Param(String key, String label, Kind kind, double min, double max, double step, String[] options, boolean optional) {
            this.key = key; this.label = label; this.kind = kind; this.min = min; this.max = max; this.step = step;
            this.options = options; this.optional = optional;
        }
    }

    public static final List<Param> PARAMS = new ArrayList<>();
    private static void i(String k, String l, int min, int max, int step) { PARAMS.add(new Param(k, l, Kind.INT, min, max, step, null, false)); }
    private static void f(String k, String l, double min, double max, double step) { PARAMS.add(new Param(k, l, Kind.FLOAT, min, max, step, null, false)); }
    private static void b(String k, String l) { PARAMS.add(new Param(k, l, Kind.BOOL, 0, 1, 1, null, false)); }
    private static void t(String k, String l, boolean opt) { PARAMS.add(new Param(k, l, Kind.TEXT, 0, 0, 0, null, opt)); }
    private static void c(String k, String l, String... opts) { PARAMS.add(new Param(k, l, Kind.CHOICE, 0, 0, 0, opts, false)); }

    static {
        // форма
        i("radius", "Радиус шестиугольника, тайлов", 8, 150, 5);
        f("squash", "Сплющивание по вертикали (1.15 = правильный шестиугольник)", 0.5, 3, 0.05);
        i("satellites", "Сколько шестиугольников добавить к центральному", 1, 6, 1);
        i("distance", "Расстояние от центра до добавленных, тайлов (0 = авто)", 0, 600, 5);
        i("gap", "Зазор между шестиугольниками при авто-расстоянии", 0, 100, 2);
        f("angle", "Направление на первый добавленный, градусы (90 = вверх)", -360, 360, 15);
        i("corridorWidth", "Ширина проходов между шестиугольниками (0 = нет)", 0, 40, 1);
        b("ringCorridors", "Проходы и между соседними добавленными");
        i("width", "Ширина карты, тайлов (0 = авто)", 0, 800, 10);
        i("height", "Высота карты, тайлов (0 = авто)", 0, 800, 10);
        i("margin", "Отступ до края карты при авторазмере", 2, 100, 2);
        // спавны
        b("centerSpawn", "Точка спавна в центральном шестиугольнике");
        c("teamAssign", "Раздача точек командам", "center_vs_ring", "ring_vs_center", "alternate");
        f("spawnOffset", "Сдвиг спавна от центра шестиугольника наружу (доли радиуса)", 0, 0.9, 0.05);
        b("coresAtSpawns", "Ставить ядро на точки спавна");
        c("coreTeam", "Чьим точкам спавна ставить ядро", "alpha", "bravo", "both");
        b("replaceSpawns", "Заменять существующие точки спавна");
        // рельеф
        t("floor", "Основной пол (например stone, grass, sand-floor)", false);
        t("floorAlt", "Дополнительный пол (- = выключить)", true);
        f("floorAltShare", "Доля дополнительного пола", 0, 1, 0.05);
        t("wall", "Стены (например stone-wall, dirt-wall)", false);
        t("outsideFloor", "Пол под стенами снаружи", false);
        t("padFloor", "Пол площадки спавна (- = нет)", true);
        f("obstacles", "Плотность препятствий внутри", 0, 0.5, 0.02);
        i("obstacleScale", "Размер пятен препятствий", 3, 30, 1);
        i("spawnClear", "Свободная зона вокруг спавна, тайлов", 2, 40, 1);
        f("edgeRoughness", "Неровность краёв", 0, 0.5, 0.02);
        t("rimFloor", "Пол у краёв арен (- = нет)", true);
        f("decor", "Плотность валунов-украшений", 0, 0.1, 0.004);
        t("ores", "Руды: руда:скоплений:размер через запятую (- = без руд)", true);
        PARAMS.add(new Param("seed", "Зерно генерации (0 = случайное)", Kind.LONG, 0, Long.MAX_VALUE, 1, null, false));
    }

    /** Основные параметры для кнопок «−/+» в меню. */
    public static final String[] MENU_KEYS = {"radius", "squash", "satellites", "distance", "corridorWidth", "obstacles", "spawnOffset"};

    private final CoreManager core;
    public MapGenConfig cfg = new MapGenConfig();
    private String lastInfo = "";

    public MapGenManager(CoreManager core) { this.core = core; }

    private Fi file() { return core.root.child("config").child("mapgen.json"); }

    public void load() {
        cfg = JsonIO.read(file(), MapGenConfig.class, MapGenConfig::new);
        cfg.sanitize();
    }

    public void save() { JsonIO.write(file(), cfg); }

    public String lastInfo() { return lastInfo; }

    // ---------- настройки ----------
    public static Param param(String key) {
        if (key == null) return null;
        for (Param p : PARAMS) if (p.key.equalsIgnoreCase(key.trim())) return p;
        return null;
    }

    private Field field(Param p) throws NoSuchFieldException { return MapGenConfig.class.getField(p.key); }

    public static String fmt(double v) {
        String s = String.format(Locale.ROOT, "%.2f", v);
        if (s.indexOf('.') >= 0) s = s.replaceAll("0+$", "").replaceAll("\\.$", "");
        return s;
    }

    /** Текущее значение настройки текстом. */
    public String value(Param p) {
        try {
            Object v = field(p).get(cfg);
            if (v instanceof Float) return fmt((Float) v);
            if (v instanceof Boolean) return ((Boolean) v) ? "да" : "нет";
            String s = String.valueOf(v);
            return s.isEmpty() ? "-" : s;
        } catch (Throwable e) {
            return "?";
        }
    }

    /** Меняет настройку. Возвращает null при успехе или текст ошибки. */
    public String set(String key, String raw) {
        Param p = param(key);
        if (p == null) return "Нет настройки '" + key + "'. Список: /mapgen keys";
        if (raw == null) raw = "";
        raw = raw.trim();
        try {
            Field fld = field(p);
            Object old = fld.get(cfg);
            List<String> before = p.kind == Kind.TEXT ? MapGenerator.check(cfg) : null;
            switch (p.kind) {
                case INT: {
                    int v = Integer.parseInt(raw);
                    if (v < p.min || v > p.max) return p.key + ": допустимо " + (int) p.min + ".." + (int) p.max;
                    fld.setInt(cfg, v);
                    break;
                }
                case LONG: {
                    long v = Long.parseLong(raw);
                    if (v < 0) return p.key + ": нужно число 0 или больше";
                    fld.setLong(cfg, v);
                    break;
                }
                case FLOAT: {
                    float v = Float.parseFloat(raw.replace(',', '.'));
                    if (v < p.min || v > p.max) return p.key + ": допустимо " + fmt(p.min) + ".." + fmt(p.max);
                    fld.setFloat(cfg, v);
                    break;
                }
                case BOOL: {
                    String s = raw.toLowerCase(Locale.ROOT);
                    boolean v;
                    if (s.equals("true") || s.equals("on") || s.equals("1") || s.equals("да") || s.equals("yes")) v = true;
                    else if (s.equals("false") || s.equals("off") || s.equals("0") || s.equals("нет") || s.equals("no")) v = false;
                    else return p.key + ": нужно да/нет (true/false, on/off)";
                    fld.setBoolean(cfg, v);
                    break;
                }
                case CHOICE: {
                    String s = raw.toLowerCase(Locale.ROOT);
                    boolean ok = false;
                    for (String o : p.options) if (o.equals(s)) ok = true;
                    if (!ok) return p.key + ": допустимо " + String.join(", ", p.options);
                    fld.set(cfg, s);
                    break;
                }
                default: {
                    String s = (raw.equals("-") || raw.equalsIgnoreCase("none")) ? "" : raw;
                    if (s.isEmpty() && !p.optional) return p.key + ": значение не может быть пустым";
                    fld.set(cfg, s);
                    List<String> after = MapGenerator.check(cfg);
                    if (after.size() > before.size()) {
                        fld.set(cfg, old);
                        return after.get(after.size() - 1);
                    }
                }
            }
            cfg.sanitize();
            save();
            return null;
        } catch (NumberFormatException e) {
            return p.key + ": нужно число, получено '" + raw + "'";
        } catch (Throwable e) {
            return "Не удалось изменить " + p.key + ": " + e;
        }
    }

    /** Шаг «−/+» для меню: dir = -1 или +1. */
    public void adjust(String key, int dir) {
        Param p = param(key);
        if (p == null) return;
        try {
            Field fld = field(p);
            if (p.kind == Kind.INT) {
                int v = (int) Math.round(Math.max(p.min, Math.min(p.max, fld.getInt(cfg) + dir * p.step)));
                fld.setInt(cfg, v);
            } else if (p.kind == Kind.FLOAT) {
                double v = fld.getFloat(cfg) + dir * p.step;
                v = Math.round(v / p.step) * p.step;
                fld.setFloat(cfg, (float) Math.max(p.min, Math.min(p.max, v)));
            }
            cfg.sanitize();
            save();
        } catch (Throwable e) {
            Log.err("[RawWar] mapgen adjust: " + e);
        }
    }

    /** Переключает BOOL или следующий вариант CHOICE. */
    public void cycle(String key) {
        Param p = param(key);
        if (p == null) return;
        try {
            Field fld = field(p);
            if (p.kind == Kind.BOOL) fld.setBoolean(cfg, !fld.getBoolean(cfg));
            else if (p.kind == Kind.CHOICE) {
                String cur = String.valueOf(fld.get(cfg));
                int idx = 0;
                for (int k = 0; k < p.options.length; k++) if (p.options[k].equals(cur)) idx = k;
                fld.set(cfg, p.options[(idx + 1) % p.options.length]);
            }
            cfg.sanitize();
            save();
        } catch (Throwable e) {
            Log.err("[RawWar] mapgen cycle: " + e);
        }
    }

    public void reset() {
        cfg = new MapGenConfig();
        save();
    }

    /** Размерные пресеты. Возвращает false, если такого нет. */
    public boolean preset(String name) {
        int r, gap, cw, scale, clear;
        switch (name == null ? "" : name.toLowerCase(Locale.ROOT)) {
            case "small": case "малая": case "s": r = 25; gap = 8; cw = 6; scale = 7; clear = 9; break;
            case "medium": case "средняя": case "m": r = 40; gap = 12; cw = 8; scale = 9; clear = 12; break;
            case "large": case "большая": case "l": r = 60; gap = 16; cw = 10; scale = 11; clear = 14; break;
            default: return false;
        }
        cfg.radius = r; cfg.gap = gap; cfg.corridorWidth = cw; cfg.obstacleScale = scale; cfg.spawnClear = clear;
        cfg.distance = 0; cfg.width = 0; cfg.height = 0;
        cfg.sanitize();
        save();
        return true;
    }

    /** Список ключей с текущими значениями и допустимыми пределами. */
    public String keysText() {
        StringBuilder sb = new StringBuilder("[accent]Настройки генератора[white] (/mapgen set <ключ> <значение>):\n");
        for (Param p : PARAMS) {
            String range;
            switch (p.kind) {
                case INT: range = (int) p.min + ".." + (int) p.max; break;
                case FLOAT: range = fmt(p.min) + ".." + fmt(p.max); break;
                case BOOL: range = "да/нет"; break;
                case CHOICE: range = String.join("|", p.options); break;
                case LONG: range = "число"; break;
                default: range = "текст";
            }
            sb.append("[accent]").append(p.key).append("[white] = ").append(value(p)).append(" [gray](").append(range).append(") ").append(p.label).append("\n");
        }
        return sb.toString().trim();
    }

    // ---------- раскладка ----------
    private String teamName(String id) {
        RwTeam t = core.teams.byId(id);
        return t == null ? id : t.name;
    }

    /** Сводка: размер карты, расстояния и точки спавна (для чата, консоли и меню). */
    public String summary() {
        HexLayout lay = HexLayout.compute(cfg);
        StringBuilder sb = new StringBuilder();
        sb.append("[accent]Карта: [white]").append(lay.width).append("x").append(lay.height).append(lay.autoSize ? " (авто)" : "").append("\n");
        sb.append("[accent]Шестиугольников: [white]").append(lay.hexes.size()).append(" (центр + ").append(cfg.satellites)
          .append("), радиус ").append(cfg.radius).append(", сплющивание ").append(fmt(cfg.squash)).append("\n");
        sb.append("[accent]Центр — добавленные: [white]").append(Math.round(lay.distance)).append(" тайлов").append(lay.autoDistance ? " (авто)" : "").append("\n");
        if (lay.hexes.size() > 2)
            sb.append("[accent]Между соседями по кругу: [white]").append(Math.round(lay.ringSpacing())).append(" тайлов (одинаково для всех)\n");
        for (String id : new String[]{HexLayout.ALPHA, HexLayout.BRAVO}) {
            sb.append("[accent]").append(teamName(id)).append(" (").append(lay.count(id)).append("): [white]");
            boolean first = true;
            for (HexLayout.Hex h : lay.hexes) {
                if (!id.equals(h.team)) continue;
                if (!first) sb.append("; ");
                sb.append(h.spawnX).append(",").append(h.spawnY);
                first = false;
            }
            if (first) sb.append("нет");
            sb.append("\n");
        }
        sb.append("[accent]Зерно: [white]").append(cfg.seed == 0 ? "случайное" : String.valueOf(cfg.seed));
        for (String w : lay.warnings) sb.append("\n[scarlet]").append(w);
        List<String> errs = MapGenerator.check(cfg);
        for (String e : errs) sb.append("\n[scarlet]").append(e);
        return sb.toString();
    }

    /** Ставит ядра на точки спавна нужной команды (после загрузки мира, до отправки мира игрокам). */
    private void ensureCores(HexLayout lay) {
        if (!cfg.coresAtSpawns) return;
        for (HexLayout.Hex h : lay.hexes) {
            if (h.team.isEmpty()) continue;
            if (!"both".equals(cfg.coreTeam) && !h.team.equals(cfg.coreTeam)) continue;
            RwTeam t = core.teams.byId(h.team);
            if (t == null || Vars.state.teams.cores(t.team).size > 0) continue;
            mindustry.world.Tile ct = Vars.world.tile(h.spawnX, h.spawnY);
            if (ct != null) ct.setNet(Blocks.coreShard, t.team, 0);
        }
    }

    // ---------- генерация ----------
    /**
     * Создаёт карту и перезагружает мир у всех игроков. seedArg == null — зерно из настроек.
     * Возвращает null при успехе (итог — в lastInfo()) или текст ошибки.
     */
    public String generate(Long seedArg) {
        if (Vars.world == null || Vars.logic == null || Vars.netServer == null || Vars.state == null) return "Игра ещё не запущена.";
        cfg.sanitize();
        List<String> errs = MapGenerator.check(cfg);
        if (!errs.isEmpty()) return "Ошибка настроек: " + errs.get(0);
        final HexLayout lay = HexLayout.compute(cfg);
        if (!lay.fits) return lay.warnings.get(0);
        final long seed = seedArg != null ? seedArg : (cfg.seed != 0 ? cfg.seed : (System.nanoTime() & 0x7FFFFFFFFFFFL));

        if (core.modes.running()) core.modes.stop();
        core.units.clearAll();

        final List<Player> players = new ArrayList<>();
        for (Player p : Groups.player) players.add(p);

        mindustry.maps.Map prevMap = Vars.state.map;
        Rules prevRules = null;
        try { prevRules = Vars.state.rules.copy(); } catch (Throwable ignored) {}

        // порядок как у перезагрузки мира самого сервера: сброс -> данные мира -> генератор -> play -> отправка клиентам
        try {
            for (Player p : players) p.clearUnit();
            Vars.logic.reset();
            Call.worldDataBegin();
            final MapGenConfig c = cfg;
            Vars.world.loadGenerator(lay.width, lay.height, tiles -> MapGenerator.fill(tiles, c, lay, seed, core));
            Vars.logic.play();
            ensureCores(lay);
        } catch (Throwable t) {
            Log.err("[RawWar] Генерация карты не удалась", t);
            return "Не удалось создать карту: " + t;
        }
        if (Vars.state.map == null) Vars.state.map = prevMap;
        if (prevRules != null) Vars.state.rules = prevRules;

        // точки спавна
        if (cfg.replaceSpawns) {
            core.spawns.replaceAll(lay.spawns());
        } else {
            for (SpawnPoint sp : lay.spawns()) core.spawns.addPoint(sp.team, sp.x, sp.y);
        }

        // игроки загружают новый мир; юниты выдаются, когда мир загрузится
        for (Player p : players) {
            if (p.con == null) continue;
            boolean wasAdmin = p.admin;
            p.reset();
            p.admin = wasAdmin;
            RwTeam t = core.teams.of(p);
            if (t != null) p.team(t.team);
            Vars.netServer.sendWorldData(p);
        }
        core.listener.applyRules();
        Timer.schedule(() -> {
            for (Player p : players) if (p.con != null && p.con.isConnected()) core.units.autoGive(p);
        }, 3f);

        lastInfo = "[lime]Карта создана: [white]" + MapGenerator.describe(lay) + ", зерно " + seed
                + "\n[accent]Точки спавна обновлены: [white]" + core.spawns.count(HexLayout.ALPHA) + " + " + core.spawns.count(HexLayout.BRAVO);
        Log.info("[RawWar] mapgen: " + MapGenerator.describe(lay) + ", seed " + seed);
        return null;
    }
}
