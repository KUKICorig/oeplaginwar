package rawwar.events;

import arc.util.Log;
import arc.util.Timer;
import mindustry.Vars;
import mindustry.game.EventType;
import mindustry.gen.Groups;
import mindustry.gen.Player;
import mindustry.gen.Unit;
import mindustry.net.Administration;
import rawwar.core.CoreManager;
import rawwar.data.PlayerData;
import rawwar.teams.RwTeam;

/** Event System: преобразует события Mindustry в вызовы подсистем RawWar. */
public class GameEventListener {
    private final CoreManager core;
    private boolean filterInstalled;
    private Timer.Task pauseTask;
    private Timer.Task lockTask;

    public GameEventListener(CoreManager core) { this.core = core; }

    public void register() {
        core.events.on(EventType.PlayerJoin.class, e -> onJoin(e.player));
        core.events.on(EventType.PlayerLeave.class, e -> onLeave(e.player));
        core.events.on(EventType.UnitDestroyEvent.class, e -> onUnitDestroyed(e.unit));
        core.events.on(EventType.UnitBulletDestroyEvent.class, e -> onUnitKilledByBullet(e.unit, e.bullet == null ? null : e.bullet.owner));
        core.events.on(EventType.WorldLoadEvent.class, e -> {
            Timer.schedule(this::applyRules, 1f);
            // первая загруженная карта (после `host`) запускает автоцикл; дальше карты меняет сам плагин
            if (!core.bootstrapDone()) Timer.schedule(core::bootstrap, 2f);
        });
        // редактор точек спавна: нажатие на карту в режиме /rw spawn edit
        core.events.on(EventType.TapEvent.class, e -> core.spawns.onTap(e.player, e.tile));

        // Серверные команды: клиент не может самостоятельно назначить себе юнит/команду
        if (!filterInstalled) {
            filterInstalled = true;
            Vars.netServer.admins.addActionFilter(action -> {
                if (!core.config.settings.plugin.enabled) return true;
                if (action.type == Administration.ActionType.placeBlock || action.type == Administration.ActionType.breakBlock) {
                    return action.player == null || core.modes.allowBuilding(action.player);
                }
                // запрет выхода из юнита: нельзя взять под контроль другой юнит/турель и сбросить юнит в ядро
                if (action.player != null && isLeaveAction(action.type) && core.units.isLocked(action.player)) {
                    core.units.lockHint(action.player);
                    return false;
                }
                return true;
            });
        }
        // Распределение новых игроков по командам
        // v8: Vars.netServer.assigner (NetServer.TeamAssigner#assign)
        Vars.netServer.assigner = (player, players) -> {
            RwTeam t = core.teams.assign(player);
            return t.team;
        };
        applyRules();
        startPauseGuard();
        startLockGuard();
        // сервер уже держит карту (плагин загружен позже `host`) — не ждём WorldLoadEvent
        try { if (Vars.state.isGame()) Timer.schedule(core::bootstrap, 3f); } catch (Throwable ignored) {}
    }

    /**
     * Типы действий, которыми игрок покидает свой юнит. Ищем по имени, чтобы код собирался
     * и на сборках, где часть значений Administration.ActionType отсутствует.
     */
    private static boolean isLeaveAction(Administration.ActionType type) {
        if (type == null) return false;
        String n = type.name();
        return n.equals("control") || n.equals("respawn");
    }

    /** Серверная страховка запрета выхода из юнита: возвращает игрока в его юнит. */
    private void startLockGuard() {
        if (lockTask != null) lockTask.cancel();
        lockTask = Timer.schedule(() -> {
            if (core.config.settings.plugin.enabled) core.units.enforceLock();
        }, 1f, 0.25f);
    }

    /** Останавливает фоновые задачи (вызывается при остановке/выключении плагина). */
    public void stop() {
        if (pauseTask != null) { pauseTask.cancel(); pauseTask = null; }
        if (lockTask != null) { lockTask.cancel(); lockTask = null; }
    }

    /** Раз в секунду снимает паузу: игра должна идти даже с одним игроком. */
    private void startPauseGuard() {
        if (pauseTask != null) pauseTask.cancel();
        pauseTask = Timer.schedule(this::keepRunning, 1f, 1f);
    }

    /**
     * Снимает все виды паузы:
     * rules.pvpAutoPause — пауза PvP, когда игроков только одной команды (главная причина «паузы с 1 игроком»);
     * Config.autoPause — пауза сервера без игроков; State.paused — сама пауза.
     */
    private void keepRunning() {
        if (!core.config.settings.plugin.enabled || !core.config.settings.disablePause) return;
        try {
            if (Vars.state.rules.pvpAutoPause) Vars.state.rules.pvpAutoPause = false;
            if (Administration.Config.autoPause.bool()) Administration.Config.autoPause.set(false);
            if (Vars.state.is(mindustry.core.GameState.State.paused)) Vars.state.set(mindustry.core.GameState.State.playing);
        } catch (Throwable t) {
            Log.err("[RawWar] keepRunning: " + t);
        }
    }

    /** Применение игровых ограничений (рассчитано на централизованное переопределение режимами). */
    public void applyRules() {
        try {
            Vars.state.rules.pvp = true;
            Vars.state.rules.attackMode = false;
            keepRunning();
            if (core.config.settings.removeCores) {
                // v8: у EntityGroup нет findAll() — собираем ядра сначала в список, потом удаляем,
                // чтобы не менять Groups.build во время итерации.
                java.util.List<mindustry.world.blocks.storage.CoreBlock.CoreBuild> cores = new java.util.ArrayList<>();
                Groups.build.each(b -> b instanceof mindustry.world.blocks.storage.CoreBlock.CoreBuild,
                        b -> cores.add((mindustry.world.blocks.storage.CoreBlock.CoreBuild) b));
                for (mindustry.world.blocks.storage.CoreBlock.CoreBuild c : cores) {
                    if (c.tile != null) c.tile.setNet(mindustry.content.Blocks.air);
                }
            }
        } catch (Throwable t) {
            Log.err("[RawWar] applyRules: " + t);
        }
    }

    private void onJoin(Player p) {
        core.teams.assign(p);
        PlayerData d = core.data.get(p.uuid(), p.plainName());
        core.data.markDirty(p.uuid());
        // вклады, которые созрели, пока игрока не было в сети
        Timer.schedule(() -> core.bank.settle(p, core.data.get(p.uuid(), p.plainName()), true), 3f);
        if (core.config.settings.units.enabled) {
            // выбор юнита через меню убран: юнит выдаётся автоматически (лучший открытый или выбранный игроком)
            Timer.schedule(() -> core.units.autoGive(p), 1.5f);
        }
        core.modes.playerJoin(p);
        keepRunning();
    }

    private void onLeave(Player p) {
        core.menus.close(p);
        core.bankMenu.forget(p);
        core.helpMenu.forget(p);
        core.spawns.leave(p);
        core.mapgenMenu.forget(p);
        core.units.release(p);
        core.units.forgetLock(p);
        core.teams.remove(p);
        core.data.unloadPlayer(p.uuid());
        // при выходе предпоследнего игрока серверная авто-пауза могла сработать — сразу снимаем
        Timer.schedule(this::keepRunning, 0.2f);
    }

    private void onUnitDestroyed(Unit u) {
        if (core.units.consumeIgnored(u)) return;
        Player p = u.getPlayer();
        if (p == null) return;
        if (!core.units.isOwnUnit(p, u)) return;
        core.units.release(p);
        PlayerData d = core.data.get(p.uuid(), p.plainName());
        d.deaths++;
        core.data.markDirty(p.uuid());
        core.modes.playerDeath(p);
        if (core.config.settings.units.enabled) {
            Timer.schedule(() -> core.units.autoGive(p), 2f);
        }
    }

    private void onUnitKilledByBullet(Unit victim, Object owner) {
        if (!(owner instanceof Unit)) return;
        Player killer = ((Unit) owner).getPlayer();
        if (killer == null) return;
        Player vp = victim.getPlayer();
        if (vp == null) { core.modes.unitKilled(killer, victim); return; } // убит бот / юнит без игрока
        if (killer == vp) return;
        RwTeam kt = core.teams.of(killer), vt = core.teams.of(vp);
        if (kt == null || vt == null || kt == vt) return;
        PlayerData d = core.data.get(killer.uuid(), killer.plainName());
        d.kills++;
        d.xp += core.config.settings.units.xpPerKill;
        core.bank.reward(killer, core.config.settings.units.xpPerKill, "убийство игрока", false);
        core.data.markDirty(killer.uuid());
        core.units.refresh(killer);
        core.modes.kill(killer, vp);
    }
}
