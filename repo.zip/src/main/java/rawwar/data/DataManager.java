package rawwar.data;

import arc.files.Fi;
import arc.util.Log;
import arc.util.Timer;
import rawwar.core.CoreManager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/** Data System: сохранение и загрузка игроков, сервера, статистики матчей. */
public class DataManager {
    private final CoreManager core;
    private final Map<String, PlayerData> players = new HashMap<>();
    private final Map<String, Boolean> dirty = new HashMap<>();
    public ServerData server = new ServerData();
    private ServerData.MatchLog matchLog = new ServerData.MatchLog();
    private Timer.Task autosave;

    public DataManager(CoreManager core) { this.core = core; }

    private Fi playerFile(String uuid) { return core.root.child("players").child(safe(uuid) + ".json"); }
    private static String safe(String s) { return s.replaceAll("[^A-Za-z0-9_=\\-]", "_"); }

    public void load() {
        server = JsonIO.read(core.root.child("config").child("server.json"), ServerData.class, ServerData::new);
        matchLog = JsonIO.read(core.root.child("statistics").child("matches.json"), ServerData.MatchLog.class, ServerData.MatchLog::new);
        int interval = Math.max(10, core.config.settings.dataSaveIntervalSeconds);
        if (autosave != null) autosave.cancel();
        autosave = Timer.schedule(this::saveAll, interval, interval);
    }

    public PlayerData get(String uuid, String name) {
        PlayerData d = players.get(uuid);
        if (d == null) {
            d = JsonIO.read(playerFile(uuid), PlayerData.class, () -> new PlayerData(uuid, name));
            players.put(uuid, d);
            // перенос старых очков в kys (один раз на игрока)
            if (core.bank != null && core.bank.migrate(d)) dirty.put(uuid, true);
        }
        d.name = name;
        return d;
    }

    public void markDirty(String uuid) { dirty.put(uuid, true); }

    public void savePlayer(String uuid) {
        PlayerData d = players.get(uuid);
        if (d != null) JsonIO.write(playerFile(uuid), d);
        dirty.remove(uuid);
    }

    public void unloadPlayer(String uuid) { savePlayer(uuid); players.remove(uuid); }

    public void saveServer() { JsonIO.write(core.root.child("config").child("server.json"), server); }

    public void recordMatch(ServerData.MatchRecord r) {
        matchLog.matches.add(r);
        JsonIO.write(core.root.child("statistics").child("matches.json"), matchLog);
    }

    public void saveAll() {
        for (String uuid : new ArrayList<>(dirty.keySet())) savePlayer(uuid);
        saveServer();
    }

    /** Резервная копия config/ и players/ (хранится до 5 копий). */
    public void backup() {
        try {
            Fi dir = core.root.child("backups").child(String.valueOf(System.currentTimeMillis()));
            dir.mkdirs();
            Fi cfg = core.root.child("config");
            if (cfg.exists()) cfg.copyTo(dir);
            Fi pl = core.root.child("players");
            if (pl.exists()) pl.copyTo(dir);
            Fi[] all = core.root.child("backups").list();
            java.util.Arrays.sort(all, (a, b) -> a.name().compareTo(b.name()));
            for (int i = 0; i < all.length - 5; i++) all[i].deleteDirectory();
        } catch (Throwable t) {
            Log.err("[RawWar] backup: " + t);
        }
    }

    public void stop() {
        if (autosave != null) autosave.cancel();
        for (String uuid : new ArrayList<>(players.keySet())) savePlayer(uuid);
        saveServer();
    }
}
