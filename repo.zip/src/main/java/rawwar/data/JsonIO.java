package rawwar.data;

import arc.files.Fi;
import arc.util.Log;
import arc.util.serialization.Json;
import arc.util.serialization.JsonWriter;

import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.function.Supplier;

/** Безопасное чтение/запись JSON: проверка корректности, обработка повреждённых файлов, атомарная запись. */
public final class JsonIO {
    private static final Json json = new Json();

    static {
        json.setOutputType(JsonWriter.OutputType.json);
        json.setIgnoreUnknownFields(true);
        // false = писать ВСЕ поля, даже равные значениям по умолчанию:
        // файлы (units.json, spawns.json, settings.json) остаются понятными правщику.
        json.setUsePrototypes(false);
    }

    private JsonIO() {}

    public static <T> T read(Fi f, Class<T> type, Supplier<T> def) {
        if (!f.exists()) {
            T d = def.get();
            write(f, d);
            return d;
        }
        try {
            T v = json.fromJson(type, f);
            if (v == null) throw new IllegalStateException("пустой файл");
            return v;
        } catch (Throwable e) {
            Log.err("[RawWar] Повреждён файл " + f.path() + ": " + e);
            try { f.copyTo(f.sibling(f.name() + ".corrupt-" + System.currentTimeMillis())); } catch (Throwable ignored) {}
            T d = def.get();
            write(f, d);
            return d;
        }
    }

    public static synchronized void write(Fi f, Object o) {
        try {
            f.parent().mkdirs();
            Fi tmp = f.sibling(f.name() + ".tmp");
            tmp.writeString(json.prettyPrint(o));
            Files.move(tmp.file().toPath(), f.file().toPath(), StandardCopyOption.REPLACE_EXISTING);
        } catch (Throwable e) {
            Log.err("[RawWar] Не удалось записать " + f.path() + ": " + e);
        }
    }
}
