package rawwar.data;

import java.util.ArrayList;

/** Постоянные данные сервера: статистика команд, администраторы, список матчей. */
public class ServerData {
    public int alphaWins, bravoWins, draws;
    public ArrayList<String> admins = new ArrayList<>();

    public static class MatchRecord {
        public String mode = "", winner = "", summary = "";
        public long endedAt;
        public int durationSeconds;
    }

    public static class MatchLog {
        public ArrayList<MatchRecord> matches = new ArrayList<>();
    }
}
