package rawwar.data;

import java.util.ArrayList;

/** Постоянные данные игрока (players/<uuid>.json). */
public class PlayerData {
    public String uuid = "";
    public String name = "";
    public String unitId = "";
    public String preferred = ""; // юнит, выбранный кнопкой «Играть этим»; пусто = автоматически лучший
    public String unitClass = ""; // устарело: выбор классов убран, поле оставлено для старых сохранений
    public int kills, deaths, wins, losses, matches;
    public int xp;          // опыт: за убийства/победы, определяет ранг
    public int rank = 1;    // текущий ранг (считается из xp при refresh)
    public int points;      // устарело
    public int spent;       // устарело: нужно только для переноса старых очков в kys (см. BankManager.migrate)
    // ---- банк (валюта kys) ----
    public long balance;    // kys: единый баланс. Награды приходят сюда, отсюда платятся покупки, вклады и переводы
    public boolean balanceMerged; // true после слияния старых кошелька и счёта в balance
    public long wallet;     // устарело: старый кошелёк, при загрузке переносится в balance (BankManager.migrate)
    public long account;    // устарело: старый счёт, при загрузке переносится в balance (BankManager.migrate)
    public boolean kysInit; // true после переноса старых очков в kys
    public ArrayList<Deposit> deposits = new ArrayList<>(); // открытые вклады
    public ArrayList<Tx> history = new ArrayList<>();       // последние операции банка
    public ArrayList<String> unlocked = new ArrayList<>(); // id открытых (исследованных/купленных) юнитов
    public int rating = 1000; // задел на будущее

    /** Срочный вклад. Сумма выплаты фиксируется при открытии. */
    public static class Deposit {
        public int id;
        public String plan = "", planName = "";
        public long amount, payout, openedAt, maturesAt;
        public Deposit() {}
    }

    /** Запись истории операций. */
    public static class Tx {
        public long time;
        public String text = "";
        public Tx() {}
        public Tx(long time, String text) { this.time = time; this.text = text; }
    }

    public PlayerData() {}
    public PlayerData(String uuid, String name) { this.uuid = uuid; this.name = name; }
}
