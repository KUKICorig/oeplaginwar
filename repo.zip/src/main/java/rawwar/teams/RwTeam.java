package rawwar.teams;

import mindustry.game.Team;

import java.util.LinkedHashSet;
import java.util.Set;

/** Команда RawWar (обёртка над mindustry.game.Team). */
public class RwTeam {
    public final String id;       // "alpha" / "bravo"
    public String name;
    public Team team;
    public int score;
    public final Set<String> members = new LinkedHashSet<>(); // uuid

    public RwTeam(String id, String name, Team team) { this.id = id; this.name = name; this.team = team; }

    public int size() { return members.size(); }
}
