package rawwar.teams;

import mindustry.game.Team;
import mindustry.gen.Groups;
import mindustry.gen.Player;
import rawwar.core.CoreManager;

import java.util.ArrayList;
import java.util.List;

/** Team System: две команды, распределение и баланс. */
public class TeamManager {
    private final CoreManager core;
    public RwTeam alpha, bravo;

    public TeamManager(CoreManager core) { this.core = core; }

    public void load() {
        alpha = new RwTeam("alpha", core.config.settings.teams.alphaName, resolve(core.config.settings.teams.alphaTeam, Team.sharded));
        bravo = new RwTeam("bravo", core.config.settings.teams.bravoName, resolve(core.config.settings.teams.bravoTeam, Team.crux));
        for (Player p : Groups.player) assign(p);
    }

    private static Team resolve(String name, Team def) {
        for (Team t : Team.all) if (t.name.equalsIgnoreCase(name)) return t;
        return def;
    }

    public RwTeam byId(String id) {
        if (id == null) return null;
        if (id.equalsIgnoreCase("alpha") || id.equalsIgnoreCase("a") || id.equalsIgnoreCase(alpha.name)) return alpha;
        if (id.equalsIgnoreCase("bravo") || id.equalsIgnoreCase("b") || id.equalsIgnoreCase(bravo.name)) return bravo;
        return null;
    }

    public RwTeam of(Player p) {
        if (alpha.members.contains(p.uuid())) return alpha;
        if (bravo.members.contains(p.uuid())) return bravo;
        return null;
    }

    public RwTeam other(RwTeam t) { return t == alpha ? bravo : alpha; }

    /** Автоматическое распределение при подключении: в менее заполненную команду. */
    public RwTeam assign(Player p) {
        RwTeam cur = of(p);
        if (cur != null) return cur;
        int max = core.config.settings.teams.maxPlayersPerTeam;
        RwTeam target = alpha.size() <= bravo.size() ? alpha : bravo;
        if (target.size() >= max) target = other(target);
        if (target.size() >= max) p.sendMessage("[scarlet]Команды заполнены сверх лимита, но вы всё равно добавлены.");
        return set(p, target);
    }

    public RwTeam set(Player p, RwTeam t) {
        alpha.members.remove(p.uuid());
        bravo.members.remove(p.uuid());
        t.members.add(p.uuid());
        p.team(t.team);
        // v8: у Unit нет isNull() — живой юнит это !dead() и добавленный в группы
        if (p.unit() != null && !p.unit().dead() && p.unit().isAdded()) p.unit().team(t.team);
        return t;
    }

    public boolean canSwitch(Player p, RwTeam to) {
        if (!core.config.settings.teams.allowTeamSwitch) return false;
        return to.size() < core.config.settings.teams.maxPlayersPerTeam && to.size() <= other(to).size();
    }

    public void remove(Player p) {
        alpha.members.remove(p.uuid());
        bravo.members.remove(p.uuid());
    }

    /** Выравнивание численности: переносит игроков из большей команды в меньшую. */
    public int balance() {
        int moved = 0;
        while (Math.abs(alpha.size() - bravo.size()) > 1) {
            RwTeam big = alpha.size() > bravo.size() ? alpha : bravo;
            RwTeam small = other(big);
            String uuid = big.members.iterator().next();
            Player pl = null;
            for (Player p : Groups.player) if (p.uuid().equals(uuid)) { pl = p; break; }
            if (pl == null) { big.members.remove(uuid); continue; }
            set(pl, small);
            core.units.release(pl);
            core.units.autoGive(pl);
            moved++;
        }
        return moved;
    }

    public List<Player> players(RwTeam t) {
        List<Player> list = new ArrayList<>();
        for (Player p : Groups.player) if (t.members.contains(p.uuid())) list.add(p);
        return list;
    }

    public void resetScores() { alpha.score = 0; bravo.score = 0; }
}
