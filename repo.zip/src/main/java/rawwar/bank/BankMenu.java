package rawwar.bank;

import arc.func.Cons;
import mindustry.gen.Call;
import mindustry.gen.Groups;
import mindustry.gen.Player;
import mindustry.ui.Menus;
import rawwar.config.Settings;
import rawwar.core.CoreManager;
import rawwar.data.PlayerData;

import java.util.*;

/**
 * Меню банка (/bank): баланс, вклады, переводы, история.
 * Суммы выбираются кнопками (быстрые значения и доли баланса); точные суммы — командами /bank send|deposit.
 */
public class BankMenu {
    private enum Stage { MAIN, DEPOSITS, DEP_PLAN, DEP_AMOUNT, DEP_INFO, SEND_PICK, SEND_AMOUNT, HISTORY }

    private static final int PAGE = 8;
    private static final long[] PRESETS = {100, 500, 1000, 5000};

    private static class State {
        Stage stage = Stage.MAIN;
        List<Runnable> actions = new ArrayList<>();
        int page;
        String planId;
        int depId;
        String targetUuid;
        boolean confirm;
    }

    private final CoreManager core;
    private final Map<String, State> states = new HashMap<>();
    private int menuId = -1;

    public BankMenu(CoreManager core) { this.core = core; }

    public void load() {
        if (menuId == -1) menuId = Menus.registerMenu(this::onChoice);
    }

    public void open(Player p) {
        State s = new State();
        states.put(p.uuid(), s);
        show(p, s);
    }

    public void close(Player p) {
        states.remove(p.uuid());
        if (menuId != -1 && p.con != null) Call.hideFollowUpMenu(p.con, menuId);
    }

    /** Закрыть без скрытия окна (при выходе игрока). */
    public void forget(Player p) { states.remove(p.uuid()); }

    private void onChoice(Player p, int option) {
        State s = states.get(p.uuid());
        if (s == null || option < 0 || option >= s.actions.size()) return; // окно закрыто игроком
        s.actions.get(option).run();
    }

    private void go(Player p, State s, Stage stage) {
        s.stage = stage;
        s.confirm = false;
        s.page = 0;
        show(p, s);
    }

    private void row(List<String[]> rows, State s, String label, Runnable action) {
        rows.add(new String[]{label});
        s.actions.add(action);
    }

    /**
     * Кнопки сумм: быстрые значения, 25 %, 50 % и «всё» в пределах [min, available].
     * Повторяющиеся значения убираются, по две кнопки в ряд.
     */
    private void amountButtons(List<String[]> rows, State s, long available, long min, Cons<Long> cb) {
        LinkedHashMap<Long, String> opts = new LinkedHashMap<>();
        long lo = Math.max(1, min);
        for (long v : PRESETS) if (v >= lo && v <= available) opts.putIfAbsent(v, BankManager.fmt(v));
        long q = available / 4, h = available / 2;
        if (q >= lo) opts.putIfAbsent(q, "25%: " + BankManager.fmt(q));
        if (h >= lo) opts.putIfAbsent(h, "50%: " + BankManager.fmt(h));
        if (available >= lo) opts.put(available, "Всё: " + BankManager.fmt(available));
        List<Map.Entry<Long, String>> l = new ArrayList<>(opts.entrySet());
        for (int i = 0; i < l.size(); i += 2) {
            int n = Math.min(2, l.size() - i);
            String[] r = new String[n];
            for (int j = 0; j < n; j++) {
                final long v = l.get(i + j).getKey();
                r[j] = "[gold]" + l.get(i + j).getValue();
                s.actions.add(() -> cb.get(v));
            }
            rows.add(r);
        }
    }

    private Player online(String uuid) {
        if (uuid == null) return null;
        for (Player p : Groups.player) if (p.uuid().equals(uuid)) return p;
        return null;
    }

    private void show(Player p, State s) {
        s.actions = new ArrayList<>();
        List<String[]> rows = new ArrayList<>();
        BankManager bank = core.bank;
        PlayerData d = core.data.get(p.uuid(), p.plainName());
        bank.settle(p, d, true);
        String title, text;

        switch (s.stage) {
            case DEPOSITS: {
                title = "ВКЛАДЫ";
                text = bank.shortBalance(d) + "\n\n" + bank.depositsText(d)
                        + "\n\n[accent]Тарифы:\n" + bank.plansText()
                        + "\n[gray]Досрочное закрытие: штраф " + Math.max(0, core.config.settings.bank.earlyClosePenaltyPercent) + "% от суммы, доход не выплачивается.";
                for (final PlayerData.Deposit x : d.deposits) {
                    row(rows, s, bank.depositLine(x), () -> { s.depId = x.id; go(p, s, Stage.DEP_INFO); });
                }
                if (d.deposits.size() < Math.max(1, core.config.settings.bank.maxDeposits) && !bank.plans().isEmpty()) {
                    row(rows, s, "[lime]Открыть вклад", () -> go(p, s, Stage.DEP_PLAN));
                }
                row(rows, s, "Назад", () -> go(p, s, Stage.MAIN));
                break;
            }
            case DEP_PLAN: {
                title = "НОВЫЙ ВКЛАД";
                text = "[accent]Баланс: " + BankManager.money(d.balance) + "\n\n[white]Выберите тариф. Деньги берутся с баланса.";
                for (final Settings.DepositPlan pl : bank.plans()) {
                    row(rows, s, bank.planName(pl) + " [gray](" + BankManager.dur(pl.minutes * 60_000L) + ", +" + (pl.percent == Math.floor(pl.percent) ? String.valueOf((long) pl.percent) : String.valueOf(pl.percent)) + "%)",
                            () -> { s.planId = pl.id; go(p, s, Stage.DEP_AMOUNT); });
                }
                row(rows, s, "Назад", () -> go(p, s, Stage.DEPOSITS));
                break;
            }
            case DEP_AMOUNT: {
                final Settings.DepositPlan pl = bank.plan(s.planId);
                if (pl == null) { go(p, s, Stage.DEP_PLAN); return; }
                title = "ВКЛАД: " + bank.planName(pl).toUpperCase();
                text = "[white]" + bank.planLine(pl) + "\n[accent]Баланс: " + BankManager.money(d.balance)
                        + "\n\n[white]Сколько внести? Выплата придёт на баланс в конце срока.";
                long min = Math.max(1, pl.minAmount);
                if (d.balance < min) text += "\n[scarlet]Недостаточно на балансе: минимум " + BankManager.fmt(min) + " " + BankManager.CUR + ".";
                amountButtons(rows, s, d.balance, min, v -> {
                    String err = bank.openDeposit(p, pl, v);
                    if (err != null) { p.sendMessage("[scarlet]" + err); show(p, s); return; }
                    p.sendMessage("[lime]Вклад открыт: " + BankManager.money(v) + "[lime] -> " + BankManager.money(BankManager.payoutOf(pl, v)) + "[lime] через " + BankManager.dur(pl.minutes * 60_000L));
                    go(p, s, Stage.DEPOSITS);
                });
                row(rows, s, "Назад", () -> go(p, s, Stage.DEP_PLAN));
                break;
            }
            case DEP_INFO: {
                final PlayerData.Deposit x = bank.deposit(d, s.depId);
                if (x == null) { go(p, s, Stage.DEPOSITS); return; }
                long refund = x.amount - bank.penaltyOf(x.amount);
                title = "ВКЛАД #" + x.id;
                text = "[accent]Тариф: [white]" + x.planName + "\n[accent]Внесено: " + BankManager.money(x.amount)
                        + "\n[accent]К выплате: " + BankManager.money(x.payout)
                        + "\n[accent]Осталось: [white]" + BankManager.dur(x.maturesAt - System.currentTimeMillis())
                        + "\n\n[gray]При досрочном закрытии вернётся " + BankManager.fmt(refund) + " " + BankManager.CUR + " (без дохода).";
                row(rows, s, s.confirm ? "[scarlet]Подтвердить: закрыть досрочно" : "[orange]Закрыть досрочно", () -> {
                    if (!s.confirm) { s.confirm = true; show(p, s); return; }
                    String err = bank.closeDeposit(p, x.id);
                    p.sendMessage(err != null ? "[scarlet]" + err : "[orange]Вклад #" + x.id + " закрыт, на баланс вернулось " + BankManager.money(refund));
                    go(p, s, Stage.DEPOSITS);
                });
                row(rows, s, "Назад", () -> go(p, s, Stage.DEPOSITS));
                break;
            }
            case SEND_PICK: {
                List<Player> others = new ArrayList<>();
                for (Player o : Groups.player) if (!o.uuid().equals(p.uuid())) others.add(o);
                int fee = Math.max(0, core.config.settings.bank.transferFeePercent);
                title = "ПЕРЕВОД";
                text = "[accent]Баланс: " + BankManager.money(d.balance) + "\n[white]Переводы идут с баланса на баланс. Комиссия: " + fee + "%."
                        + (others.isEmpty() ? "\n[gray]Других игроков в сети нет." : "\n[white]Кому перевести?");
                int pages = Math.max(1, (others.size() + PAGE - 1) / PAGE);
                s.page = Math.max(0, Math.min(s.page, pages - 1));
                for (int i = s.page * PAGE; i < Math.min(others.size(), s.page * PAGE + PAGE); i++) {
                    final Player o = others.get(i);
                    row(rows, s, o.plainName(), () -> { s.targetUuid = o.uuid(); go(p, s, Stage.SEND_AMOUNT); });
                }
                if (pages > 1) {
                    final int page = s.page;
                    rows.add(new String[]{"<<", (page + 1) + "/" + pages, ">>"});
                    s.actions.add(() -> { s.page = (page + pages - 1) % pages; show(p, s); });
                    s.actions.add(() -> show(p, s));
                    s.actions.add(() -> { s.page = (page + 1) % pages; show(p, s); });
                }
                row(rows, s, "Назад", () -> go(p, s, Stage.MAIN));
                break;
            }
            case SEND_AMOUNT: {
                final Player to = online(s.targetUuid);
                if (to == null) { p.sendMessage("[scarlet]Игрок вышел из сети."); go(p, s, Stage.SEND_PICK); return; }
                long max = bank.maxSend(d.balance);
                long min = Math.max(1, core.config.settings.bank.minTransfer);
                title = "ПЕРЕВОД: " + to.plainName();
                text = "[accent]Баланс: " + BankManager.money(d.balance) + "\n[white]Сколько перевести игроку [accent]" + to.plainName() + "[white]?"
                        + (core.config.settings.bank.transferFeePercent > 0 ? "\n[gray]Комиссия " + core.config.settings.bank.transferFeePercent + "% сверх суммы." : "");
                amountButtons(rows, s, max, min, v -> {
                    String err = bank.send(p, to, v);
                    p.sendMessage(err != null ? "[scarlet]" + err : "[lime]Переведено: " + BankManager.money(v) + "[lime] игроку [white]" + to.plainName());
                    if (err == null) go(p, s, Stage.MAIN); else show(p, s);
                });
                row(rows, s, "Назад", () -> go(p, s, Stage.SEND_PICK));
                break;
            }
            case HISTORY: {
                title = "ИСТОРИЯ";
                text = bank.historyText(d);
                row(rows, s, "Назад", () -> go(p, s, Stage.MAIN));
                break;
            }
            default: {
                title = "БАНК " + BankManager.CUR.toUpperCase();
                text = bank.overview(p, d)
                        + "\n\n[gray]Награды приходят на баланс, юниты покупаются с баланса (/shop).\nКоманды: /help bank";
                row(rows, s, "Вклады" + (d.deposits.isEmpty() ? "" : " (" + d.deposits.size() + ")"), () -> go(p, s, Stage.DEPOSITS));
                row(rows, s, "Перевод игроку", () -> go(p, s, Stage.SEND_PICK));
                row(rows, s, "История операций", () -> go(p, s, Stage.HISTORY));
                row(rows, s, "Закрыть", () -> states.remove(p.uuid()));
                break;
            }
        }
        Call.menu(p.con, menuId, title, text, rows.toArray(new String[0][]));
    }
}
