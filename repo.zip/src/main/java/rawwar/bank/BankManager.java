package rawwar.bank;

import arc.util.Log;
import arc.util.Timer;
import mindustry.gen.Groups;
import mindustry.gen.Player;
import rawwar.config.Settings;
import rawwar.core.CoreManager;
import rawwar.data.PlayerData;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

/**
 * Bank System: валюта kys.
 *
 * Баланс (balance)  — единственный счёт игрока. Сюда приходят награды (убийства, волны, победы), отсюда платятся
 *                     покупка юнитов, вклады и переводы игрокам.
 * Вклады (deposits) — срочные: сумма и доход фиксируются при открытии, в конце срока выплата падает на баланс.
 *                     Досрочное закрытие возвращает сумму за вычетом штрафа, без дохода.
 *
 * Все операции возвращают null при успехе или текст причины отказа (как в UnitManager).
 * Вклады «созревают» по реальному времени, в том числе пока игрок не в сети: выплата происходит при ближайшем
 * обращении к банку или входе игрока (settle).
 */
public class BankManager {
    public static final String CUR = "kys";
    private static final long CAP = 999_999_999_999L; // потолок любого баланса
    private static final int HISTORY_MAX = 25;
    private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("dd.MM HH:mm");

    private final CoreManager core;
    private Timer.Task task;

    public BankManager(CoreManager core) { this.core = core; }

    // ---------- жизненный цикл ----------
    public void load() {
        if (task != null) task.cancel();
        task = Timer.schedule(this::tick, 30f, 30f);
    }

    public void stop() {
        if (task != null) { task.cancel(); task = null; }
    }

    /** Раз в 30 секунд выплачивает созревшие вклады игрокам онлайн. */
    private void tick() {
        try {
            for (Player p : Groups.player) settle(p, data(p), true);
        } catch (Throwable t) {
            Log.err("[RawWar] bank tick: " + t);
        }
    }

    private Settings.BankCfg cfg() { return core.config.settings.bank; }

    private PlayerData data(Player p) { return core.data.get(p.uuid(), p.plainName()); }

    private void dirty(PlayerData d) { core.data.markDirty(d.uuid); }

    /**
     * Перенос старых данных: очки (опыт * коэффициент - потрачено) и старые кошелёк со счётом сливаются в balance.
     * Каждый шаг выполняется один раз на игрока. true, если данные изменились.
     */
    public boolean migrate(PlayerData d) {
        boolean changed = false;
        if (!d.kysInit) {
            double k = Math.max(0f, cfg().kysPerXp);
            long old = Math.max(0L, (long) Math.floor(d.xp * k) - d.spent);
            d.balance = cap(d.balance + old + Math.max(0, cfg().startBonus));
            d.kysInit = true;
            changed = true;
        }
        if (!d.balanceMerged) {
            d.balance = cap(d.balance + d.wallet + d.account);
            d.wallet = 0;
            d.account = 0;
            d.balanceMerged = true;
            changed = true;
        }
        return changed;
    }

    // ---------- тарифы ----------
    /** Корректные тарифы из настроек (с непустым id и сроком > 0). */
    public List<Settings.DepositPlan> plans() {
        List<Settings.DepositPlan> out = new ArrayList<>();
        if (cfg().plans == null) return out;
        for (Settings.DepositPlan p : cfg().plans) {
            if (p == null || p.id == null || p.id.isEmpty() || p.minutes <= 0) continue;
            boolean dup = false;
            for (Settings.DepositPlan x : out) if (x.id.equalsIgnoreCase(p.id)) { dup = true; break; }
            if (!dup) out.add(p);
        }
        return out;
    }

    /** Тариф по id, названию или номеру в списке (с 1). */
    public Settings.DepositPlan plan(String q) {
        if (q == null) return null;
        String s = q.trim().toLowerCase(Locale.ROOT);
        if (s.isEmpty()) return null;
        List<Settings.DepositPlan> l = plans();
        for (Settings.DepositPlan p : l) if (p.id.toLowerCase(Locale.ROOT).equals(s) || (p.name != null && p.name.toLowerCase(Locale.ROOT).equals(s))) return p;
        try {
            int i = Integer.parseInt(s);
            if (i >= 1 && i <= l.size()) return l.get(i - 1);
        } catch (NumberFormatException ignored) {}
        Settings.DepositPlan hit = null; int cnt = 0;
        for (Settings.DepositPlan p : l) if (p.id.toLowerCase(Locale.ROOT).startsWith(s) || (p.name != null && p.name.toLowerCase(Locale.ROOT).startsWith(s))) { hit = p; cnt++; }
        return cnt == 1 ? hit : null;
    }

    public static long payoutOf(Settings.DepositPlan plan, long amount) {
        return amount + Math.round(amount * (double) plan.percent / 100.0);
    }

    // ---------- балансы ----------
    public long balance(PlayerData d) { return d.balance; }

    public long locked(PlayerData d) {
        long s = 0;
        for (PlayerData.Deposit x : d.deposits) s += x.amount;
        return s;
    }

    public long total(PlayerData d) { return d.balance + locked(d); }

    // ---------- награды и траты ----------
    /** Награда за опыт: xp * kysPerXp на баланс. */
    public void reward(Player p, int xp, String reason, boolean notify) {
        if (p == null || xp <= 0) return;
        long k = Math.round(xp * (double) Math.max(0f, cfg().kysPerXp));
        if (k <= 0) return;
        PlayerData d = data(p);
        d.balance = cap(d.balance + k);
        dirty(d);
        if (notify) p.sendMessage("[accent]+" + money(k) + "[accent] (" + reason + "). Баланс: " + money(d.balance));
    }

    /** Списывает kys с баланса (покупка). */
    public String spend(Player p, long amount, String reason) {
        PlayerData d = data(p);
        if (amount <= 0) return "Некорректная сумма.";
        if (d.balance < amount) return notEnough(d, amount);
        d.balance -= amount;
        log(d, "-" + fmt(amount) + " " + CUR + ": " + reason);
        dirty(d);
        return null;
    }

    /** Текст «не хватает kys». */
    public String notEnough(PlayerData d, long need) {
        return "Не хватает " + CUR + ": нужно " + fmt(need) + ", на балансе " + fmt(d.balance) + ".";
    }

    // ---------- переводы ----------
    /** Комиссия перевода (округляется вверх). */
    public long feeOf(long amount) {
        int pct = Math.max(0, cfg().transferFeePercent);
        return pct == 0 ? 0 : (amount * pct + 99) / 100;
    }

    /** Максимальная сумма, которую можно перевести при данном балансе (с учётом комиссии). */
    public long maxSend(long balance) {
        long a = balance;
        int pct = Math.max(0, cfg().transferFeePercent);
        if (pct > 0) a = balance * 100 / (100 + pct);
        while (a > 0 && a + feeOf(a) > balance) a--;
        return Math.max(0, a);
    }

    /** Перевод с баланса на баланс другого игрока (получатель должен быть онлайн). */
    public String send(Player from, Player to, long amount) {
        if (to == null) return "Игрок не найден (он должен быть в сети).";
        if (from == to || from.uuid().equals(to.uuid())) return "Нельзя перевести самому себе.";
        PlayerData a = data(from), b = data(to);
        settle(from, a, true);
        settle(to, b, true);
        int min = Math.max(1, cfg().minTransfer);
        if (amount < min) return "Минимальный перевод: " + fmt(min) + " " + CUR + ".";
        long fee = feeOf(amount), cost = amount + fee;
        if (a.balance < cost) {
            return "На балансе " + fmt(a.balance) + " " + CUR + ", нужно " + fmt(cost)
                    + (fee > 0 ? " (комиссия " + fmt(fee) + ")" : "") + ".";
        }
        if (b.balance + amount > CAP) return "У получателя превышен лимит баланса.";
        a.balance -= cost;
        b.balance += amount;
        log(a, "Перевод игроку " + to.plainName() + ": -" + fmt(cost) + " " + CUR + (fee > 0 ? " (комиссия " + fmt(fee) + ")" : ""));
        log(b, "Перевод от " + from.plainName() + ": +" + fmt(amount) + " " + CUR);
        dirty(a);
        dirty(b);
        to.sendMessage("[lime]Вам перевели " + money(amount) + "[lime] от [white]" + from.plainName() + "[lime]. Баланс: " + money(b.balance));
        return null;
    }

    /** Игрок онлайн по имени: точное совпадение без учёта регистра, иначе единственное начало имени. */
    public Player findPlayer(String name) {
        if (name == null || name.trim().isEmpty()) return null;
        String q = name.trim().toLowerCase(Locale.ROOT);
        Player hit = null; int cnt = 0;
        for (Player p : Groups.player) {
            String n = p.plainName().toLowerCase(Locale.ROOT);
            if (n.equals(q)) return p;
            if (n.startsWith(q)) { hit = p; cnt++; }
        }
        return cnt == 1 ? hit : null;
    }

    // ---------- вклады ----------
    /** Открывает вклад за счёт средств на балансе. */
    public String openDeposit(Player p, Settings.DepositPlan plan, long amount) {
        PlayerData d = data(p);
        settle(p, d, true);
        if (plan == null) return "Тариф не найден. Список: /bank plans";
        if (d.deposits.size() >= Math.max(1, cfg().maxDeposits)) return "Достигнут лимит вкладов: " + Math.max(1, cfg().maxDeposits) + ".";
        if (amount < Math.max(1, plan.minAmount)) return "Минимум для тарифа «" + planName(plan) + "»: " + fmt(Math.max(1, plan.minAmount)) + " " + CUR + ".";
        if (d.balance < amount) return "На балансе только " + fmt(d.balance) + " " + CUR + ".";
        int id = 1;
        for (PlayerData.Deposit x : d.deposits) id = Math.max(id, x.id + 1);
        long now = System.currentTimeMillis();
        PlayerData.Deposit dep = new PlayerData.Deposit();
        dep.id = id;
        dep.plan = plan.id;
        dep.planName = planName(plan);
        dep.amount = amount;
        dep.payout = payoutOf(plan, amount);
        dep.openedAt = now;
        dep.maturesAt = now + plan.minutes * 60_000L;
        d.balance -= amount;
        d.deposits.add(dep);
        log(d, "Вклад #" + id + " «" + dep.planName + "»: " + fmt(amount) + " " + CUR + " -> " + fmt(dep.payout) + " через " + dur(plan.minutes * 60_000L));
        dirty(d);
        return null;
    }

    /** Досрочное закрытие: возврат суммы за вычетом штрафа, без дохода. */
    public String closeDeposit(Player p, int id) {
        PlayerData d = data(p);
        settle(p, d, true);
        PlayerData.Deposit dep = deposit(d, id);
        if (dep == null) return "Вклад #" + id + " не найден (возможно, срок уже вышел и деньги на балансе).";
        long refund = dep.amount - penaltyOf(dep.amount);
        d.deposits.remove(dep);
        d.balance = cap(d.balance + refund);
        log(d, "Вклад #" + dep.id + " закрыт досрочно: +" + fmt(refund) + " " + CUR + " на баланс (штраф " + fmt(dep.amount - refund) + ")");
        dirty(d);
        return null;
    }

    public long penaltyOf(long amount) {
        int pct = Math.min(100, Math.max(0, cfg().earlyClosePenaltyPercent));
        return pct == 0 ? 0 : (amount * pct + 99) / 100;
    }

    public PlayerData.Deposit deposit(PlayerData d, int id) {
        for (PlayerData.Deposit x : d.deposits) if (x.id == id) return x;
        return null;
    }

    /** Выплачивает созревшие вклады на баланс. Возвращает число выплат. */
    public int settle(Player p, PlayerData d, boolean notify) {
        if (d.deposits.isEmpty()) return 0;
        long now = System.currentTimeMillis();
        int n = 0;
        Iterator<PlayerData.Deposit> it = d.deposits.iterator();
        while (it.hasNext()) {
            PlayerData.Deposit x = it.next();
            if (x.maturesAt > now) continue;
            it.remove();
            d.balance = cap(d.balance + x.payout);
            log(d, "Вклад #" + x.id + " «" + x.planName + "» выплачен: +" + fmt(x.payout) + " " + CUR + " на баланс");
            if (notify && p != null) p.sendMessage("[lime]Вклад #" + x.id + " «" + x.planName + "» созрел: [white]" + money(x.payout) + "[lime] зачислено на баланс.");
            n++;
        }
        if (n > 0) dirty(d);
        return n;
    }

    // ---------- админ ----------
    /** op: give | take | set — операции с балансом. null = успех. */
    public String adminAdjust(Player target, String op, long amount, String by) {
        PlayerData d = data(target);
        switch (op) {
            case "give":
                d.balance = cap(d.balance + amount);
                log(d, "Выдано администрацией: +" + fmt(amount) + " " + CUR);
                break;
            case "take":
                d.balance = Math.max(0, d.balance - amount);
                log(d, "Списано администрацией: -" + fmt(amount) + " " + CUR);
                break;
            case "set":
                d.balance = cap(Math.max(0, amount));
                log(d, "Баланс установлен администрацией: " + fmt(d.balance) + " " + CUR);
                break;
            default:
                return "Операции: give, take, set.";
        }
        dirty(d);
        Log.info("[RawWar] bank " + op + " " + target.plainName() + " " + amount + " (" + by + ")");
        return null;
    }

    // ---------- история ----------
    private void log(PlayerData d, String text) {
        d.history.add(new PlayerData.Tx(System.currentTimeMillis(), text));
        while (d.history.size() > HISTORY_MAX) d.history.remove(0);
    }

    // ---------- тексты ----------
    /** Баланс одной строкой (для шапок меню и /me). */
    public String shortBalance(PlayerData d) {
        return "[accent]Баланс: " + money(d.balance);
    }

    /** Полная сводка: баланс, вклады, всего. */
    public String overview(Player p, PlayerData d) {
        settle(p, d, false);
        long locked = locked(d), pending = 0;
        for (PlayerData.Deposit x : d.deposits) pending += x.payout;
        StringBuilder sb = new StringBuilder();
        sb.append("[accent]Баланс: ").append(money(d.balance)).append("\n");
        sb.append("[accent]Во вкладах: ").append(money(locked));
        if (!d.deposits.isEmpty()) sb.append(" [gray](вернётся ").append(fmt(pending)).append(")");
        sb.append("\n[accent]Всего: ").append(money(total(d)));
        return sb.toString();
    }

    /** Строка вклада: номер, суммы, срок. */
    public String depositLine(PlayerData.Deposit x) {
        long left = x.maturesAt - System.currentTimeMillis();
        return "#" + x.id + " «" + x.planName + "»: " + fmt(x.amount) + " -> " + fmt(x.payout) + " " + CUR
                + (left <= 0 ? " [lime](готов)" : " [gray](осталось " + dur(left) + ")");
    }

    public String depositsText(PlayerData d) {
        if (d.deposits.isEmpty()) return "[gray]Открытых вкладов нет.";
        StringBuilder sb = new StringBuilder();
        for (PlayerData.Deposit x : d.deposits) sb.append("[white]").append(depositLine(x)).append("\n");
        return sb.toString().trim();
    }

    /** Тарифы вкладов: номер, название, срок, доход, минимум. */
    public String plansText() {
        List<Settings.DepositPlan> l = plans();
        if (l.isEmpty()) return "[gray]Тарифы вкладов не настроены (settings.json -> bank.plans).";
        StringBuilder sb = new StringBuilder();
        int i = 1;
        for (Settings.DepositPlan p : l) sb.append("[accent]").append(i++).append(". [white]").append(planLine(p)).append("\n");
        return sb.toString().trim();
    }

    public String planLine(Settings.DepositPlan p) {
        return planName(p) + " [gray](" + p.id + ")[white]: срок " + dur(p.minutes * 60_000L) + ", доход +" + pct(p.percent) + "%, от " + fmt(Math.max(1, p.minAmount)) + " " + CUR;
    }

    public String planName(Settings.DepositPlan p) { return p.name == null || p.name.isEmpty() ? p.id : p.name; }

    public String historyText(PlayerData d) {
        if (d.history.isEmpty()) return "[gray]Операций пока нет.";
        StringBuilder sb = new StringBuilder();
        for (int i = d.history.size() - 1; i >= 0; i--) {
            PlayerData.Tx t = d.history.get(i);
            sb.append("[gray]").append(TIME.format(Instant.ofEpochMilli(t.time).atZone(ZoneId.systemDefault()))).append(" [white]").append(t.text).append("\n");
        }
        return sb.toString().trim();
    }

    // ---------- форматирование и разбор ----------
    private static long cap(long v) { return Math.min(CAP, Math.max(0, v)); }

    /** 1234567 -> "1 234 567". */
    public static String fmt(long v) { return String.format(Locale.ROOT, "%,d", v).replace(',', ' '); }

    /** Сумма с цветом валюты: «1 500 kys». */
    public static String money(long v) { return "[gold]" + fmt(v) + " " + CUR + "[]"; }

    private static String pct(float v) {
        return v == Math.floor(v) ? String.valueOf((long) v) : String.format(Locale.ROOT, "%.1f", v);
    }

    /** Длительность: «2 д 3 ч», «45 мин», «30 с». */
    public static String dur(long ms) {
        long s = Math.max(0, ms / 1000);
        if (s < 60) return s + " с";
        long m = s / 60;
        if (m < 60) return m + " мин";
        long h = m / 60;
        if (h < 24) return h + " ч" + (m % 60 > 0 ? " " + (m % 60) + " мин" : "");
        long days = h / 24;
        return days + " д" + (h % 24 > 0 ? " " + (h % 24) + " ч" : "");
    }

    /**
     * Разбор суммы: «500», «1k»/«1к» (тысячи), «2.5k», «1m»/«1м» (миллионы), «50%» и «all»/«все»/«всё» от all.
     * Возвращает -1, если разобрать нельзя или сумма меньше 1. При all < 0 слова и проценты не принимаются.
     */
    public static long parseAmount(String s, long all) {
        if (s == null) return -1;
        s = s.trim().toLowerCase(Locale.ROOT).replace(',', '.');
        if (s.isEmpty()) return -1;
        try {
            if (s.equals("all") || s.equals("max") || s.equals("все") || s.equals("всё")) return all >= 1 ? all : -1;
            if (s.endsWith("%")) {
                double pc = Double.parseDouble(s.substring(0, s.length() - 1));
                if (all < 1 || !(pc > 0) || pc > 100) return -1;
                long v = (long) Math.floor(all * pc / 100.0);
                return v >= 1 ? v : -1;
            }
            double mul = 1;
            char last = s.charAt(s.length() - 1);
            if (last == 'k' || last == 'к') { mul = 1_000; s = s.substring(0, s.length() - 1); }
            else if (last == 'm' || last == 'м') { mul = 1_000_000; s = s.substring(0, s.length() - 1); }
            double v = Double.parseDouble(s) * mul;
            if (Double.isNaN(v) || v < 1 || v > CAP) return -1;
            return (long) Math.floor(v);
        } catch (NumberFormatException e) {
            return -1;
        }
    }
}
