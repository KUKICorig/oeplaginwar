package rawwar.modes.builtin;

import arc.files.Fi;
import mindustry.gen.Call;
import mindustry.gen.Player;
import rawwar.core.CoreManager;
import rawwar.data.JsonIO;
import rawwar.modes.GameMode;
import rawwar.teams.RwTeam;

/** Встроенный режим: Team Deathmatch — побеждает команда, первой набравшая нужное число убийств. */
public class TeamDeathmatch implements GameMode {
    public static class Cfg { public int scoreLimit = 30; public int matchTimeSeconds = 900; }

    private CoreManager core;
    private Cfg cfg = new Cfg();
    private int elapsed;

    @Override public String getId() { return "TeamDeathmatch"; }
    @Override public String getName() { return "Team Deathmatch"; }
    @Override public void attach(CoreManager core) { this.core = core; }

    @Override public void onLoad() {
        Fi f = core.modes.modeDir(getId()).child("config.json");
        cfg = JsonIO.read(f, Cfg.class, Cfg::new);
    }

    @Override public void onStart() { elapsed = 0; core.teams.resetScores(); }
    @Override public void onPlayerJoin(Player p) {}
    @Override public void onPlayerDeath(Player p) {}

    @Override public void onKill(Player killer, Player victim) {
        RwTeam kt = core.teams.of(killer), vt = core.teams.of(victim);
        if (kt == null || kt == vt) return;
        kt.score++;
        if (kt.score >= cfg.scoreLimit) core.modes.endMatch(kt, "Счёт " + core.teams.alpha.score + ":" + core.teams.bravo.score);
    }

    @Override public void onUpdate() {
        elapsed++;
        if (cfg.matchTimeSeconds > 0 && elapsed >= cfg.matchTimeSeconds) {
            RwTeam a = core.teams.alpha, b = core.teams.bravo;
            RwTeam w = a.score == b.score ? null : (a.score > b.score ? a : b);
            core.modes.endMatch(w, "Время вышло. Счёт " + a.score + ":" + b.score);
        } else if (elapsed % 60 == 0) {
            Call.sendMessage("[accent][TDM] " + core.teams.alpha.name + " " + core.teams.alpha.score + " : " + core.teams.bravo.score + " " + core.teams.bravo.name + " (до " + cfg.scoreLimit + ")");
        }
    }

    @Override public void onEnd() {}
    @Override public void onUnload() {}
    @Override public String describe() { return "Team Deathmatch\nПобеждает команда, набравшая " + cfg.scoreLimit + " убийств, либо лидер по истечении " + (cfg.matchTimeSeconds / 60) + " мин."; }
}
