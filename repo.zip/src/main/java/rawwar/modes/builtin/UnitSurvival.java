package rawwar.modes.builtin;

import arc.files.Fi;
import arc.util.Log;
import mindustry.Vars;
import mindustry.gen.Call;
import mindustry.gen.Groups;
import mindustry.gen.Player;
import mindustry.gen.Unit;
import mindustry.type.UnitType;
import rawwar.core.CoreManager;
import rawwar.data.JsonIO;
import rawwar.data.PlayerData;
import rawwar.modes.GameMode;
import rawwar.teams.RwTeam;

import java.util.ArrayList;
import java.util.List;

/**
 * Встроенный режим «Survival»: все игроки в одной команде (Alpha) против волн ботов (Bravo),
 * которые появляются в точках высадки Bravo (/rw spawn add b). Строить и обороняться можно.
 * Настройки: RawWar/modes/UnitSurvival/config.json.
 */
public class UnitSurvival implements GameMode {

    /** Запись о составе волны: сколько юнитов типа появляется на волне N. */
    public static class WaveUnit {
        public String unit = "dagger";
        public int fromWave = 1;        // с какой волны появляется
        public int toWave = 0;          // до какой включительно (0 = без ограничения)
        public int base = 1;            // сколько на волне fromWave
        public float perWave = 0.5f;    // прирост количества за каждую следующую волну
        public int max = 20;            // потолок количества этого типа за одну волну

        public WaveUnit() {}
        public WaveUnit(String unit, int fromWave, int base, float perWave, int max) {
            this.unit = unit; this.fromWave = fromWave; this.base = base; this.perWave = perWave; this.max = max;
        }
    }

    public static class Cfg {
        public int firstWaveDelaySeconds = 60;
        public int waveIntervalSeconds = 45;
        /** Волна, после которой (и после зачистки врагов) игроки побеждают. 0 = бесконечно. */
        public int winWave = 0;
        public int maxEnemiesAlive = 60;
        /** Рост здоровья врагов за каждую волну (0.02 = +2%). */
        public float healthGrowthPerWave = 0.02f;
        public boolean allowBuilding = true;
        public boolean infiniteResources = true;
        public int xpPerBotKill = 5;
        public int xpPerWave = 10;
        public ArrayList<WaveUnit> units = new ArrayList<>(java.util.Arrays.asList(
                new WaveUnit("dagger", 1, 2, 1f, 15),
                new WaveUnit("flare", 2, 1, 0.7f, 10),
                new WaveUnit("mace", 4, 1, 0.6f, 8),
                new WaveUnit("horizon", 5, 1, 0.6f, 8),
                new WaveUnit("fortress", 8, 1, 0.4f, 5),
                new WaveUnit("zenith", 10, 1, 0.3f, 4),
                new WaveUnit("scepter", 15, 1, 0.2f, 2)));
    }

    private CoreManager core;
    private Cfg cfg = new Cfg();
    private int wave, countdown, initialCores;
    private boolean warnedNoSpawn;
    private Boolean prevInfinite;

    @Override public String getId() { return "UnitSurvival"; }
    @Override public String getName() { return "Survival"; }
    @Override public void attach(CoreManager core) { this.core = core; }

    @Override public void onLoad() {
        Fi f = core.modes.modeDir(getId()).child("config.json");
        cfg = JsonIO.read(f, Cfg.class, Cfg::new);
        if (cfg.units == null) cfg.units = new Cfg().units;
    }

    // ---------- жизненный цикл ----------
    @Override public void onStart() {
        wave = 0;
        countdown = Math.max(5, cfg.firstWaveDelaySeconds);
        warnedNoSpawn = false;
        core.teams.resetScores();
        removeBots();
        for (Player p : Groups.player) moveToPlayers(p);
        initialCores = Vars.state.teams.cores(core.teams.alpha.team).size;
        applyModeRules();
        if (initialCores == 0)
            Call.sendMessage("[scarlet][Survival] У игроков нет ядра — враги не будут знать, куда идти. Сгенерируйте карту: /mapgen generate");
        if (core.spawns.count(core.teams.bravo.id) == 0)
            Call.sendMessage("[scarlet][Survival] У врагов (" + core.teams.bravo.name + ") нет точек высадки! Админ: /rw spawn add b");
        if (core.spawns.count(core.teams.alpha.id) == 0)
            Call.sendMessage("[scarlet][Survival] У игроков (" + core.teams.alpha.name + ") нет точек высадки! Админ: /rw spawn add a");
    }

    @Override public void onPlayerJoin(Player p) {
        moveToPlayers(p);
        p.sendMessage("[accent]Выживание: [white]защищайте ядро от волн врагов. Убийства дают опыт, ранг открывает новых юнитов.\n"
                + "[gray]/me — ваш ранг, /shop — юниты, /help — команды");
    }
    @Override public void onPlayerDeath(Player p) {}

    /** Все игроки — в одной команде (Alpha). */
    private void moveToPlayers(Player p) {
        RwTeam a = core.teams.alpha;
        if (core.teams.of(p) != a) {
            core.teams.set(p, a);
            core.units.release(p);
            core.units.autoGive(p);
        }
    }

    @Override public void onUpdate() {
        applyModeRules(); // правила могли сброситься при перезагрузке карты
        if (Groups.player.size() == 0) return; // без игроков волны не идут
        int enemies = enemiesAlive();
        countdown--;
        showHud(enemies);
        if (countdown <= 0) {
            wave++;
            spawnWave();
            countdown = Math.max(5, cfg.waveIntervalSeconds);
            for (Player p : Groups.player) {
                if (cfg.xpPerWave <= 0 || wave <= 1) continue;
                PlayerData d = core.data.get(p.uuid(), p.plainName());
                d.xp += cfg.xpPerWave;
                core.bank.reward(p, cfg.xpPerWave, "волна " + wave, false);
                core.data.markDirty(p.uuid());
                core.units.refresh(p);
            }
        }
        // поражение: ядра игроков были и все уничтожены
        if (initialCores > 0 && Vars.state.teams.cores(core.teams.alpha.team).size == 0) {
            core.modes.endMatch(core.teams.bravo, "Ядро уничтожено. Продержались волн: " + wave);
            nextRound();
            return;
        }
        // победа: отбита последняя волна
        if (cfg.winWave > 0 && wave >= cfg.winWave && enemiesAlive() == 0) {
            core.modes.endMatch(core.teams.alpha, "Все " + cfg.winWave + " волн отбиты!");
            nextRound();
        }
    }

    /** После матча: пауза и новая карта (если включён автоцикл). */
    private void nextRound() {
        if (core.config.settings.autoBootstrap) core.newRound(Math.max(5, core.config.settings.roundDelaySeconds));
    }

    @Override public void onEnd() { cleanup(); }
    @Override public void onUnload() { cleanup(); }

    private void cleanup() {
        try { Call.hideHudText(); } catch (Throwable ignored) {}
        try { removeBots(); } catch (Throwable ignored) {}
        try {
            if (prevInfinite != null) { Vars.state.rules.infiniteResources = prevInfinite; prevInfinite = null; }
            setRuleBool("canGameOver", true);
        } catch (Throwable ignored) {}
    }

    // ---------- правила ----------
    private void applyModeRules() {
        if (cfg.infiniteResources) {
            if (prevInfinite == null) prevInfinite = Vars.state.rules.infiniteResources;
            Vars.state.rules.infiniteResources = true;
        }
        // команда ботов без ядер не должна заканчивать игру; поражение определяет сам режим
        setRuleBool("canGameOver", false);
    }

    private static void setRuleBool(String field, boolean value) {
        try {
            Vars.state.rules.getClass().getField(field).setBoolean(Vars.state.rules, value);
        } catch (Throwable ignored) {} // поля нет в этой версии — не страшно
    }

    // ---------- волны ----------
    private int enemiesAlive() {
        final mindustry.game.Team bots = core.teams.bravo.team;
        return Groups.unit.count(u -> u.team == bots);
    }

    private void removeBots() {
        final mindustry.game.Team bots = core.teams.bravo.team;
        List<Unit> list = new ArrayList<>();
        Groups.unit.each(u -> u.team == bots && u.getPlayer() == null, list::add);
        for (Unit u : list) u.kill();
    }

    private void spawnWave() {
        RwTeam bravo = core.teams.bravo;
        int alive = enemiesAlive();
        int spawned = 0;
        float hp = 1f + Math.max(0f, cfg.healthGrowthPerWave) * (wave - 1);
        for (WaveUnit w : cfg.units) {
            if (wave < w.fromWave || (w.toWave > 0 && wave > w.toWave)) continue;
            UnitType type = Vars.content.unit(w.unit);
            if (type == null) { Log.warn("[RawWar] Survival: неизвестный юнит '" + w.unit + "'"); continue; }
            int n = Math.min(Math.max(1, w.max), w.base + (int) Math.floor((wave - w.fromWave) * w.perWave));
            for (int i = 0; i < n; i++) {
                if (alive + spawned >= cfg.maxEnemiesAlive) break;
                Unit u = type.create(bravo.team);
                if (!core.spawns.placeNear(u, bravo)) {
                    if (!warnedNoSpawn) { warnedNoSpawn = true; Call.sendMessage("[scarlet][Survival] Нет точек высадки врагов: /rw spawn add b"); }
                    return;
                }
                u.maxHealth = type.health * hp;
                u.health = u.maxHealth;
                u.add();
                spawned++;
            }
        }
        Call.sendMessage("[accent][Survival] Волна [white]" + wave + "[accent]: врагов [white]" + spawned
                + (cfg.winWave > 0 ? "[accent] (всего волн: " + cfg.winWave + ")" : ""));
    }

    private void showHud(int enemies) {
        try {
            String coreHp = "";
            var cores = Vars.state.teams.cores(core.teams.alpha.team);
            if (!cores.isEmpty()) {
                var cb = cores.first();
                coreHp = "\n[accent]Ядро: [white]" + (int) Math.max(0f, cb.health()) + "[gray]/" + (int) cb.maxHealth();
            }
            Call.setHudText("[accent]Волна [white]" + wave + (cfg.winWave > 0 ? "/" + cfg.winWave : "")
                    + "[gray]  |  [accent]след. через [white]" + Math.max(0, countdown) + " с"
                    + "\n[accent]Врагов: [white]" + enemies + coreHp);
        } catch (Throwable ignored) {}
    }

    // ---------- хуки ----------
    @Override public void onUnitKilled(Player killer, Unit victim) {
        if (victim.team != core.teams.bravo.team) return;
        PlayerData d = core.data.get(killer.uuid(), killer.plainName());
        d.kills++;
        d.xp += cfg.xpPerBotKill;
        core.bank.reward(killer, cfg.xpPerBotKill, "бот", false);
        core.data.markDirty(killer.uuid());
        core.units.refresh(killer);
        core.teams.alpha.score++;
    }

    @Override public boolean allowBuilding(Player p) { return cfg.allowBuilding; }

    @Override public String describe() {
        return "Survival\nВсе игроки в одной команде против волн ботов. Враги появляются в точках высадки команды "
                + core.teams.bravo.name + ". Строить можно (нужен юнит-строитель, например мега или нова).\n"
                + "Первая волна через " + cfg.firstWaveDelaySeconds + " с, затем каждые " + cfg.waveIntervalSeconds + " с. "
                + (cfg.winWave > 0 ? "Победа: отбить " + cfg.winWave + " волн." : "Волны бесконечны.")
                + " Поражение: потеря всех ядер.\nВолна сейчас: " + wave;
    }
}
