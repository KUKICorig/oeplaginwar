package rawwar.modes;

import arc.util.Log;
import arc.util.Timer;
import mindustry.gen.Call;
import mindustry.gen.Groups;
import mindustry.gen.Player;
import rawwar.core.CoreManager;
import rawwar.data.PlayerData;
import rawwar.data.ServerData;
import rawwar.modes.builtin.TeamDeathmatch;
import rawwar.modes.builtin.UnitSurvival;
import rawwar.teams.RwTeam;
import rawwar.units.UnitNode;

import java.util.LinkedHashMap;
import java.util.Map;

/** Mode Manager: реестр, выбор, запуск и завершение режимов. */
public class ModeManager {
    private final CoreManager core;
    private final ModeLoader loader;
    private final Map<String, GameMode> modes = new LinkedHashMap<>();
    private GameMode active;
    private boolean running;
    private long startedAt;
    private Timer.Task ticker;

    public ModeManager(CoreManager core) { this.core = core; this.loader = new ModeLoader(core); }

    public void load() {
        unloadAll();
        register(new TeamDeathmatch());
        register(new UnitSurvival());
        for (GameMode m : loader.discover()) register(m);
        select(core.config.settings.activeMode, false);
        if (core.config.settings.autoStartMode && active != null) start();
    }

    private void register(GameMode m) {
        try {
            m.attach(core);
            m.onLoad();
            modes.put(m.getId(), m);
            Log.info("[RawWar] Режим зарегистрирован: " + m.getId());
        } catch (Throwable t) {
            Log.err("[RawWar] Ошибка загрузки режима " + m.getId() + ": " + t);
        }
    }

    public Map<String, GameMode> all() { return modes; }
    public GameMode active() { return active; }
    public String activeId() { return active == null ? "" : active.getId(); }
    public boolean running() { return running; }

    public boolean select(String id, boolean persist) {
        GameMode m = null;
        for (GameMode g : modes.values()) if (g.getId().equalsIgnoreCase(id)) m = g;
        if (m == null) return false;
        if (running) stop();
        active = m;
        core.menus.clearExtras();
        if (persist) { core.config.settings.activeMode = m.getId(); core.config.save(); }
        return true;
    }

    public boolean start() {
        if (active == null || running) return false;
        core.teams.resetScores();
        core.units.clearAll();
        running = true;
        startedAt = System.currentTimeMillis();
        try { active.onStart(); } catch (Throwable t) { Log.err("[RawWar] onStart: " + t); }
        for (Player p : Groups.player) { core.teams.assign(p); core.units.autoGive(p); }
        if (ticker != null) ticker.cancel();
        ticker = Timer.schedule(() -> {
            if (running && active != null) { try { active.onUpdate(); } catch (Throwable t) { Log.err("[RawWar] onUpdate: " + t); } }
        }, 1f, 1f);
        Call.sendMessage("[accent][RawWar] Матч начался: [white]" + active.getName());
        return true;
    }

    /** Принудительная остановка без победителя. */
    public void stop() { endMatch(null, "Остановлено администратором"); }

    /** Завершение матча. winner == null — ничья/остановка. */
    public void endMatch(RwTeam winner, String summary) {
        if (!running) return;
        running = false;
        if (ticker != null) { ticker.cancel(); ticker = null; }
        try { active.onEnd(); } catch (Throwable t) { Log.err("[RawWar] onEnd: " + t); }

        ServerData.MatchRecord r = new ServerData.MatchRecord();
        r.mode = active.getId();
        r.winner = winner == null ? "-" : winner.name;
        r.summary = summary;
        r.endedAt = System.currentTimeMillis();
        r.durationSeconds = (int) ((r.endedAt - startedAt) / 1000);
        core.data.recordMatch(r);

        if (winner != null) {
            if (winner == core.teams.alpha) core.data.server.alphaWins++; else core.data.server.bravoWins++;
        } else core.data.server.draws++;
        for (Player p : Groups.player) {
            RwTeam t = core.teams.of(p);
            if (t == null) continue;
            PlayerData d = core.data.get(p.uuid(), p.plainName());
            d.matches++;
            if (winner != null) { if (t == winner) { d.wins++; d.xp += core.config.settings.units.xpPerWin; core.bank.reward(p, core.config.settings.units.xpPerWin, "победа в матче", true); } else d.losses++; }
            core.data.markDirty(p.uuid());
            core.units.refresh(p);
        }
        core.data.saveAll();
        Call.sendMessage("[accent][RawWar] Матч завершён. " + (winner == null ? "Победитель не определён." : "Победила команда [white]" + winner.name + "[accent].") + " " + summary);
    }

    // ---- проксирование событий ----
    public void playerJoin(Player p) { if (running && active != null) try { active.onPlayerJoin(p); } catch (Throwable t) { Log.err(t); } }
    public void playerDeath(Player p) { if (running && active != null) try { active.onPlayerDeath(p); } catch (Throwable t) { Log.err(t); } }
    public void kill(Player killer, Player victim) { if (running && active != null) try { active.onKill(killer, victim); } catch (Throwable t) { Log.err(t); } }

    public void unitKilled(Player killer, mindustry.gen.Unit victim) { if (running && active != null) try { active.onUnitKilled(killer, victim); } catch (Throwable t) { Log.err(t); } }

    /** Строительство разрешает сам активный режим (во время матча). */
    public boolean allowBuilding(Player p) {
        return active != null && running && active.allowBuilding(p);
    }
    public boolean allowUnit(Player p, UnitNode c) { return active == null || active.allowUnit(p, c); }

    public String describe() {
        return active == null ? "Режим не выбран." : active.describe() + "\n\nСостояние: " + (running ? "идёт матч" : "ожидание")
                + "\n" + core.teams.alpha.name + ": " + core.teams.alpha.score + "  |  " + core.teams.bravo.name + ": " + core.teams.bravo.score;
    }

    private void unloadAll() {
        if (running) { running = false; if (ticker != null) ticker.cancel(); }
        for (GameMode m : modes.values()) { try { m.onUnload(); } catch (Throwable t) { Log.err(t); } }
        modes.clear();
        active = null;
        loader.close();
    }

    public void stopAll() { unloadAll(); }
    public arc.files.Fi modeDir(String id) { arc.files.Fi f = core.root.child("modes").child(id); f.mkdirs(); return f; }
}
