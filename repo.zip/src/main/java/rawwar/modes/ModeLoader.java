package rawwar.modes;

import arc.files.Fi;
import arc.util.Log;
import arc.util.serialization.JsonReader;
import arc.util.serialization.JsonValue;
import rawwar.core.CoreManager;

import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.List;

/**
 * Mode Loader: ищет режимы в RawWar/modes/&lt;Имя&gt;/.
 * В каждой папке ожидается mode.json: {"id":"...","main":"pkg.Class","jar":"file.jar"}.
 */
public class ModeLoader {
    private final CoreManager core;
    private final List<URLClassLoader> loaders = new ArrayList<>();

    public ModeLoader(CoreManager core) { this.core = core; }

    public List<GameMode> discover() {
        List<GameMode> found = new ArrayList<>();
        Fi dir = core.root.child("modes");
        dir.mkdirs();
        for (Fi d : dir.list()) {
            if (!d.isDirectory()) continue;
            Fi meta = d.child("mode.json");
            if (!meta.exists()) continue; // например, папка с конфигом встроенного режима
            try {
                JsonValue v = new JsonReader().parse(meta);
                String main = v.getString("main");
                String jarName = v.getString("jar", d.name() + ".jar");
                Fi jar = d.child(jarName);
                if (!jar.exists()) throw new IllegalStateException("нет файла " + jarName);
                URLClassLoader cl = new URLClassLoader(new URL[]{jar.file().toURI().toURL()}, getClass().getClassLoader());
                loaders.add(cl);
                Object o = cl.loadClass(main).getDeclaredConstructor().newInstance();
                if (!(o instanceof GameMode)) throw new IllegalStateException(main + " не реализует GameMode");
                found.add((GameMode) o);
            } catch (Throwable t) {
                Log.err("[RawWar] Не удалось загрузить режим из " + d.name() + ": " + t);
            }
        }
        return found;
    }

    public void close() {
        for (URLClassLoader l : loaders) { try { l.close(); } catch (Throwable ignored) {} }
        loaders.clear();
    }
}
