package rawwar;

import arc.util.CommandHandler;
import arc.util.Log;
import mindustry.gen.Player;
import mindustry.mod.Plugin;
import rawwar.commands.CommandManager;
import rawwar.core.CoreManager;

/** Точка входа плагина RawWar. */
public class RawWarPlugin extends Plugin {
    private CoreManager core;

    @Override
    public void init() {
        core = new CoreManager();
        try {
            core.start();
        } catch (Throwable t) {
            Log.err("[RawWar] Не удалось запустить плагин", t);
        }
    }

    @Override
    public void registerServerCommands(CommandHandler handler) {
        // "[args...]" — весь хвост одной строкой, без лимита на число аргументов (делится в CommandManager.split)
        handler.register("rw", "[args...]", "RawWar: rw help | rw spawn add <a|b> <x> <y> | rw mapgen | rw mode | rw team | rw units list|add|remove|set | rw bank give|take|set|show | rw reload", args -> {
            if (core != null) core.commands.handleConsole(CommandManager.split(args));
        });
    }

    /** Короткие команды: имя -> внутренняя подкоманда /rw. */
    private static final String[][] SHORT = {
            {"shop", "shop", "Магазин юнитов: /shop, /shop list, /shop <юнит>"},
            {"units", "shop", "То же, что /shop"},
            {"buy", "buy", "Купить юнита за kys с баланса: /buy <юнит>"},
            {"research", "research", "Исследовать юнита бесплатно: /research <юнит>"},
            {"unlock", "research", "То же, что /research"},
            {"play", "play", "Играть выбранным юнитом: /play <юнит>"},
            {"me", "me", "Ваш ранг, опыт, баланс kys и юнит"},
            {"help", "help", "Справка по командам: меню с разделами, /help all, /help <команда>"},
            {"commands", "help", "То же, что /help"},
            {"stats", "me", "То же, что /me"},
            {"bank", "bank", "Банк kys: /bank — меню; /bank send|deposit|close|plans|history"},
            {"balance", "balance", "Ваш баланс kys и вклады"},
            {"kys", "balance", "То же, что /balance"},
            {"pay", "pay", "Перевести kys игроку с баланса: /pay <игрок> <сумма>"},
            {"bankadmin", "bankadmin", "Админ: /bankadmin give|take|set|show <игрок> [сумма]"},
            {"team", "team", "Состав команды: /team, /team switch"},
            {"spawn", "spawn", "Точки спавна (админ): /spawn add|list|show|remove|clear|edit"},
            {"mapgen", "mapgen", "Генератор карты (админ): /mapgen — меню; /mapgen set|show|keys|preset|reset|generate"},
            {"mode", "mode", "Режимы (админ): /mode list|select <id>|start|stop"},
            {"shopadd", "shopadd", "Добавить юнита в магазин (админ): /shopadd <юнит> [ранг] [опыт] [цена] [название]"},
            {"shopremove", "shopremove", "Убрать юнита из магазина (админ): /shopremove <юнит>"},
            {"shopset", "shopset", "Изменить юнита (админ): /shopset <юнит> <поле> <значение>"},
    };

    @Override
    public void registerClientCommands(CommandHandler handler) {
        for (String name : new String[]{"rw", "war", "rwar"}) {
            handler.<Player>register(name, "[args...]", "RawWar: меню и команды (/help)", (args, player) -> {
                if (core != null) core.commands.handle(player, CommandManager.split(args));
            });
        }
        handler.removeCommand("help"); // заменяем стандартную /help сервера справкой RawWar
        for (String[] c : SHORT) {
            final String sub = c[1];
            handler.<Player>register(c[0], "[args...]", c[2], (args, player) -> {
                if (core == null) return;
                String[] rest = CommandManager.split(args);
                String[] all = new String[rest.length + 1];
                all[0] = sub;
                System.arraycopy(rest, 0, all, 1, rest.length);
                core.commands.handle(player, all);
            });
        }
    }
}
