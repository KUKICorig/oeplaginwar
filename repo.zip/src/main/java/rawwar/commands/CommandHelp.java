package rawwar.commands;

import mindustry.gen.Player;
import rawwar.core.CoreManager;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Справочник команд: единый реестр (раздел, синтаксис, описание, пример, уровень доступа).
 * Используется для /help (меню и текст), /rw help [команда], а также для подсказки при неверных аргументах.
 * Игрок видит только те разделы и команды, к которым у него есть доступ.
 *
 * Чтобы добавить команду: строка add(Section.X, "ключ", "/синтаксис", "описание", "пример") в блоке static.
 * Ключ из одного слова — отдельная команда (кнопка в меню), «ключ подкоманда» — её подкоманда (показывается в карточке команды).
 */
public final class CommandHelp {
    public enum Level { PLAYER, ADMIN, OWNER }

    /** Раздел справочника. Раздел виден, если доступен его уровень. */
    public enum Section {
        SHOP("shop", "Магазин юнитов", Level.PLAYER, "Список юнитов, исследование, покупка, выбор юнита."),
        BANK("bank", "Банк kys", Level.PLAYER, "Баланс, вклады, переводы игрокам."),
        PLAYER("player", "Профиль и команда", Level.PLAYER, "Статистика, состав команды, меню, справка."),
        SPAWN("spawn", "Точки спавна", Level.ADMIN, "Где появляются игроки и боты."),
        MAPGEN("mapgen", "Генератор карты", Level.ADMIN, "Карта из шестиугольников с точками спавна."),
        MODES("modes", "Режимы и команды", Level.ADMIN, "Запуск режимов, баланс команд, перезагрузка конфигов."),
        SHOP_ADMIN("shopadmin", "Магазин: управление", Level.ADMIN, "Добавить, убрать и изменить юнитов без правки файла."),
        BANK_ADMIN("bankadmin", "Банк: управление", Level.ADMIN, "Выдать, списать и посмотреть баланс игрока."),
        OWNER("owner", "Создатель", Level.OWNER, "Команды создателя плагина.");

        public final String id, title, desc;
        public final Level level;
        Section(String id, String title, Level level, String desc) {
            this.id = id; this.title = title; this.level = level; this.desc = desc;
        }

        public String color() {
            return level == Level.PLAYER ? "[sky]" : level == Level.ADMIN ? "[orange]" : "[scarlet]";
        }
    }

    public static final class Entry {
        public final Section section;
        public final Level level;
        public final String key, usage, desc, example;
        Entry(Section section, String key, String usage, String desc, String example) {
            this.section = section; this.level = section.level;
            this.key = key; this.usage = usage; this.desc = desc; this.example = example;
        }
        public boolean isSub() { return key.contains(" "); }
    }

    private static final List<Entry> ALL = new ArrayList<>();

    private static void add(Section s, String key, String usage, String desc, String example) {
        ALL.add(new Entry(s, key, usage, desc, example));
    }

    static {
        Section SH = Section.SHOP, BK = Section.BANK, PL = Section.PLAYER, SP = Section.SPAWN, MG = Section.MAPGEN, MD = Section.MODES,
                SA = Section.SHOP_ADMIN, BA = Section.BANK_ADMIN, OW = Section.OWNER;

        // --- магазин юнитов ---
        add(SH, "shop", "/shop [юнит|тип]", "Магазин: меню со списком юнитов. С названием юнита — его карточка в чате, с типом (air, legs, mech, tank, hover) — меню с фильтром. Алиас: /units.", "/shop fortress");
        add(SH, "shop list", "/shop list [тип]", "Список юнитов текстом в чате.", "/shop list mech");
        add(SH, "buy", "/buy <юнит>", "Купить юнита за kys с баланса (ранг и опыт не нужны). Без названия — открыть магазин.", "/buy fortress");
        add(SH, "research", "/research <юнит>", "Исследовать бесплатно: нужны ранг и опыт, указанные в карточке (опыт не тратится). Алиас: /unlock.", "/research mace");
        add(SH, "play", "/play [юнит]", "Играть выбранным открытым юнитом. Без названия — снять выбор (выдаётся лучший открытый).", "/play nova");

        // --- банк ---
        add(BK, "bank", "/bank [send|deposit|close|plans|deposits|history]", "Банк kys: без аргументов — меню (вклады, переводы, история). Награды приходят на баланс, с него же платятся юниты, вклады и переводы. Суммы: 500, 1k, 2.5k, 50%, all.", "/bank deposit day 1k");
        add(BK, "bank send", "/bank send <игрок> <сумма|all|%>", "Перевести kys игроку (то же, что /pay).", "/bank send Vasya 250");
        add(BK, "bank deposit", "/bank deposit <тариф> <сумма|all|%>", "Открыть срочный вклад с баланса. Тариф — номер, id или название из /bank plans. В конце срока выплата с доходом придёт на баланс, досрочное закрытие — со штрафом и без дохода.", "/bank deposit day 1k");
        add(BK, "bank close", "/bank close <номер вклада>", "Закрыть вклад досрочно: вернётся сумма за вычетом штрафа, доход не выплачивается.", "/bank close 2");
        add(BK, "bank plans", "/bank plans", "Тарифы вкладов: срок, доход, минимальная сумма.", "");
        add(BK, "bank deposits", "/bank deposits", "Ваши открытые вклады.", "");
        add(BK, "bank history", "/bank history", "Последние операции банка.", "");
        add(BK, "balance", "/balance", "Ваш баланс в kys и вклады. Алиас: /kys.", "");
        add(BK, "pay", "/pay <игрок> <сумма|all|%>", "Перевести kys с баланса игроку (он должен быть в сети). Комиссия задаётся в settings.json (bank.transferFeePercent).", "/pay Vasya 250");

        // --- профиль и команда ---
        add(PL, "menu", "/rw", "Главное меню: юниты, банк kys, справка, информация, статистика.", "");
        add(PL, "help", "/help [раздел|команда|all]", "Справка по командам. Без аргументов — меню с разделами, all — полный список в чат, раздел или команда — подробности. Работает и как /rw help.", "/help bank");
        add(PL, "me", "/me", "Ваш ранг, опыт, баланс, текущий юнит и статистика. Алиас: /stats.", "");
        add(PL, "info", "/rw info", "Правила и состояние текущего режима.", "");
        add(PL, "team", "/team [switch]", "Состав вашей команды; switch — перейти в другую (если разрешено настройками).", "/team switch");

        // --- спавн ---
        add(SP, "spawn", "/spawn", "Редактор точек спавна (меню). Подкоманды: add, edit, show, list, remove, clear.", "");
        add(SP, "spawn add", "/spawn add <a|b> [x y]", "Добавить точку команды. Без координат — туда, где вы стоите.", "/spawn add a   или   /spawn add b 120 45");
        add(SP, "spawn edit", "/spawn edit <a|b|off>", "Режим тапа: нажатие на карту добавляет точку, нажатие рядом с точкой (до 1 тайла) удаляет её.", "/spawn edit a");
        add(SP, "spawn show", "/spawn show [a|b]", "Подписать точки номерами на карте (на 15 секунд).", "/spawn show");
        add(SP, "spawn list", "/spawn list [a|b]", "Список точек с номерами (номера начинаются с 1).", "/spawn list b");
        add(SP, "spawn remove", "/spawn remove <a|b> [номер]", "Удалить точку по номеру из list. Без номера — последнюю.", "/spawn remove a 2");
        add(SP, "spawn clear", "/spawn clear <a|b>", "Удалить ВСЕ точки команды.", "/spawn clear b");

        // --- генератор карты ---
        add(MG, "mapgen", "/mapgen [show|keys|set|preset|reset|generate]", "Генератор карты: центральный шестиугольник и ещё несколько вокруг него через равные углы, в каждом точка спавна. Без аргументов — меню с кнопками −/+, пресетами и запуском.", "/mapgen");
        add(MG, "mapgen show", "/mapgen show", "Размер карты, расстояния и координаты точек спавна по текущим настройкам.", "");
        add(MG, "mapgen keys", "/mapgen keys", "Все настройки с текущими значениями и допустимыми пределами.", "");
        add(MG, "mapgen set", "/mapgen set <ключ> <значение>", "Изменить настройку (ключи — /mapgen keys). Например radius, squash, satellites, distance, corridorWidth, teamAssign, floor, wall, ores, seed.", "/mapgen set satellites 3");
        add(MG, "mapgen preset", "/mapgen preset <small|medium|large>", "Размерный пресет: радиус, зазор, ширина проходов.", "/mapgen preset large");
        add(MG, "mapgen reset", "/mapgen reset", "Вернуть настройки генератора по умолчанию.", "");
        add(MG, "mapgen generate", "/mapgen generate [зерно]", "Создать карту: матч останавливается, мир перезагружается у всех игроков, точки спавна заменяются. Одинаковое зерно даёт ту же карту.", "/mapgen generate 12345");

        // --- режимы и команды ---
        add(MD, "mode", "/mode list|select <id>|start|stop", "Игровые режимы: список, выбор, запуск и остановка матча.", "/mode select TeamDeathmatch");
        add(MD, "team set", "/team set <игрок> <a|b>", "Принудительно перевести игрока в команду.", "/team set Vasya b");
        add(MD, "team balance", "/team balance", "Выровнять численность команд.", "");
        add(MD, "reload", "/rw reload", "Перечитать settings.json, units.json, spawns.json и режимы без перезапуска сервера.", "");

        // --- магазин: управление ---
        add(SA, "shopadd", "/shopadd <юнит> [ранг] [опыт] [цена] [название]", "Добавить юнита в магазин (в том числе из мода). Опыт 0 = выдаётся сразу, -1 = только купить; цена 0 = купить нельзя.", "/shopadd my-boss 3 500 1000 Мой Босс");
        add(SA, "shopremove", "/shopremove <юнит>", "Убрать юнита из магазина.", "/shopremove my-boss");
        add(SA, "shopset", "/shopset <юнит> <поле> <значение>", "Изменить юнита. Поля: name, desc, rank, xp, price, enabled, category, limit, teamlimit.", "/shopset my-boss price 800");

        // --- банк: управление ---
        add(BA, "bankadmin", "/bankadmin give|take|set|show <игрок> [сумма]", "Баланс игрока: give — выдать kys, take — списать, set — установить, show — сводка (баланс, вклады). Игрок должен быть в сети. В консоли: rw bank …", "/bankadmin give Vasya 5k");

        // --- создатель ---
        add(OW, "owner", "/rw owner reload|debug|data|modes|units|admin add|remove <игрок>", "Команды создателя плагина.", "/rw owner admin add Vasya");
    }

    private CommandHelp() {}

    private static Level levelOf(CoreManager core, Player p) {
        if (p == null || core.isOwner(p)) return Level.OWNER; // консоль доверенная
        return core.isAdmin(p) ? Level.ADMIN : Level.PLAYER;
    }

    private static String fix(String s, Player p) { return p == null ? s.replace("/rw", "rw") : s; }

    // ---------- разделы (для меню /help) ----------
    /** Разделы, доступные игроку (консоль видит все). */
    public static List<Section> sections(CoreManager core, Player p) {
        Level lv = levelOf(core, p);
        List<Section> out = new ArrayList<>();
        for (Section s : Section.values()) if (s.level.ordinal() <= lv.ordinal()) out.add(s);
        return out;
    }

    /** Команды раздела без подкоманд — кнопки меню. */
    public static List<Entry> commands(Section s) {
        List<Entry> out = new ArrayList<>();
        for (Entry e : ALL) if (e.section == s && !e.isSub()) out.add(e);
        return out;
    }

    /** Раздел по id или началу названия; null, если нет такого или нет доступа. */
    public static Section findSection(CoreManager core, Player p, String q) {
        if (q == null) return null;
        String k = q.trim().toLowerCase(Locale.ROOT);
        if (k.isEmpty()) return null;
        List<Section> list = sections(core, p);
        for (Section s : list) if (s.id.equals(k)) return s;
        for (Section s : list) if (s.title.toLowerCase(Locale.ROOT).startsWith(k)) return s;
        return null;
    }

    /** Весь раздел текстом: каждая команда и её подкоманды, с описанием. */
    public static String sectionText(Section s, Player p) {
        StringBuilder sb = new StringBuilder(s.color()).append(s.title).append("[white] — ").append(s.desc).append("\n");
        for (Entry e : ALL) {
            if (e.section != s) continue;
            sb.append(e.isSub() ? "  " : "").append("[accent]").append(fix(e.usage, p)).append("[white] — ").append(e.desc).append("\n");
        }
        return sb.toString().trim();
    }

    // ---------- тексты ----------
    /** Полный список: разделы, в каждом по строке на команду; только доступные. */
    public static String overview(CoreManager core, Player p) {
        StringBuilder sb = new StringBuilder("[accent]Команды RawWar[white] (меню: /help, подробно: " + (p == null ? "rw help <команда>" : "/help <команда>") + ")\n");
        Level section = null;
        for (Section s : sections(core, p)) {
            if (section != s.level) {
                section = s.level;
                sb.append(s.level == Level.PLAYER ? "[sky]== Игроки ==\n" : s.level == Level.ADMIN ? "[orange]== Администраторы ==\n" : "[scarlet]== Создатель ==\n");
            }
            sb.append("[white]").append(s.title).append(":\n");
            for (Entry e : commands(s)) sb.append("  [accent]").append(fix(e.usage, p)).append("[white] — ").append(e.desc).append("\n");
        }
        return sb.toString().trim();
    }

    /** Подробности по команде (key — "spawn" или "spawn add"). null, если такой нет или нет доступа. */
    public static String detail(CoreManager core, Player p, String key) {
        Level lv = levelOf(core, p);
        String k = key == null ? "" : key.trim().toLowerCase().replaceAll("\\s+", " ");
        if (k.startsWith("/")) k = k.substring(1);
        StringBuilder sb = new StringBuilder();
        for (Entry e : ALL) {
            if (e.level.ordinal() > lv.ordinal()) continue;
            if (!(e.key.equals(k) || e.key.startsWith(k + " "))) continue;
            sb.append("[accent]").append(fix(e.usage, p)).append("[white]\n  ").append(e.desc).append("\n");
            if (!e.example.isEmpty()) sb.append("  [gray]Пример: ").append(fix(e.example, p)).append("\n");
        }
        return sb.length() == 0 ? null : sb.toString().trim();
    }

    /** Ответ на /help <запрос>: команда, затем раздел. null, если ничего не найдено. */
    public static String lookup(CoreManager core, Player p, String q) {
        String d = detail(core, p, q);
        if (d != null) return d;
        Section s = findSection(core, p, q);
        return s == null ? null : sectionText(s, p);
    }

    /** Подсказка при неверных аргументах. key — ключ команды из реестра. */
    public static String usage(String key) {
        for (Entry e : ALL) {
            if (!e.key.equals(key)) continue;
            return "[scarlet]Неверные аргументы.\n[accent]Использование: [white]" + e.usage
                    + (e.example.isEmpty() ? "" : "\n[gray]Пример: " + e.example)
                    + "\n[gray]Подробнее: /help " + e.key;
        }
        return "[scarlet]Неверные аргументы. [gray]/help";
    }
}
