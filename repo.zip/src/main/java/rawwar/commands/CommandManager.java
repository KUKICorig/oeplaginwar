package rawwar.commands;

import mindustry.gen.Player;
import rawwar.core.CoreManager;

/** Command System: единая точка входа для /rw, проверка прав на стороне сервера. */
public class CommandManager {
    public final CoreManager core;
    private final PlayerCommands player;
    private final AdminCommands admin;
    private final OwnerCommands owner;

    public CommandManager(CoreManager core) {
        this.core = core;
        this.player = new PlayerCommands(core);
        this.admin = new AdminCommands(core);
        this.owner = new OwnerCommands(core);
    }

    static String arg(String[] a, int i) { return i < a.length && a[i] != null ? a[i] : ""; }

    /**
     * Команда зарегистрирована как "[args...]" — Mindustry отдаёт весь хвост одной строкой
     * (иначе больше N аргументов отвергаются: /rw spawn add b 120 45 не проходило).
     * Здесь строка делится на слова.
     */
    public static String[] split(String[] raw) {
        if (raw == null || raw.length == 0 || raw[0] == null) return new String[0];
        String s = raw[0].trim();
        return s.isEmpty() ? new String[0] : s.split("\\s+");
    }

    /** args: [sub] [a] [b] ... */
    public void handle(Player p, String[] args) {
        String sub = arg(args, 0).toLowerCase();
        String[] rest = args.length > 1 ? java.util.Arrays.copyOfRange(args, 1, args.length) : new String[0];
        switch (sub) {
            case "":
                core.menus.open(p);
                return;
            case "owner":
                if (!core.isOwner(p)) { p.sendMessage("[scarlet]Нет доступа."); return; }
                owner.run(p, rest);
                return;
            case "admin":
            case "reload":
            case "mode":
            case "spawn":
            case "mapgen":
            case "shopadd":
            case "shopremove":
            case "shopset":
            case "bankadmin":
                if (!core.isAdmin(p)) { p.sendMessage("[scarlet]Нет доступа. [gray]Ваши команды: /help"); return; }
                admin.run(p, sub, rest);
                return;
            case "team":
                // /rw team — для всех; /rw team set|balance — только админам
                if (rest.length > 0 && (rest[0].equalsIgnoreCase("set") || rest[0].equalsIgnoreCase("balance"))) {
                    if (!core.isAdmin(p)) { p.sendMessage("[scarlet]Нет доступа. [gray]Ваши команды: /help"); return; }
                    admin.run(p, sub, rest);
                } else player.team(p, rest);
                return;
            default:
                player.run(p, sub, rest);
        }
    }

    /** Консольная команда: полный доступ (консоль сервера доверенная). */
    public void handleConsole(String[] args) {
        String sub = arg(args, 0).toLowerCase();
        String[] rest = args.length > 1 ? java.util.Arrays.copyOfRange(args, 1, args.length) : new String[0];
        admin.runConsole(sub.isEmpty() ? "help" : sub, rest);
    }
}
