package rawwar.commands;

import mindustry.gen.Player;
import rawwar.core.CoreManager;
import rawwar.data.PlayerData;
import rawwar.teams.RwTeam;
import rawwar.bank.BankManager;
import rawwar.units.UnitNode;

/** Игровые команды (/shop, /buy, /research, /play, /me, /team, /bank, /help, /rw info). */
public class PlayerCommands {
    private final CoreManager core;
    PlayerCommands(CoreManager core) { this.core = core; }

    void run(Player p, String sub, String[] a) {
        switch (sub) {
            case "shop":
            case "units":
            case "tech":
                shop(p, a);
                break;
            case "buy":
                buy(p, a);
                break;
            case "research":
            case "unlock":
                research(p, a);
                break;
            case "play":
            case "use":
                play(p, a);
                break;
            case "bank":
                bank(p, a);
                break;
            case "balance":
            case "bal":
                balance(p);
                break;
            case "pay":
                send(p, a);
                break;
            case "me":
            case "unit":
            case "stats": {
                PlayerData d = core.data.get(p.uuid(), p.plainName());
                p.sendMessage(core.units.statusText(p) + "\n[accent]Убийств: [white]" + d.kills + " [accent]Смертей: [white]" + d.deaths
                        + " [accent]Побед: [white]" + d.wins + " [accent]Поражений: [white]" + d.losses + " [accent]Матчей: [white]" + d.matches);
                break;
            }
            case "info":
                p.sendMessage("[accent]" + core.modes.describe());
                break;
            case "help":
                help(p, a);
                break;
            default:
                p.sendMessage("[scarlet]Неизвестная команда: [white]" + sub + "\n[accent]Список ваших команд: [white]/help");
        }
    }

    // ---------- банк (kys) ----------
    private PlayerData pd(Player p) { return core.data.get(p.uuid(), p.plainName()); }

    private void balance(Player p) {
        PlayerData d = pd(p);
        p.sendMessage(core.bank.overview(p, d) + "\n[gray]Меню: /bank   Справка: /help bank");
    }

    /** /bank — меню; /bank send|deposit|close|plans|deposits|history|balance. */
    private void bank(Player p, String[] a) {
        if (a.length == 0) { core.bankMenu.open(p); return; }
        PlayerData d = pd(p);
        core.bank.settle(p, d, true);
        String op = a[0].toLowerCase();
        String[] r = java.util.Arrays.copyOfRange(a, 1, a.length);
        switch (op) {
            case "balance": case "bal": case "info":
                balance(p);
                return;
            case "send": case "pay":
                send(p, r);
                return;
            case "plans":
                p.sendMessage("[accent]Тарифы вкладов:\n" + core.bank.plansText() + "\n[gray]Открыть: /bank deposit <тариф> <сумма>");
                return;
            case "deposits": case "list":
                p.sendMessage("[accent]Ваши вклады:\n" + core.bank.depositsText(d));
                return;
            case "deposit": case "dep": {
                if (r.length < 2) { p.sendMessage(CommandHelp.usage("bank deposit") + "\n[accent]Тарифы:\n" + core.bank.plansText()); return; }
                // тариф может состоять из нескольких слов: последний аргумент — сумма
                String planQ = String.join(" ", java.util.Arrays.copyOfRange(r, 0, r.length - 1));
                rawwar.config.Settings.DepositPlan plan = core.bank.plan(planQ);
                if (plan == null) { p.sendMessage("[scarlet]Тариф не найден: [white]" + planQ + "\n[accent]Тарифы:\n" + core.bank.plansText()); return; }
                long v = BankManager.parseAmount(r[r.length - 1], d.balance);
                if (v < 1) { p.sendMessage("[scarlet]Не понял сумму: [white]" + r[r.length - 1] + "\n" + CommandHelp.usage("bank deposit")); return; }
                String err = core.bank.openDeposit(p, plan, v);
                p.sendMessage(err != null ? "[scarlet]" + err : "[lime]Вклад открыт: " + BankManager.money(v) + "[lime] -> " + BankManager.money(BankManager.payoutOf(plan, v))
                        + "[lime] через " + BankManager.dur(plan.minutes * 60_000L));
                return;
            }
            case "close": {
                int id = -1;
                try { if (r.length > 0) id = Integer.parseInt(r[0].replace("#", "")); } catch (NumberFormatException ignored) {}
                if (id < 1) { p.sendMessage(CommandHelp.usage("bank close") + "\n[accent]Ваши вклады:\n" + core.bank.depositsText(d)); return; }
                rawwar.data.PlayerData.Deposit dep = core.bank.deposit(d, id);
                long refund = dep == null ? 0 : dep.amount - core.bank.penaltyOf(dep.amount);
                String err = core.bank.closeDeposit(p, id);
                p.sendMessage(err != null ? "[scarlet]" + err : "[orange]Вклад #" + id + " закрыт досрочно, на баланс вернулось " + BankManager.money(refund));
                return;
            }
            case "history":
                p.sendMessage("[accent]История операций:\n" + core.bank.historyText(d));
                return;
            case "help":
                p.sendMessage(CommandHelp.detail(core, p, "bank"));
                return;
            default:
                p.sendMessage("[scarlet]Неизвестная подкоманда банка: [white]" + op + "\n" + CommandHelp.detail(core, p, "bank"));
        }
    }

    /** /pay <игрок> <сумма> и /bank send <игрок> <сумма>: имя может содержать пробелы, сумма — последний аргумент. */
    private void send(Player p, String[] a) {
        if (a.length < 2) { p.sendMessage(CommandHelp.usage("pay")); return; }
        PlayerData d = pd(p);
        core.bank.settle(p, d, true);
        String name = String.join(" ", java.util.Arrays.copyOfRange(a, 0, a.length - 1));
        Player to = core.bank.findPlayer(name);
        if (to == null) { p.sendMessage("[scarlet]Игрок не найден или имя неоднозначно (он должен быть в сети): [white]" + name); return; }
        long max = core.bank.maxSend(d.balance);
        long v = BankManager.parseAmount(a[a.length - 1], max);
        if (v < 1) { p.sendMessage("[scarlet]Не понял сумму: [white]" + a[a.length - 1] + "\n" + CommandHelp.usage("pay")); return; }
        String err = core.bank.send(p, to, v);
        p.sendMessage(err != null ? "[scarlet]" + err : "[lime]Переведено: " + BankManager.money(v) + "[lime] игроку [white]" + to.plainName() + "[lime]. Баланс: " + BankManager.money(d.balance));
    }

    /** /help — меню с разделами; /help all — полный список в чат; /help <раздел|команда> — подробности. */
    private void help(Player p, String[] a) {
        String key = String.join(" ", a).trim();
        if (key.isEmpty()) { core.helpMenu.open(p); return; }
        if (key.equalsIgnoreCase("all") || key.equals("все") || key.equals("всё")) { p.sendMessage(CommandHelp.overview(core, p)); return; }
        String d = CommandHelp.lookup(core, p, key);
        p.sendMessage(d != null ? d : "[scarlet]Такой команды или раздела нет (или нет доступа): [white]" + key + "\n[accent]Меню: [white]/help   [accent]Полный список: [white]/help all");
    }

    private static String join(String[] a, int from) {
        return a.length <= from ? "" : String.join(" ", java.util.Arrays.copyOfRange(a, from, a.length));
    }

    /** /shop — меню; /shop list [тип] — список в чат; /shop <юнит> — карточка; /shop <тип> — меню с фильтром. */
    private void shop(Player p, String[] a) {
        if (a.length == 0) { core.menus.openTech(p); return; }
        String first = a[0].toLowerCase();
        switch (first) {
            case "list": {
                String cat = null;
                if (a.length > 1) {
                    cat = core.units.parseCategory(a[1]);
                    if (cat == null) { p.sendMessage("[scarlet]Такого типа нет. [gray]" + core.units.categories()); return; }
                }
                p.sendMessage(core.units.listText(p, cat));
                return;
            }
            // старые формы /rw tech buy|unlock|play|info <юнит> продолжают работать
            case "buy": buy(p, java.util.Arrays.copyOfRange(a, 1, a.length)); return;
            case "unlock": case "research": research(p, java.util.Arrays.copyOfRange(a, 1, a.length)); return;
            case "play": play(p, java.util.Arrays.copyOfRange(a, 1, a.length)); return;
            case "info": a = java.util.Arrays.copyOfRange(a, 1, a.length); break;
            default:
        }
        String q = join(a, 0);
        UnitNode n = core.units.find(q);
        if (n != null) {
            p.sendMessage(core.units.nodeText(p, n) + "\n[gray]/research " + n.id + "   /buy " + n.id + "   /play " + n.id);
            return;
        }
        String cat = core.units.parseCategory(q);
        if (cat != null) { core.menus.openTech(p, cat); return; }
        p.sendMessage("[scarlet]" + core.units.notFound(q));
    }

    /** /buy <юнит> — купить за kys; без аргумента открывает магазин. */
    private void buy(Player p, String[] a) {
        if (a.length == 0) { p.sendMessage(CommandHelp.usage("buy")); core.menus.openTech(p); return; }
        String q = join(a, 0);
        String err = core.units.buy(p, q);
        if (err != null) { p.sendMessage("[scarlet]" + err); return; }
        UnitNode n = core.units.find(q);
        p.sendMessage("[lime]Куплено: [white]" + (n == null ? q : n.displayName())
                + "[lime]. Баланс: [white]" + core.bank.balance(core.data.get(p.uuid(), p.plainName())) + " kys[lime]. Играть: /play " + (n == null ? q : n.id));
    }

    /** /research <юнит> — бесплатное исследование по рангу и опыту. */
    private void research(Player p, String[] a) {
        if (a.length == 0) { p.sendMessage(CommandHelp.usage("research")); core.menus.openTech(p); return; }
        String q = join(a, 0);
        String err = core.units.unlock(p, q);
        if (err != null) { p.sendMessage("[scarlet]" + err); return; }
        UnitNode n = core.units.find(q);
        p.sendMessage("[lime]Исследовано: [white]" + (n == null ? q : n.displayName()) + "[lime]. Играть: /play " + (n == null ? q : n.id));
    }

    /** /play <юнит> — играть выбранным открытым юнитом; без аргумента — снять выбор. */
    private void play(Player p, String[] a) {
        if (a.length == 0) {
            core.units.clearPreferred(p);
            p.sendMessage("[lime]Выбор снят: будет выдаваться лучший из открытых юнитов. [gray]Выбрать: /play <юнит>");
            return;
        }
        String err = core.units.play(p, join(a, 0));
        p.sendMessage(err != null ? "[scarlet]" + err : "[lime]Юнит выбран.");
    }

    void team(Player p, String[] a) {
        RwTeam t = core.teams.of(p);
        if (t == null) { p.sendMessage("[scarlet]Вы не в команде."); return; }
        StringBuilder sb = new StringBuilder("[accent]Команда: [white]" + t.name + " [accent]Игроков: [white]" + t.size() + " [accent]Счёт: [white]" + t.score + "\n");
        for (Player m : core.teams.players(t)) sb.append(m.plainName()).append(", ");
        p.sendMessage(sb.toString());
        RwTeam other = core.teams.other(t);
        if (a.length > 0 && a[0].equalsIgnoreCase("switch")) {
            if (core.teams.canSwitch(p, other)) {
                core.teams.set(p, other);
                core.units.release(p);
                core.units.autoGive(p);
            } else p.sendMessage("[scarlet]Смена команды сейчас недоступна.");
        }
    }
}
