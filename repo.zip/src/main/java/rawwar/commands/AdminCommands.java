package rawwar.commands;

import arc.util.Log;
import mindustry.gen.Groups;
import mindustry.gen.Player;
import rawwar.bank.BankManager;
import rawwar.core.CoreManager;
import rawwar.data.PlayerData;
import rawwar.modes.GameMode;
import rawwar.spawn.SpawnPoint;
import rawwar.teams.RwTeam;
import rawwar.units.UnitNode;

import java.util.List;
import java.util.function.Consumer;
import java.util.regex.Pattern;

/**
 * Административные команды. Один код для чата (/rw …) и консоли сервера (rw …):
 * p == null — консоль, вывод через Log.info.
 * Права проверяются в CommandManager (на сервере).
 */
public class AdminCommands {
    private final CoreManager core;
    AdminCommands(CoreManager core) { this.core = core; }

    private static String arg(String[] a, int i) { return CommandManager.arg(a, i); }

    /** Цвета Mindustry: в логе консоли теги не рисуются, убираем только их (не [режимы] и т.п.). */
    private static final Pattern COLOR_TAGS = Pattern.compile("\\[(?:white|black|lightgray|gray|grey|darkgray|red|green|blue|yellow|lime|orange|purple|cyan|teal|maroon|olive|sky|navy|cobalt|vermilion|tan|sepia|accent|stat|good|bad|health|minus|sub|inc|scarlet|gold|#(?i)[0-9a-f]{6})]");
    private static String plain(String s) { return COLOR_TAGS.matcher(s).replaceAll("").replace("/rw ", "rw "); }

    private Consumer<String> out(Player p) {
        return s -> { if (p != null) p.sendMessage(s); else Log.info("[RawWar] " + plain(s)); };
    }

    void run(Player p, String sub, String[] a) {
        Consumer<String> out = out(p);
        switch (sub) {
            case "admin":
                out.accept(CommandHelp.overview(core, p));
                break;
            case "reload":
                core.reload();
                out.accept("[lime]Конфигурация перезагружена (settings, units, spawns, режимы).");
                break;
            case "team":
                team(out, p, a);
                break;
            case "spawn":
                spawn(out, p, a);
                break;
            case "mapgen":
                mapgen(out, p, a);
                break;
            case "mode":
                mode(out, a);
                break;
            case "shopadd":
                units(out, prepend("add", a));
                break;
            case "shopremove":
                units(out, prepend("remove", a));
                break;
            case "shopset":
                units(out, prepend("set", a));
                break;
            case "bankadmin":
                bankAdmin(out, a);
                break;
            default:
        }
    }

    /** Консоль сервера: rw spawn | team | mode | reload … (полный доступ). */
    void runConsole(String sub, String[] a) {
        Consumer<String> out = out(null);
        switch (sub) {
            case "spawn": spawn(out, null, a); return;
            case "mapgen": mapgen(out, null, a); return;
            case "team":  team(out, null, a); return;
            case "mode":  mode(out, a); return;
            case "reload": core.reload(); out.accept("Конфигурация перезагружена."); return;
            case "units": units(out, a); return;
            case "bank":  bankAdmin(out, a); return;
            case "tech":  units(out, new String[]{"list"}); return;
            case "help":
                String key = String.join(" ", a);
                String d = key.isEmpty() ? null : CommandHelp.lookup(core, null, key);
                out.accept(d != null ? d : CommandHelp.overview(core, null));
                return;
            default: out.accept(CommandHelp.overview(core, null));
        }
    }

    private static String[] prepend(String first, String[] a) {
        String[] r = new String[a.length + 1];
        r[0] = first;
        System.arraycopy(a, 0, r, 1, a.length);
        return r;
    }

    /** /shopadd, /shopremove, /shopset (в консоли: rw units list|add|remove|set) — управление списком юнитов без правки файла. */
    private void units(Consumer<String> out, String[] a) {
        String op = arg(a, 0).toLowerCase();
        switch (op) {
            case "list": {
                for (UnitNode n : core.units.all())
                    out.accept(n.id + " -> " + n.unit + " [" + n.category + "] ранг " + n.rank + ", опыт " + n.xp + ", цена " + n.price
                            + (n.enabled ? "" : " [выключен]"));
                break;
            }
            case "add": {
                if (a.length < 2) { out.accept(CommandHelp.usage("shopadd")); return; }
                String unit = a[1];
                int rank, xp, price;
                try {
                    rank = a.length > 2 ? Integer.parseInt(a[2]) : 1;
                    xp = a.length > 3 ? Integer.parseInt(a[3]) : 0;
                    price = a.length > 4 ? Integer.parseInt(a[4]) : 0;
                } catch (NumberFormatException e) { out.accept("[scarlet]Ранг, опыт и цена — числа.\n" + CommandHelp.usage("shopadd")); return; }
                String name = a.length > 5 ? String.join(" ", java.util.Arrays.copyOfRange(a, 5, a.length)) : "";
                String id = unit.replaceAll("[^A-Za-z0-9_\\-]", "_");
                String err = core.units.addNode(id, unit, name, rank, xp, price);
                out.accept(err != null ? "[scarlet]" + err : "[lime]Добавлено: [white]" + id + "[lime] (ранг " + rank + ", опыт " + xp + ", цена " + price + ")");
                break;
            }
            case "remove": {
                if (a.length < 2) { out.accept(CommandHelp.usage("shopremove")); return; }
                String err = core.units.removeNode(a[1]);
                out.accept(err != null ? "[scarlet]" + err : "[orange]Удалено: [white]" + a[1]);
                break;
            }
            case "set": {
                if (a.length < 4) { out.accept(CommandHelp.usage("shopset")); return; }
                String value = String.join(" ", java.util.Arrays.copyOfRange(a, 3, a.length));
                String err = core.units.setField(a[1], a[2], value);
                out.accept(err != null ? "[scarlet]" + err : "[lime]" + a[1] + ": " + a[2] + " = " + value);
                break;
            }
            default:
                out.accept(CommandHelp.usage("shopadd") + "\n"
                        + CommandHelp.usage("shopremove") + "\n" + CommandHelp.usage("shopset"));
        }
    }

    /**
     * /bankadmin give|take|set|show <игрок> [сумма] (консоль: rw bank …).
     * give/take/set меняют баланс игрока; show — полная сводка. Игрок должен быть в сети.
     * Имя может содержать пробелы: сумма — последний аргумент.
     */
    private void bankAdmin(Consumer<String> out, String[] a) {
        String op = arg(a, 0).toLowerCase();
        boolean show = op.equals("show");
        if (!(op.equals("give") || op.equals("take") || op.equals("set") || show) || a.length < (show ? 2 : 3)) {
            out.accept(CommandHelp.usage("bankadmin"));
            return;
        }
        String name = String.join(" ", java.util.Arrays.copyOfRange(a, 1, show ? a.length : a.length - 1));
        Player t = core.bank.findPlayer(name);
        if (t == null) { out.accept("[scarlet]Игрок не найден или имя неоднозначно (он должен быть в сети): [white]" + name); return; }
        PlayerData d = core.data.get(t.uuid(), t.plainName());
        if (show) {
            out.accept("[accent]" + t.plainName() + ":\n" + core.bank.overview(t, d) + "\n[accent]Вклады:\n" + core.bank.depositsText(d));
            return;
        }
        String raw = a[a.length - 1];
        long v = raw.equals("0") && op.equals("set") ? 0 : BankManager.parseAmount(raw, -1);
        if (v < 0) { out.accept("[scarlet]Не понял сумму: [white]" + raw + "\n" + CommandHelp.usage("bankadmin")); return; }
        String err = core.bank.adminAdjust(t, op, v, "admin");
        out.accept(err != null ? "[scarlet]" + err : "[lime]" + t.plainName() + ": " + op + " " + BankManager.fmt(v) + " kys. Баланс: " + BankManager.money(d.balance));
    }

    private void team(Consumer<String> out, Player p, String[] a) {
        String op = arg(a, 0).toLowerCase();
        if (op.equals("balance")) {
            out.accept("[lime]Перенесено игроков: " + core.teams.balance());
        } else if (op.equals("set")) {
            Player target = findPlayer(arg(a, 1));
            RwTeam t = core.teams.byId(arg(a, 2));
            if (target == null || t == null) { out.accept(CommandHelp.usage("team set")); return; }
            core.teams.set(target, t);
            core.units.release(target);
            core.units.autoGive(target);
            out.accept("[lime]" + target.plainName() + " -> " + t.name);
        } else {
            out.accept(CommandHelp.usage("team set") + "\n" + CommandHelp.usage("team balance"));
        }
    }

    /**
     * Точки появления.
     *   /rw spawn                    — меню-редактор (в игре)
     *   /rw spawn add a              — точка команды A там, где вы стоите
     *   /rw spawn add b 120 45       — точка по координатам (работает и в консоли)
     *   /rw spawn edit a             — режим тапа: нажимайте на карту
     * Совместимость: team / set / here — синонимы add.
     */
    private void spawn(Consumer<String> out, Player p, String[] a) {
        String op = arg(a, 0).toLowerCase();

        switch (op) {
            case "":
            case "menu": {
                if (p == null) { out.accept(CommandHelp.detail(core, null, "spawn")); return; }
                core.menus.openSpawn(p);
                break;
            }

            case "add":
            case "team":
            case "set":
            case "here": {
                RwTeam t = core.teams.byId(arg(a, 1));
                if (t == null) { out.accept(CommandHelp.usage("spawn add")); return; }
                int sx, sy;
                if (a.length >= 4) {
                    sx = parse(arg(a, 2)); sy = parse(arg(a, 3));
                    if (sx < 0 || sy < 0) { out.accept(CommandHelp.usage("spawn add")); return; }
                } else if (p != null) {
                    sx = p.tileX(); sy = p.tileY();
                } else {
                    out.accept("[scarlet]В консоли нужны координаты.\n" + CommandHelp.usage("spawn add"));
                    return;
                }
                String err = core.spawns.addPoint(t.id, sx, sy);
                if (err != null) { out.accept("[scarlet]" + err); return; }
                out.accept("[lime]Точка #" + core.spawns.count(t.id) + " команды " + t.name + ": [white]" + sx + ", " + sy
                        + core.spawns.tileWarning(sx, sy));
                if (p != null) core.spawns.show(p, t.id);
                break;
            }

            case "edit": {
                if (p == null) { out.accept("[scarlet]Режим тапа доступен только в игре. В консоли: rw spawn add <a|b> <x> <y>"); return; }
                String v = arg(a, 1).toLowerCase();
                if (v.equals("off") || v.equals("stop") || v.equals("выкл")) {
                    core.spawns.setEdit(p, null);
                    out.accept("[accent]Режим тапа выключен.");
                    return;
                }
                RwTeam t = core.teams.byId(v);
                if (t == null) { out.accept(CommandHelp.usage("spawn edit")); return; }
                core.spawns.setEdit(p, t.id);
                core.spawns.show(p, t.id);
                out.accept("[lime]Режим тапа: команда " + t.name + ". [white]Нажмите на карту — точка добавится, "
                        + "нажмите рядом с точкой — удалится. Выключить: /rw spawn edit off");
                break;
            }

            case "show": {
                if (p == null) { out.accept("[scarlet]Подписи на карте видны только в игре. Список: rw spawn list"); return; }
                RwTeam f = a.length > 1 ? core.teams.byId(arg(a, 1)) : null;
                if (a.length > 1 && f == null) { out.accept(CommandHelp.usage("spawn show")); return; }
                core.spawns.show(p, f == null ? null : f.id);
                out.accept("[accent]Точки подписаны на карте на 15 секунд.");
                break;
            }

            case "list": {
                RwTeam f = a.length > 1 ? core.teams.byId(arg(a, 1)) : null;
                if (a.length > 1 && f == null) { out.accept(CommandHelp.usage("spawn list")); return; }
                StringBuilder sb = new StringBuilder();
                for (RwTeam t : new RwTeam[]{core.teams.alpha, core.teams.bravo}) {
                    if (f != null && f != t) continue;
                    List<SpawnPoint> l = core.spawns.list(t.id);
                    sb.append("[accent]").append(t.name).append(" (").append(l.size()).append("):\n")
                      .append(core.spawns.describe(t.id)).append("\n");
                }
                out.accept(sb.toString().trim());
                break;
            }

            case "remove": {
                RwTeam rt = core.teams.byId(arg(a, 1));
                if (rt == null) { out.accept(CommandHelp.usage("spawn remove")); return; }
                if (a.length > 2) {
                    int num = parse(arg(a, 2));
                    if (num < 1) { out.accept(CommandHelp.usage("spawn remove")); return; }
                    int n = core.spawns.removeAt(rt.id, num - 1);
                    out.accept(n > 0 ? "[lime]Точка #" + num + " удалена." : "[scarlet]Точки с таким номером нет. [gray]/rw spawn list " + rt.id);
                } else {
                    SpawnPoint sp = core.spawns.removeLast(rt.id);
                    out.accept(sp != null ? "[lime]Удалена последняя точка: " + sp.x + ", " + sp.y : "[scarlet]У команды нет точек.");
                }
                break;
            }

            case "clear": {
                RwTeam rt = core.teams.byId(arg(a, 1));
                if (rt == null) { out.accept(CommandHelp.usage("spawn clear")); return; }
                out.accept("[lime]Удалено точек: " + core.spawns.remove(rt.id));
                break;
            }

            default:
                out.accept("[scarlet]Неизвестная подкоманда: [white]" + op + "\n" + CommandHelp.detail(core, p, "spawn"));
        }
    }

    /**
     * Генератор карты.
     *   /mapgen                      — меню (в консоли: сводка)
     *   /mapgen show | keys          — раскладка / все настройки
     *   /mapgen set <ключ> <значение>
     *   /mapgen preset small|medium|large
     *   /mapgen reset
     *   /mapgen generate [зерно]
     */
    private void mapgen(Consumer<String> out, Player p, String[] a) {
        String op = arg(a, 0).toLowerCase();
        switch (op) {
            case "":
            case "menu":
                if (p != null) core.mapgenMenu.open(p);
                else out.accept(core.mapgen.summary() + "\n" + CommandHelp.detail(core, null, "mapgen"));
                break;
            case "show":
                out.accept(core.mapgen.summary());
                break;
            case "keys":
            case "list":
                out.accept(core.mapgen.keysText());
                break;
            case "set": {
                if (a.length < 3) { out.accept(CommandHelp.usage("mapgen set")); return; }
                String value = String.join(" ", java.util.Arrays.copyOfRange(a, 2, a.length));
                String err = core.mapgen.set(a[1], value);
                if (err != null) { out.accept("[scarlet]" + err); return; }
                out.accept("[lime]" + a[1] + " = " + value + "\n" + core.mapgen.summary());
                break;
            }
            case "preset": {
                if (!core.mapgen.preset(arg(a, 1))) { out.accept(CommandHelp.usage("mapgen preset")); return; }
                out.accept("[lime]Пресет применён.\n" + core.mapgen.summary());
                break;
            }
            case "reset":
                core.mapgen.reset();
                out.accept("[lime]Настройки генератора сброшены.\n" + core.mapgen.summary());
                break;
            case "generate":
            case "gen":
            case "go": {
                Long seed = null;
                if (a.length > 1) {
                    try { seed = Long.parseLong(a[1]); } catch (NumberFormatException e) { out.accept(CommandHelp.usage("mapgen generate")); return; }
                }
                String err = core.mapgen.generate(seed);
                out.accept(err != null ? "[scarlet]" + err : core.mapgen.lastInfo());
                break;
            }
            default:
                out.accept("[scarlet]Неизвестная подкоманда: [white]" + op + "\n" + CommandHelp.detail(core, p, "mapgen"));
        }
    }

    void mode(Consumer<String> out, String[] a) {
        switch (arg(a, 0).toLowerCase()) {
            case "list":
                for (GameMode m : core.modes.all().values()) out.accept((m == core.modes.active() ? "* " : "  ") + m.getId() + " — " + m.getName());
                break;
            case "select":
                out.accept(core.modes.select(arg(a, 1), true) ? "Режим выбран." : "Режим не найден. [gray]/mode list");
                break;
            case "start":
                out.accept(core.modes.start() ? "Запущено." : "Не удалось (режим не выбран или уже идёт матч).");
                break;
            case "stop":
                core.modes.stop();
                out.accept("Остановлено.");
                break;
            default:
                out.accept(CommandHelp.usage("mode"));
        }
    }

    static Player findPlayer(String name) {
        for (Player p : Groups.player) if (p.plainName().equalsIgnoreCase(name) || p.name.equalsIgnoreCase(name)) return p;
        return null;
    }

    private static int parse(String s) { try { return Integer.parseInt(s); } catch (Exception e) { return -1; } }
}
