package rawwar.config;

import java.util.ArrayList;
import java.util.Arrays;

/** Структура settings.json. */
public class Settings {
    public static class PluginCfg { public String name = "RawWar"; public String version = "1.0.0"; public boolean enabled = true; }
    public static class TeamsCfg {
        public boolean enabled = true;
        public int maxPlayersPerTeam = 20;
        public boolean autoBalance = true;
        public boolean allowTeamSwitch = false;
        public String alphaName = "Alpha", bravoName = "Bravo";
        public String alphaTeam = "sharded", bravoTeam = "crux";
    }
    public static class UnitsCfg {
        public boolean enabled = true;
        public int xpRankBase = 100;   // опыт за 1-й шаг ранга; ранг r+1 стоит base*r
        public int xpPerKill = 25;     // опыт за убийство игрока
        public int xpPerWin = 100;     // опыт за победу в матче
        public boolean statusMultipliers = false;
        /** true = игрок не может выйти из своего юнита (пересесть на другой юнит/турель, сброситься в ядро). */
        public boolean lockUnit = true;
        /** true = администраторы не ограничены запретом выхода из юнита. */
        public boolean lockExemptAdmins = false;
    }
    public static class SpawnCfg { public boolean enabled = true; public boolean randomSpawn = false; public int searchRadius = 6; }
    public static class BuildingCfg { public boolean enabled = false; }

    /** Тариф срочного вклада: срок в минутах, доход в процентах от суммы (выплачивается в конце срока). */
    public static class DepositPlan {
        public String id = "", name = "";
        public int minutes = 60;
        public float percent = 5f;
        public int minAmount = 100;
        public DepositPlan() {}
        public DepositPlan(String id, String name, int minutes, float percent, int minAmount) {
            this.id = id; this.name = name; this.minutes = minutes; this.percent = percent; this.minAmount = minAmount;
        }
    }

    /** Банк и валюта kys. */
    public static class BankCfg {
        public float kysPerXp = 1f;            // сколько kys приходит за 1 полученный опыт (убийства, волны, победы)
        public int startBonus = 0;             // разовая добавка на баланс при первой загрузке данных игрока
        public int maxDeposits = 5;            // сколько вкладов может быть открыто одновременно
        public int earlyClosePenaltyPercent = 10; // штраф при досрочном закрытии: процент от суммы вклада (доход не выплачивается)
        public int transferFeePercent = 0;     // комиссия перевода игроку (платит отправитель сверх суммы)
        public int minTransfer = 1;            // минимальная сумма перевода
        public ArrayList<DepositPlan> plans = new ArrayList<>(Arrays.asList(
                new DepositPlan("short", "Короткий", 30, 3f, 100),
                new DepositPlan("day", "Суточный", 720, 15f, 500),
                new DepositPlan("long", "Долгий", 4320, 50f, 1000)
        ));
    }

    public PluginCfg plugin = new PluginCfg();
    public TeamsCfg teams = new TeamsCfg();
    public UnitsCfg units = new UnitsCfg();
    public SpawnCfg spawn = new SpawnCfg();
    public BuildingCfg building = new BuildingCfg();
    public BankCfg bank = new BankCfg();

    /** UUID создателя плагина (даёт доступ к /rw owner ...). */
    public String ownerUuid = "";
    public String activeMode = "TeamDeathmatch";
    public boolean autoStartMode = false;
    /** true = при старте сервера сам сгенерирует карту и запустит режим bootstrapMode; после матча — новый раунд. */
    public boolean autoBootstrap = true;
    public String bootstrapMode = "UnitSurvival";
    /** Пауза между матчами (секунды) перед новой картой. */
    public int roundDelaySeconds = 15;
    public boolean removeCores = false;
    public int dataSaveIntervalSeconds = 120;
    public boolean debug = false;
    /** true = игра никогда не встаёт на паузу (в том числе при 1 игроке или пустом сервере). */
    public boolean disablePause = true;
}
