package rawwar.config;

import rawwar.core.CoreManager;
import rawwar.data.JsonIO;

/** Configuration System. */
public class ConfigManager {
    private final CoreManager core;
    public Settings settings = new Settings();

    public ConfigManager(CoreManager core) { this.core = core; }

    public void load() {
        arc.files.Fi f = core.root.child("config").child("settings.json");
        settings = JsonIO.read(f, Settings.class, Settings::new);
        // старый файл без раздела bank: дописываем его, чтобы настройки банка были видны и правились в файле
        try { if (f.exists() && !f.readString().contains("\"bank\"")) save(); } catch (Throwable ignored) {}
    }

    public void save() { JsonIO.write(core.root.child("config").child("settings.json"), settings); }
}
