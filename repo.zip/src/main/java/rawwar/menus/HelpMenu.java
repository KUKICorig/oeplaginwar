package rawwar.menus;

import mindustry.gen.Call;
import mindustry.gen.Player;
import mindustry.ui.Menus;
import rawwar.commands.CommandHelp;
import rawwar.commands.CommandHelp.Entry;
import rawwar.commands.CommandHelp.Section;
import rawwar.core.CoreManager;

import java.util.*;

/**
 * Меню справки (/help): разделы команд -> список команд раздела -> карточка команды (синтаксис, описание, пример, подкоманды).
 * Данные берутся из CommandHelp, поэтому новая команда появляется в меню сама. Администраторские разделы видят только администраторы.
 */
public class HelpMenu {
    private enum Stage { MAIN, SECTION, COMMAND }

    private static final int PAGE = 8;

    private static class State {
        Stage stage = Stage.MAIN;
        List<Runnable> actions = new ArrayList<>();
        int page;
        Section section;
        String key;
    }

    private final CoreManager core;
    private final Map<String, State> states = new HashMap<>();
    private int menuId = -1;

    public HelpMenu(CoreManager core) { this.core = core; }

    public void load() {
        if (menuId == -1) menuId = Menus.registerMenu(this::onChoice);
    }

    public void open(Player p) {
        State s = new State();
        states.put(p.uuid(), s);
        show(p, s);
    }

    /** Сразу раздел (например /help bank). */
    public void openSection(Player p, Section sec) {
        State s = new State();
        s.stage = Stage.SECTION;
        s.section = sec;
        states.put(p.uuid(), s);
        show(p, s);
    }

    public void close(Player p) {
        states.remove(p.uuid());
        if (menuId != -1 && p.con != null) Call.hideFollowUpMenu(p.con, menuId);
    }

    /** Закрыть без скрытия окна (при выходе игрока). */
    public void forget(Player p) { states.remove(p.uuid()); }

    private void onChoice(Player p, int option) {
        State s = states.get(p.uuid());
        if (s == null || option < 0 || option >= s.actions.size()) return; // окно закрыто игроком
        s.actions.get(option).run();
    }

    private void go(Player p, State s, Stage stage) {
        s.stage = stage;
        s.page = 0;
        show(p, s);
    }

    private void row(List<String[]> rows, State s, String label, Runnable action) {
        rows.add(new String[]{label});
        s.actions.add(action);
    }

    private void show(Player p, State s) {
        s.actions = new ArrayList<>();
        List<String[]> rows = new ArrayList<>();
        String title, text;

        // доступ мог измениться, пока меню было открыто
        List<Section> visible = CommandHelp.sections(core, p);
        if (s.section != null && !visible.contains(s.section)) { s.section = null; s.stage = Stage.MAIN; }

        switch (s.stage) {
            case SECTION: {
                final Section sec = s.section;
                List<Entry> cmds = CommandHelp.commands(sec);
                title = sec.title.toUpperCase();
                text = sec.color() + sec.desc + "\n[gray]Нажмите на команду: синтаксис, описание, пример.";
                int pages = Math.max(1, (cmds.size() + PAGE - 1) / PAGE);
                s.page = Math.max(0, Math.min(s.page, pages - 1));
                for (int i = s.page * PAGE; i < Math.min(cmds.size(), s.page * PAGE + PAGE); i++) {
                    final Entry e = cmds.get(i);
                    row(rows, s, "[accent]" + e.usage, () -> { s.key = e.key; go(p, s, Stage.COMMAND); });
                }
                if (pages > 1) {
                    final int page = s.page;
                    rows.add(new String[]{"<<", (page + 1) + "/" + pages, ">>"});
                    s.actions.add(() -> { s.page = (page + pages - 1) % pages; show(p, s); });
                    s.actions.add(() -> show(p, s));
                    s.actions.add(() -> { s.page = (page + 1) % pages; show(p, s); });
                }
                row(rows, s, "Назад", () -> go(p, s, Stage.MAIN));
                break;
            }
            case COMMAND: {
                String d = CommandHelp.detail(core, p, s.key);
                if (d == null) { go(p, s, Stage.SECTION); return; }
                title = "/" + s.key.split(" ")[0].toUpperCase();
                text = d;
                row(rows, s, "К разделу", () -> go(p, s, Stage.SECTION));
                row(rows, s, "К разделам", () -> go(p, s, Stage.MAIN));
                break;
            }
            default: {
                title = "СПРАВКА";
                text = "Выберите раздел команд.\n[gray]Полный список в чат: /help all   Подробно: /help <команда>";
                for (final Section sec : visible) {
                    row(rows, s, sec.color() + sec.title + " [gray](" + CommandHelp.commands(sec).size() + ")", () -> { s.section = sec; go(p, s, Stage.SECTION); });
                }
                row(rows, s, "Закрыть", () -> states.remove(p.uuid()));
                break;
            }
        }
        Call.menu(p.con, menuId, title, text, rows.toArray(new String[0][]));
    }
}
