package rawwar.menus;

import arc.func.Cons;
import mindustry.gen.Call;
import mindustry.gen.Player;
import mindustry.ui.Menus;
import rawwar.core.CoreManager;
import rawwar.data.PlayerData;
import rawwar.teams.RwTeam;
import rawwar.units.UnitCategory;
import rawwar.units.UnitManager;
import rawwar.units.UnitNode;

import java.util.*;

/**
 * Menu System: главное меню /rw.
 * Юниты: список (фильтр по типу) -> карточка юнита со статами и требованиями -> «Исследовать» / «Купить» (за kys) / «Играть этим».
 * Банк kys открывает BankMenu.
 * Для администраторов — редактор точек спавна.
 */
public class MenuManager {
    private enum Stage { MAIN, LIST, NODE, STATS, INFOTEXT, SPAWN_TEAMS, SPAWN_TEAM }

    private static final int PAGE = 8;

    private static class State {
        Stage stage = Stage.MAIN;
        List<Runnable> actions = new ArrayList<>();
        int page;
        String cat;          // фильтр списка по типу (null = все)
        String nodeId;
        String confirmBuyId; // юнит, для которого ждём подтверждения покупки
        String teamId;
        boolean confirmClear;
    }

    /** Пункты главного меню, добавленные режимами. */
    private static class Extra { String label; Cons<Player> action; }

    private final CoreManager core;
    private final Map<String, State> states = new HashMap<>();
    private final List<Extra> extras = new ArrayList<>();
    private int menuId = -1;

    public MenuManager(CoreManager core) { this.core = core; }

    public void load() {
        if (menuId == -1) menuId = Menus.registerMenu(this::onChoice);
    }

    /** Позволяет режимам добавлять собственные кнопки в главное меню. */
    public void addMainEntry(String label, Cons<Player> action) {
        Extra e = new Extra();
        e.label = label;
        e.action = action;
        extras.add(e);
    }

    public void clearExtras() { extras.clear(); }

    public void open(Player p) { openAt(p, Stage.MAIN); }

    /** Сразу список юнитов (/shop). */
    public void openTech(Player p) { openTech(p, null); }

    /** Список юнитов с фильтром по типу (cat == null — все). */
    public void openTech(Player p, String cat) {
        State s = new State();
        s.stage = Stage.LIST;
        s.cat = cat;
        states.put(p.uuid(), s);
        show(p, s);
    }

    /** Редактор точек спавна (только администраторы). */
    public void openSpawn(Player p) {
        if (!core.isAdmin(p)) { p.sendMessage("[scarlet]Нет доступа."); return; }
        openAt(p, Stage.SPAWN_TEAMS);
    }

    private void openAt(Player p, Stage stage) {
        State s = new State();
        s.stage = stage;
        states.put(p.uuid(), s);
        show(p, s);
    }

    public void close(Player p) {
        states.remove(p.uuid());
        if (menuId != -1 && p.con != null) Call.hideFollowUpMenu(p.con, menuId);
    }

    private void onChoice(Player p, int option) {
        State s = states.get(p.uuid());
        if (s == null || option < 0 || option >= s.actions.size()) { return; } // закрыто игроком
        s.actions.get(option).run();
    }

    private void go(Player p, State s, Stage stage) { s.stage = stage; show(p, s); }

    private void show(Player p, State s) {
        s.actions = new ArrayList<>();
        List<String[]> rows = new ArrayList<>();
        String title, text;

        if ((s.stage == Stage.SPAWN_TEAMS || s.stage == Stage.SPAWN_TEAM) && !core.isAdmin(p)) s.stage = Stage.MAIN;

        switch (s.stage) {
            case LIST: {
                core.units.refresh(p);
                PlayerData d = core.data.get(p.uuid(), p.plainName());
                List<String> cats = core.units.categories();
                if (s.cat != null && !cats.contains(s.cat)) s.cat = null;
                List<UnitNode> all = core.units.list(s.cat);
                int pages = Math.max(1, (all.size() + PAGE - 1) / PAGE);
                s.page = Math.max(0, Math.min(s.page, pages - 1));
                title = "ЮНИТЫ" + (s.cat == null ? "" : ": " + UnitCategory.title(s.cat).toUpperCase());
                text = core.units.headerText(p) + "\n[lime]открыт  [yellow]можно исследовать  [gray]закрыт\n"
                        + (all.isEmpty() ? "[scarlet]Список пуст: config/units.json или /shopadd"
                                         : "[gray]Нажмите на юнита: характеристики, требования, «Исследовать» и «Купить».");
                int from = s.page * PAGE, to = Math.min(all.size(), from + PAGE);
                for (int i = from; i < to; i++) {
                    final UnitNode n = all.get(i);
                    UnitManager.Status st = core.units.status(d, n);
                    String extra = "ранг " + n.rank;
                    if (st == UnitManager.Status.AVAILABLE) extra += ", [yellow]можно[gray]";
                    else if (st != UnitManager.Status.UNLOCKED && n.canBuy()) extra += ", " + n.price + " kys";
                    String label = UnitManager.color(st) + n.displayName() + " [gray](" + extra + ")"
                            + (n.id.equals(d.preferred) ? " [lime]*" : "");
                    row(rows, s, label, () -> { s.nodeId = n.id; s.confirmBuyId = null; go(p, s, Stage.NODE); });
                }
                if (pages > 1) {
                    final int page = s.page;
                    rows.add(new String[]{"<<", (page + 1) + "/" + pages, ">>"});
                    s.actions.add(() -> { s.page = (page + pages - 1) % pages; show(p, s); });
                    s.actions.add(() -> show(p, s));
                    s.actions.add(() -> { s.page = (page + 1) % pages; show(p, s); });
                }
                if (cats.size() > 1) {
                    row(rows, s, "Тип: [accent]" + (s.cat == null ? "все" : UnitCategory.title(s.cat)), () -> {
                        int idx = s.cat == null ? -1 : cats.indexOf(s.cat);
                        s.cat = idx + 1 >= cats.size() ? null : cats.get(idx + 1);
                        s.page = 0;
                        show(p, s);
                    });
                }
                row(rows, s, "Назад", () -> go(p, s, Stage.MAIN));
                break;
            }
            case NODE: {
                final UnitNode n = core.units.get(s.nodeId);
                if (n == null) { go(p, s, Stage.LIST); return; }
                PlayerData d = core.data.get(p.uuid(), p.plainName());
                UnitManager.Status st = core.units.status(d, n);
                title = n.displayName();
                text = core.units.nodeText(p, n);
                if (st == UnitManager.Status.AVAILABLE) {
                    row(rows, s, "[yellow]Исследовать (бесплатно)", () -> {
                        String err = core.units.unlock(p, n.id);
                        if (err != null) p.sendMessage("[scarlet]" + err);
                        show(p, s);
                    });
                }
                if (st != UnitManager.Status.UNLOCKED && st != UnitManager.Status.DISABLED && n.canBuy()) {
                    boolean afford = core.bank.balance(d) >= n.price;
                    boolean confirm = n.id.equals(s.confirmBuyId);
                    row(rows, s, confirm ? "[scarlet]Подтвердить: купить за " + n.price + " kys" : (afford ? "[lime]" : "[gray]") + "Купить за " + n.price + " kys", () -> {
                        if (!afford) { p.sendMessage("[scarlet]" + core.bank.notEnough(d, n.price)); }
                        else if (!confirm) { s.confirmBuyId = n.id; }
                        else {
                            s.confirmBuyId = null;
                            String err = core.units.buy(p, n.id);
                            if (err != null) p.sendMessage("[scarlet]" + err);
                        }
                        show(p, s);
                    });
                }
                if (st == UnitManager.Status.UNLOCKED) {
                    if (n.id.equals(d.preferred)) {
                        row(rows, s, "Снять выбор (авто: лучший юнит)", () -> { core.units.clearPreferred(p); show(p, s); });
                    } else {
                        row(rows, s, "[accent]Играть этим юнитом", () -> {
                            String err = core.units.play(p, n.id);
                            p.sendMessage(err != null ? "[scarlet]" + err : "[lime]Юнит: [white]" + n.displayName());
                            show(p, s);
                        });
                    }
                }
                final int idx = core.units.list(s.cat).indexOf(n);
                row(rows, s, "К списку", () -> { s.confirmBuyId = null; s.page = Math.max(0, idx) / PAGE; go(p, s, Stage.LIST); });
                break;
            }
            case STATS: {
                PlayerData d = core.data.get(p.uuid(), p.plainName());
                title = "СТАТИСТИКА";
                text = "Убийств: " + d.kills + "\nСмертей: " + d.deaths + "\nПобед: " + d.wins + "\nПоражений: " + d.losses
                        + "\nМатчей: " + d.matches + "\nОпыт: " + d.xp + "\nРанг: " + d.rank + "\nБаланс: " + core.bank.balance(d) + " kys";
                row(rows, s, "Назад", () -> go(p, s, Stage.MAIN));
                break;
            }
            case INFOTEXT: {
                title = "ИНФОРМАЦИЯ";
                text = core.modes.describe();
                row(rows, s, "Назад", () -> go(p, s, Stage.MAIN));
                break;
            }
            case SPAWN_TEAMS: {
                title = "ТОЧКИ СПАВНА";
                text = "Выберите команду. Точки задают, где появляются её игроки.\n"
                        + "[accent]" + core.teams.alpha.name + ": [white]" + core.spawns.count("alpha") + " точек\n"
                        + "[accent]" + core.teams.bravo.name + ": [white]" + core.spawns.count("bravo") + " точек\n"
                        + "[gray]Подсказки по командам: /help spawn";
                for (final RwTeam t : new RwTeam[]{core.teams.alpha, core.teams.bravo}) {
                    row(rows, s, t.name + " (" + core.spawns.count(t.id) + ")", () -> { s.teamId = t.id; s.confirmClear = false; go(p, s, Stage.SPAWN_TEAM); });
                }
                row(rows, s, "Закрыть", () -> states.remove(p.uuid()));
                break;
            }
            case SPAWN_TEAM: {
                final RwTeam t = core.teams.byId(s.teamId);
                if (t == null) { go(p, s, Stage.SPAWN_TEAMS); return; }
                title = "СПАВН: " + t.name;
                text = core.spawns.describe(t.id)
                        + "\n\n[gray]Вы стоите на: [white]" + p.tileX() + ", " + p.tileY();
                row(rows, s, "Добавить здесь (" + p.tileX() + ", " + p.tileY() + ")", () -> {
                    String err = core.spawns.addPoint(t.id, p.tileX(), p.tileY());
                    if (err != null) p.sendMessage("[scarlet]" + err);
                    else {
                        p.sendMessage("[lime]Точка #" + core.spawns.count(t.id) + ": [white]" + p.tileX() + ", " + p.tileY() + core.spawns.tileWarning(p.tileX(), p.tileY()));
                        core.spawns.show(p, t.id);
                    }
                    s.confirmClear = false;
                    show(p, s);
                });
                row(rows, s, "Режим тапа: нажимать на карту", () -> {
                    core.spawns.setEdit(p, t.id);
                    core.spawns.show(p, t.id);
                    states.remove(p.uuid());
                    p.sendMessage("[lime]Режим тапа: " + t.name + ". [white]Нажмите на карту — добавится точка, нажмите рядом с точкой — удалится. Выключить: /rw spawn edit off");
                });
                row(rows, s, "Показать точки на карте", () -> {
                    core.spawns.show(p, t.id);
                    p.sendMessage("[accent]Точки подписаны на карте на 15 секунд.");
                    show(p, s);
                });
                row(rows, s, "Удалить последнюю", () -> {
                    rawwar.spawn.SpawnPoint sp = core.spawns.removeLast(t.id);
                    p.sendMessage(sp != null ? "[orange]Удалена точка " + sp.x + ", " + sp.y : "[scarlet]У команды нет точек.");
                    s.confirmClear = false;
                    show(p, s);
                });
                row(rows, s, s.confirmClear ? "[scarlet]ДА, удалить все точки" : "Очистить все точки", () -> {
                    if (s.confirmClear) {
                        p.sendMessage("[orange]Удалено точек: " + core.spawns.remove(t.id));
                        s.confirmClear = false;
                    } else s.confirmClear = true;
                    show(p, s);
                });
                row(rows, s, "Назад", () -> { s.confirmClear = false; go(p, s, Stage.SPAWN_TEAMS); });
                break;
            }
            default: {
                title = "RAW WAR";
                text = "Юнит выдаётся автоматически (лучший открытый) или тот, которого вы выбрали.\n" + core.units.statusText(p)
                        + "\n[gray]Все команды: /help";
                row(rows, s, "Юниты: исследование и покупка", () -> { s.cat = null; s.page = 0; go(p, s, Stage.LIST); });
                row(rows, s, "Банк kys", () -> { states.remove(p.uuid()); core.bankMenu.open(p); });
                row(rows, s, "Справка по командам", () -> { states.remove(p.uuid()); core.helpMenu.open(p); });
                row(rows, s, "Информация", () -> go(p, s, Stage.INFOTEXT));
                row(rows, s, "Статистика", () -> go(p, s, Stage.STATS));
                if (core.isAdmin(p)) row(rows, s, "Точки спавна", () -> go(p, s, Stage.SPAWN_TEAMS));
                for (Extra e : extras) row(rows, s, e.label, () -> { states.remove(p.uuid()); e.action.get(p); });
                break;
            }
        }
        Call.menu(p.con, menuId, title, text, rows.toArray(new String[0][]));
    }

    private void row(List<String[]> rows, State s, String label, Runnable action) {
        rows.add(new String[]{label});
        s.actions.add(action);
    }
}
