package rawwar.units;

import mindustry.gen.Unit;
import mindustry.type.UnitType;

import java.util.*;

/**
 * Типы (категории) юнитов: у каждого типа свой отдельный список исследований.
 * Категория узла задаётся в units.json полем "category". Если поле пустое — тип определяется автоматически
 * по классу юнита Mindustry (см. {@link #detect}).
 */
public final class UnitCategory {
    public static final String AIR = "air", LEGS = "legs", MECH = "mech", TANK = "tank", HOVER = "hover", OTHER = "other";

    /** Порядок вывода в меню. Неизвестные категории из файла выводятся после этих. */
    public static final List<String> KNOWN = Collections.unmodifiableList(Arrays.asList(AIR, LEGS, MECH, TANK, HOVER));

    private UnitCategory() {}

    public static String normalize(String c) {
        return c == null ? "" : c.trim().toLowerCase(Locale.ROOT);
    }

    public static String title(String c) {
        switch (c) {
            case AIR: return "Воздушные";
            case LEGS: return "Шагоходы (legs)";
            case MECH: return "Мехи (mech)";
            case TANK: return "Танки (tank)";
            case HOVER: return "Ховеры (hover)";
            case OTHER: return "Прочие";
            default: return c;
        }
    }

    /** Определение типа по юниту Mindustry. Никогда не бросает исключений. */
    public static String detect(UnitType t) {
        try {
            if (t.flying) return AIR;
            Unit probe = t.constructor.get();
            String cls = probe.getClass().getSimpleName().toLowerCase(Locale.ROOT);
            if (cls.contains("legs")) return LEGS;
            if (cls.contains("tank")) return TANK;
            if (cls.contains("mech")) return MECH;
            if (cls.contains("elevation") || cls.contains("hover")) return HOVER;
        } catch (Throwable ignored) {}
        return OTHER;
    }
}
