package rawwar.units;

import arc.files.Fi;
import arc.util.Log;
import mindustry.Vars;
import mindustry.content.StatusEffects;
import mindustry.gen.Call;
import mindustry.gen.Groups;
import mindustry.gen.Player;
import mindustry.gen.Unit;
import mindustry.type.UnitType;
import rawwar.core.CoreManager;
import rawwar.data.JsonIO;
import rawwar.data.PlayerData;
import rawwar.teams.RwTeam;

import java.util.*;

/**
 * Unit System: список юнитов (config/units.json), ранги по опыту, исследование и покупка, выдача юнита.
 *
 * Исследовать (бесплатно): ранг игрока >= rank и суммарный опыт >= xp (опыт не тратится).
 * Купить: заплатить price kys с баланса (см. BankManager), ранг и опыт не нужны.
 * Юниты с xp = 0 выдаются сразу.
 */
public class UnitManager {

    /** Формат config/units.json. */
    public static class TreeFile {
        public String help = "Список юнитов. Запись: id, unit (internal-имя юнита Mindustry, можно из модов), name, "
                + "rank и xp (требования для ИСКЛЮЧИТЕЛЬНО исследования; xp 0 = выдаётся сразу, xp -1 = только купить), "
                + "price (цена покупки в kys, 0 = купить нельзя), category (пусто = авто). "
                + "Добавить юнита можно командой /shopadd. После правки файла: /rw reload.";
        public ArrayList<UnitNode> nodes = new ArrayList<>();
    }

    /** Состояние юнита для конкретного игрока. */
    public enum Status { UNLOCKED, AVAILABLE, NEED_RANK, NEED_XP, BUY_ONLY, DISABLED }

    private final CoreManager core;
    private TreeFile tree = new TreeFile();
    /** id -> запись (в порядке файла). */
    private final Map<String, UnitNode> nodes = new LinkedHashMap<>();
    /** Записи, отсортированные для списка: по рангу, затем по опыту/цене. */
    private final List<UnitNode> sorted = new ArrayList<>();
    /** uuid -> id выбранного юнита */
    private final Map<String, String> selected = new HashMap<>();
    /** uuid -> id сущности юнита, выданного плагином */
    private final Map<String, Integer> activeUnit = new HashMap<>();
    private final Set<Integer> ignoredDeaths = new HashSet<>();

    public UnitManager(CoreManager core) { this.core = core; }

    private Fi file() { return core.root.child("config").child("units.json"); }

    // ---------- загрузка ----------
    public void load() {
        nodes.clear();
        Fi f = file();
        boolean oldFormat = false;
        try { oldFormat = f.exists() && !f.readString().contains("\"price\""); } catch (Throwable ignored) {}
        tree = JsonIO.read(f, TreeFile.class, UnitManager::defaultTree);

        for (UnitNode n : tree.nodes) {
            if (n.id == null || n.id.isEmpty()) { Log.warn("[RawWar] units.json: запись без id пропущена"); continue; }
            if (nodes.containsKey(n.id)) { Log.warn("[RawWar] units.json: дубликат id '" + n.id + "' пропущен"); continue; }
            if (Vars.content.unit(n.unit) == null) { Log.warn("[RawWar] units.json: неизвестный юнит '" + n.unit + "' (запись " + n.id + ") — пропущена"); continue; }
            if (n.rank < 1) n.rank = 1;
            if (n.xp < -1) n.xp = -1;
            if (n.price < 0) n.price = 0;
            nodes.put(n.id, n);
        }

        if (oldFormat) {
            // файл от дерева исследований: цена покупки = 2 x требуемый опыт, родители (parent) отбрасываются
            for (UnitNode n : tree.nodes) if (n.xp > 0 && n.price == 0) n.price = n.xp * 2;
            try { f.copyTo(f.sibling("units.json.before-list.bak")); } catch (Throwable ignored) {}
            JsonIO.write(f, tree);
            Log.info("[RawWar] units.json: дерево преобразовано в список (добавлено поле price), копия: units.json.before-list.bak");
        }

        for (UnitNode n : nodes.values()) {
            String c = UnitCategory.normalize(n.category);
            n.category = c.isEmpty() ? UnitCategory.detect(Vars.content.unit(n.unit)) : c; // только в памяти
        }
        rebuild();
        Log.info("[RawWar] Список юнитов загружен: " + nodes.size() + " " + categories());
    }

    private void rebuild() {
        sorted.clear();
        sorted.addAll(nodes.values());
        // стабильная сортировка: ранг, затем «стоимость» (опыт; для «только купить» — цена)
        sorted.sort(Comparator.<UnitNode>comparingInt(n -> n.rank).thenComparingInt(n -> n.xp >= 0 ? n.xp : n.price));
    }

    private void save() { JsonIO.write(file(), tree); }

    /** Дефолтный список. */
    private static TreeFile defaultTree() {
        TreeFile t = new TreeFile();
        // воздух
        t.nodes.add(node("mega", "mega", "Мега", 1, 0, 0, "Стартовый воздушный юнит-строитель.", true));
        t.nodes.add(node("flare", "flare", "Флэр", 2, 100, 200, "Быстрый истребитель.", false));
        t.nodes.add(node("horizon", "horizon", "Хорайзон", 3, 300, 600, "Бомбардировщик.", false));
        t.nodes.add(node("zenith", "zenith", "Зенит", 4, 600, 1200, "Ракетный штурмовик.", false));
        // mech
        t.nodes.add(node("dagger", "dagger", "Даггер", 1, 0, 0, "Базовый наземный боец.", false));
        t.nodes.add(node("mace", "mace", "Мейс", 2, 100, 200, "Огнемётный штурмовик.", false));
        t.nodes.add(node("fortress", "fortress", "Фортресс", 3, 300, 600, "Артиллерийский мех.", false));
        t.nodes.add(node("scepter", "scepter", "Скептр", 4, 600, 1200, "Тяжёлый штурмовой мех.", false));
        t.nodes.add(node("reign", "reign", "Рейн", 5, 1000, 2000, "Сверхтяжёлый мех.", false));
        t.nodes.add(node("atrax", "atrax", "Атракс", 1, 0, 0, "Шагоход, плюёт кислотой.", false));
        t.nodes.add(node("stell", "stell", "Стелл", 1, 0, 0, "Лёгкий танк.", false));
        t.nodes.add(node("elude", "elude", "Элюд", 1, 0, 0, "Ховер.", false));
        t.nodes.add(node("nova", "nova", "Нова", 1, 0, 0, "Мех поддержки, умеет строить.", true));
        t.nodes.add(node("pulsar", "pulsar", "Пульсар", 2, 100, 200, "Дуговой боец с ремонтом.", true));
        t.nodes.add(node("quasar", "quasar", "Квазар", 3, 300, 600, "Бронированная поддержка.", true));
        // legs
        t.nodes.add(node("spiroct", "spiroct", "Спирокт", 2, 100, 200, "Высасывает здоровье лучами.", false));
        t.nodes.add(node("arkyid", "arkyid", "Аркид", 3, 300, 600, "Тяжёлый шагоход.", false));
        t.nodes.add(node("toxopid", "toxopid", "Токсопид", 4, 600, 1200, "Огромный шагоход.", false));
        // tank
        t.nodes.add(node("locus", "locus", "Локус", 2, 100, 200, "Танк с лазером.", false));
        t.nodes.add(node("precept", "precept", "Прецепт", 3, 300, 600, "Тяжёлый танк.", false));
        t.nodes.add(node("vanquish", "vanquish", "Ванквиш", 4, 600, 1200, "Артиллерийский танк.", false));
        t.nodes.add(node("conquer", "conquer", "Конкер", 5, 1000, 2000, "Сверхтяжёлый танк.", false));
        // hover
        return t;
    }

    private static UnitNode node(String id, String unit, String name, int rank, int xp, int price, String desc, boolean builder) {
        UnitNode n = new UnitNode();
        n.id = id; n.unit = unit; n.name = name; n.rank = rank; n.xp = xp; n.price = price; n.description = desc; n.canBuild = builder;
        return n;
    }

    // ---------- запросы ----------
    public Collection<UnitNode> all() { return sorted; }

    public UnitNode get(String id) {
        if (id == null) return null;
        UnitNode n = nodes.get(id);
        if (n != null) return n;
        for (UnitNode x : nodes.values()) if (x.id.equalsIgnoreCase(id)) return x;
        return null;
    }

    /**
     * Поиск юнита по тому, что ввёл игрок: id, internal-имя, название (без учёта регистра),
     * затем однозначное начало или вхождение. null — не найден или неоднозначно.
     */
    public UnitNode find(String query) {
        if (query == null) return null;
        String q = query.trim().toLowerCase(Locale.ROOT);
        if (q.isEmpty()) return null;
        for (UnitNode n : nodes.values()) if (n.id.toLowerCase(Locale.ROOT).equals(q)) return n;
        for (UnitNode n : nodes.values()) if (n.unit.toLowerCase(Locale.ROOT).equals(q) || n.displayName().toLowerCase(Locale.ROOT).equals(q)) return n;
        UnitNode hit = null; int cnt = 0;
        for (UnitNode n : nodes.values()) {
            if (n.id.toLowerCase(Locale.ROOT).startsWith(q) || n.displayName().toLowerCase(Locale.ROOT).startsWith(q)) { hit = n; cnt++; }
        }
        if (cnt == 1) return hit;
        if (cnt > 1) return null;
        for (UnitNode n : nodes.values()) {
            if (n.id.toLowerCase(Locale.ROOT).contains(q) || n.displayName().toLowerCase(Locale.ROOT).contains(q)) { hit = n; cnt++; }
        }
        return cnt == 1 ? hit : null;
    }

    /** Сообщение «не найден» с похожими вариантами. */
    public String notFound(String query) {
        String q = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
        List<String> similar = new ArrayList<>();
        for (UnitNode n : nodes.values()) {
            if (!n.enabled || q.isEmpty()) continue;
            if (n.id.toLowerCase(Locale.ROOT).contains(q) || n.displayName().toLowerCase(Locale.ROOT).contains(q)) similar.add(n.id);
            if (similar.size() >= 5) break;
        }
        return "Юнит '" + query + "' не найден или название неоднозначно."
                + (similar.isEmpty() ? " Список: /shop list" : " Похожие: " + String.join(", ", similar));
    }

    /** Типы, у которых есть хотя бы одна запись, в порядке вывода. */
    public List<String> categories() {
        Set<String> present = new LinkedHashSet<>();
        for (UnitNode n : nodes.values()) present.add(n.category);
        List<String> out = new ArrayList<>();
        for (String k : UnitCategory.KNOWN) if (present.contains(k)) out.add(k);
        List<String> rest = new ArrayList<>();
        for (String k : present) if (!UnitCategory.KNOWN.contains(k)) rest.add(k);
        Collections.sort(rest);
        out.addAll(rest);
        return out;
    }

    /** Разбор ввода игрока: id типа (mech) или начало русского названия. null — не найдено. */
    public String parseCategory(String input) {
        String in = UnitCategory.normalize(input);
        if (in.isEmpty()) return null;
        List<String> cats = categories();
        for (String k : cats) if (k.equals(in)) return k;
        for (String k : cats) if (UnitCategory.title(k).toLowerCase(Locale.ROOT).startsWith(in)) return k;
        return null;
    }

    /** Список для меню: отсортирован по рангу; category == null — все типы. Выключенные не показываются. */
    public List<UnitNode> list(String category) {
        List<UnitNode> l = new ArrayList<>();
        for (UnitNode n : sorted) {
            if (!n.enabled) continue;
            if (category != null && !category.equals(n.category)) continue;
            l.add(n);
        }
        return l;
    }

    public int usedGlobal(String nodeId) {
        int n = 0;
        for (String id : selected.values()) if (id.equals(nodeId)) n++;
        return n;
    }

    public int usedInTeam(String nodeId, RwTeam t) {
        int n = 0;
        for (Map.Entry<String, String> e : selected.entrySet())
            if (e.getValue().equals(nodeId) && t.members.contains(e.getKey())) n++;
        return n;
    }

    /** Свободные места (-1 = без ограничений). */
    public int freeSlots(UnitNode c, RwTeam t) {
        int free = Integer.MAX_VALUE;
        if (c.maxPlayers > 0) free = Math.min(free, c.maxPlayers - usedGlobal(c.id));
        if (c.teamLimit > 0 && t != null) free = Math.min(free, c.teamLimit - usedInTeam(c.id, t));
        return free == Integer.MAX_VALUE ? -1 : Math.max(0, free);
    }

    public String selectedId(Player p) { return selected.get(p.uuid()); }

    // ---------- статус ----------
    public Status status(PlayerData d, UnitNode n) {
        if (!n.enabled) return Status.DISABLED;
        if (d.unlocked.contains(n.id)) return Status.UNLOCKED;
        if (!n.canResearch()) return Status.BUY_ONLY;
        if (d.rank < n.rank) return Status.NEED_RANK;
        if (d.xp < n.xp) return Status.NEED_XP;
        return Status.AVAILABLE;
    }

    public Status statusOf(Player p, UnitNode n) {
        return status(core.data.get(p.uuid(), p.plainName()), n);
    }

    /** Цвет-тег Mindustry для статуса. */
    public static String color(Status s) {
        switch (s) {
            case UNLOCKED: return "[lime]";
            case AVAILABLE: return "[yellow]";
            case DISABLED: return "[scarlet]";
            default: return "[gray]";
        }
    }

    // ---------- ранги ----------
    /** Ранг по опыту: ранг r+1 стоит xpRankBase * r (суммарно base*r*(r+1)/2). */
    public int rankOf(int xp) {
        int base = Math.max(10, core.config.settings.units.xpRankBase);
        int rank = 1;
        while (xp >= (long) base * rank * (rank + 1) / 2) rank++;
        return rank;
    }

    /** Сколько опыта суммарно нужно для ранга r. */
    public long xpForRank(int rank) {
        int base = Math.max(10, core.config.settings.units.xpRankBase);
        return (long) base * (rank - 1) * rank / 2;
    }

    /** Пересчёт ранга по опыту и автоматическая выдача юнитов без требований (xp = 0). */
    public void refresh(Player p) {
        PlayerData d = core.data.get(p.uuid(), p.plainName());
        int newRank = rankOf(d.xp);
        if (newRank > d.rank) {
            d.rank = newRank;
            core.data.markDirty(p.uuid());
            int fresh = 0;
            for (UnitNode n : nodes.values()) if (status(d, n) == Status.AVAILABLE && n.xp > 0) fresh++;
            p.sendMessage("[accent]Ранг повышен: [white]" + d.rank
                    + (fresh > 0 ? "[accent]. Можно исследовать юнитов: [white]" + fresh + "[accent] — /shop" : "[accent]. Юниты: /shop"));
        }
        for (UnitNode n : nodes.values()) {
            if (n.enabled && n.xp == 0 && d.rank >= n.rank && !d.unlocked.contains(n.id)) {
                d.unlocked.add(n.id);
                core.data.markDirty(p.uuid());
            }
        }
    }

    /** Юнит для выдачи: выбранный игроком («Играть этим»), иначе самый старший из доступных. */
    public UnitNode best(Player p) {
        PlayerData d = core.data.get(p.uuid(), p.plainName());
        if (d.preferred != null && !d.preferred.isEmpty()) {
            UnitNode pr = nodes.get(d.preferred);
            if (pr != null && usable(p, d, pr)) return pr;
        }
        UnitNode best = null; int bi = -1, i = 0;
        for (UnitNode n : nodes.values()) {
            i++;
            if (!usable(p, d, n)) continue;
            int cost = n.xp >= 0 ? n.xp : n.price;
            int bestCost = best == null ? 0 : (best.xp >= 0 ? best.xp : best.price);
            if (best == null || n.rank > best.rank || (n.rank == best.rank && (cost > bestCost || (cost == bestCost && i > bi)))) {
                best = n; bi = i;
            }
        }
        return best;
    }

    private boolean usable(Player p, PlayerData d, UnitNode n) {
        if (!n.enabled || !d.unlocked.contains(n.id)) return false;
        if (freeSlots(n, core.teams.of(p)) == 0) return false;
        return core.modes.active() == null || core.modes.allowUnit(p, n);
    }

    /** Автоматическая выдача юнита (вход, респавн, старт матча). */
    public void autoGive(Player p) {
        if (!core.config.settings.units.enabled) return;
        if (p.con == null || !p.con.isConnected()) return;
        if (activeUnit.get(p.uuid()) != null) return; // уже стоит живой юнит
        refresh(p);
        UnitNode n = best(p);
        if (n == null) { p.sendMessage("[scarlet]Нет доступного юнита: исследуйте или купите (/shop) либо настройте config/units.json."); return; }
        String err = give(p, n);
        if (err != null) p.sendMessage("[scarlet]" + err);
        else p.sendMessage("[lime]Юнит: [white]" + n.displayName() + " [accent](ранг " + n.rank + ")");
    }

    /** «Играть этим»: запоминает юнита как предпочитаемого и сразу пересаживает игрока. null = успех. */
    public String play(Player p, String id) {
        UnitNode n = find(id);
        if (n == null) return notFound(id);
        PlayerData d = core.data.get(p.uuid(), p.plainName());
        refresh(p);
        if (!d.unlocked.contains(n.id)) return "Этот юнит ещё не открыт — /research " + n.id + " или /buy " + n.id + ".";
        d.preferred = n.id;
        core.data.markDirty(p.uuid());
        if (n.id.equals(selected.get(p.uuid()))) return null;
        return give(p, n);
    }

    /** Снимает выбор юнита: дальше выдаётся лучший из доступных. */
    public void clearPreferred(Player p) {
        PlayerData d = core.data.get(p.uuid(), p.plainName());
        d.preferred = "";
        core.data.markDirty(p.uuid());
    }

    /** Исследование (бесплатно, по рангу и опыту). Возвращает null при успехе или текст причины отказа. */
    public String unlock(Player p, String id) {
        UnitNode n = find(id);
        if (n == null) return notFound(id);
        PlayerData d = core.data.get(p.uuid(), p.plainName());
        refresh(p);
        switch (status(d, n)) {
            case DISABLED: return "Юнит отключён.";
            case UNLOCKED: return "Уже открыт.";
            case BUY_ONLY: return "Этого юнита нельзя исследовать — только купить" + (n.canBuy() ? " (" + n.price + " kys)." : ", но покупка тоже отключена.");
            case NEED_RANK: return "Нужен ранг " + n.rank + " (у вас " + d.rank + ").";
            case NEED_XP: return "Нужно опыта: " + n.xp + " (у вас " + d.xp + ").";
            default:
        }
        grant(p, d, n, "исследовал");
        return null;
    }

    /** Покупка за kys с баланса (ранг и опыт не нужны). Возвращает null при успехе или текст причины отказа. */
    public String buy(Player p, String id) {
        UnitNode n = find(id);
        if (n == null) return notFound(id);
        PlayerData d = core.data.get(p.uuid(), p.plainName());
        refresh(p);
        if (!n.enabled) return "Юнит отключён.";
        if (d.unlocked.contains(n.id)) return "Уже открыт.";
        if (!n.canBuy()) return "Этого юнита нельзя купить.";
        String err = core.bank.spend(p, n.price, "юнит " + n.displayName());
        if (err != null) return err;
        grant(p, d, n, "купил");
        return null;
    }

    private void grant(Player p, PlayerData d, UnitNode n, String verb) {
        d.unlocked.add(n.id);
        core.data.markDirty(p.uuid());
        Call.sendMessage("[accent][RawWar] [white]" + p.plainName() + "[accent] " + verb + " юнита: [white]" + n.displayName());
        // если игрок сейчас без юнита — сразу высадка
        if (activeUnit.get(p.uuid()) == null) autoGive(p);
    }

    // ---------- управление списком (админ) ----------
    /** Добавляет юнита в список (в том числе из мода). null = успех. */
    public String addNode(String id, String unit, String name, int rank, int xp, int price) {
        UnitType t = Vars.content.unit(unit);
        if (t == null) return "Юнит '" + unit + "' не найден в игре (проверьте internal-имя, для мода — с префиксом мода).";
        if (id == null || id.isEmpty()) id = unit;
        if (get(id) != null) return "Запись '" + id + "' уже есть.";
        UnitNode n = new UnitNode();
        n.id = id; n.unit = unit; n.name = name == null ? "" : name;
        n.rank = Math.max(1, rank); n.xp = Math.max(-1, xp); n.price = Math.max(0, price);
        n.category = UnitCategory.detect(t);
        tree.nodes.add(n);
        nodes.put(n.id, n);
        rebuild();
        save();
        return null;
    }

    public String removeNode(String id) {
        UnitNode n = get(id);
        if (n == null) return "Запись '" + id + "' не найдена.";
        tree.nodes.remove(n);
        nodes.remove(n.id);
        rebuild();
        save();
        return null;
    }

    /** Меняет поле записи: name, desc, rank, xp, price, enabled, category, limit, teamlimit. null = успех. */
    public String setField(String id, String field, String value) {
        UnitNode n = get(id);
        if (n == null) return "Запись '" + id + "' не найдена.";
        try {
            switch (field.toLowerCase(Locale.ROOT)) {
                case "name": n.name = value; break;
                case "desc": case "description": n.description = value; break;
                case "rank": n.rank = Math.max(1, Integer.parseInt(value)); break;
                case "xp": n.xp = Math.max(-1, Integer.parseInt(value)); break;
                case "price": n.price = Math.max(0, Integer.parseInt(value)); break;
                case "enabled": n.enabled = Boolean.parseBoolean(value) || value.equals("1") || value.equalsIgnoreCase("on"); break;
                case "category": n.category = UnitCategory.normalize(value).isEmpty() ? UnitCategory.detect(Vars.content.unit(n.unit)) : UnitCategory.normalize(value); break;
                case "limit": n.maxPlayers = Math.max(0, Integer.parseInt(value)); break;
                case "teamlimit": n.teamLimit = Math.max(0, Integer.parseInt(value)); break;
                default: return "Поля: name, desc, rank, xp, price, enabled, category, limit, teamlimit.";
            }
        } catch (NumberFormatException e) {
            return "Нужно число: " + value;
        }
        rebuild();
        save();
        return null;
    }

    // ---------- тексты ----------
    public String statusText(Player p) {
        PlayerData d = core.data.get(p.uuid(), p.plainName());
        refresh(p);
        UnitNode cur = get(selected.get(p.uuid()));
        return "[accent]Ранг: [white]" + d.rank + "[accent]  Опыт: [white]" + d.xp + "/" + xpForRank(d.rank + 1)
                + "\n" + core.bank.shortBalance(d) + "\n"
                + "[accent]Текущий юнит: [white]" + (cur == null ? "нет" : cur.displayName() + " (" + cur.unit + ")")
                + "\n[accent]Магазин: [white]/shop";
    }

    /** Шапка меню/чата: ранг, опыт и баланс kys. */
    public String headerText(Player p) {
        PlayerData d = core.data.get(p.uuid(), p.plainName());
        return "[accent]Ранг: [white]" + d.rank + "[accent]  Опыт: [white]" + d.xp
                + "[accent] (след. ранг: [white]" + xpForRank(d.rank + 1) + "[accent])\n" + core.bank.shortBalance(d);
    }

    /** Короткая причина, почему юнит пока закрыт (\"\" если открыт или доступен). */
    public String lockReason(PlayerData d, UnitNode n) {
        switch (status(d, n)) {
            case NEED_RANK: return "нужен ранг " + n.rank;
            case NEED_XP: return "нужно " + n.xp + " опыта";
            case BUY_ONLY: return "только покупка";
            case DISABLED: return "отключён";
            default: return "";
        }
    }

    /** Список юнитов текстом для чата (/shop list [тип]). */
    public String listText(Player p, String category) {
        PlayerData d = core.data.get(p.uuid(), p.plainName());
        refresh(p);
        StringBuilder sb = new StringBuilder("[accent]Юниты").append(category == null ? "" : ": " + UnitCategory.title(category))
                .append("\n").append(headerText(p)).append("\n");
        for (UnitNode n : list(category)) {
            Status s = status(d, n);
            sb.append(color(s)).append(n.id).append(" [gray](").append(UnitCategory.title(n.category)).append(", ранг ").append(n.rank).append(", ")
              .append(n.xp >= 0 ? n.xp + " оп." : "без исследования").append(n.canBuy() ? ", " + n.price + " kys" : "").append(")");
            if (s == Status.UNLOCKED) sb.append(" [lime]открыт");
            else if (s == Status.AVAILABLE) sb.append(" [yellow]можно исследовать");
            sb.append("\n");
        }
        sb.append("[gray]/research <id>   /buy <id>   /play <id>   карточка: /shop <id>");
        return sb.toString();
    }

    /** Карточка юнита: характеристики, требования, статус. */
    public String nodeText(Player p, UnitNode n) {
        PlayerData d = core.data.get(p.uuid(), p.plainName());
        Status s = status(d, n);
        StringBuilder sb = new StringBuilder();
        sb.append(color(s)).append(n.displayName()).append(" [gray](").append(n.unit).append(")\n");
        if (n.description != null && !n.description.isEmpty()) sb.append("[white]").append(n.description).append("\n");
        UnitType t = Vars.content.unit(n.unit);
        if (t != null) {
            sb.append("\n[accent]Тип: [white]").append(UnitCategory.title(n.category)).append("\n")
              .append("[accent]Здоровье: [white]").append(Math.round(t.health * n.healthMultiplier))
              .append("  [accent]Броня: [white]").append(Math.round(t.armor)).append("\n")
              .append("[accent]Скорость: [white]").append(String.format(Locale.ROOT, "%.1f", t.speed * 60f / 8f * n.speedMultiplier)).append(" т/с")
              .append("  [accent]Дальность: [white]").append(String.format(Locale.ROOT, "%.1f", t.maxRange / 8f)).append(" т\n")
              .append("[accent]Оружий: [white]").append(t.weapons.size)
              .append("  [accent]Строит: [white]").append(t.buildSpeed > 0f ? "да" : "нет")
              .append("  [accent]Летает: [white]").append(t.flying ? "да" : "нет").append("\n");
        }
        sb.append("\n[accent]Исследовать (бесплатно):\n");
        if (!n.canResearch()) {
            sb.append("[gray]- недоступно, юнита можно только купить\n");
        } else {
            sb.append(d.rank >= n.rank ? "[lime]+ " : "[scarlet]- ").append("[white]ранг ").append(n.rank).append(" [gray](у вас ").append(d.rank).append(")\n");
            sb.append(d.xp >= n.xp ? "[lime]+ " : "[scarlet]- ").append("[white]опыт ").append(n.xp).append(" [gray](у вас ").append(d.xp).append(", не тратится)\n");
        }
        sb.append("[accent]Купить:\n");
        if (!n.canBuy()) sb.append("[gray]- недоступно\n");
        else sb.append(d.balance >= n.price ? "[lime]+ " : "[scarlet]- ").append("[white]").append(n.price).append(" kys [gray](на балансе ").append(d.balance).append(")\n");
        sb.append("\n");
        switch (s) {
            case UNLOCKED: sb.append("[lime]Открыт"); break;
            case AVAILABLE: sb.append("[yellow]Можно исследовать бесплатно"); break;
            case DISABLED: sb.append("[scarlet]Отключён администратором"); break;
            default: sb.append("[scarlet]Закрыт: ").append(lockReason(d, n));
        }
        if (n.maxPlayers > 0 || n.teamLimit > 0)
            sb.append("\n[gray]Лимит: ").append(n.maxPlayers > 0 ? n.maxPlayers + " на сервер " : "").append(n.teamLimit > 0 ? n.teamLimit + " на команду" : "");
        return sb.toString();
    }

    // ---------- выдача ----------
    /** Пытается выдать юнит. Возвращает null при успехе или текст причины отказа. */
    public String give(Player p, UnitNode c) {
        if (!c.enabled) return "Юнит отключён.";
        RwTeam t = core.teams.of(p);
        if (t == null) return "Вы не состоите в команде.";
        String current = selected.get(p.uuid());
        if (c.id.equals(current)) return "Этот юнит уже выбран.";
        if (freeSlots(c, t) == 0) return "Свободных мест нет.";
        if (core.modes.active() != null && !core.modes.allowUnit(p, c)) return "Режим не разрешает этот юнит.";

        UnitType type = Vars.content.unit(c.unit);
        if (type == null) return "Неизвестный тип юнита.";

        Unit old = p.unit();
        boolean oldOwn = old != null && isOwnUnit(p, old); // юнит, выданный плагином (смена типа/юнита)

        Unit u = type.create(t.team);
        if (!core.spawns.placeAt(p, u, t))
            return "У команды " + t.name + " нет точки появления. " + (core.isAdmin(p)
                    ? "Добавьте: /rw spawn add " + t.id + " (встаньте на место) или /rw spawn."
                    : "Сообщите администратору.");
        release(p);
        u.maxHealth = type.health * c.healthMultiplier;
        u.health = u.maxHealth;
        u.add();
        p.unit(u);
        applyMultipliers(u, c);

        if (old != null && !old.dead() && old != u && (old.spawnedByCore || oldOwn)) {
            ignoredDeaths.add(old.id);
            old.kill();
        }

        selected.put(p.uuid(), c.id);
        activeUnit.put(p.uuid(), u.id);
        PlayerData d = core.data.get(p.uuid(), p.plainName());
        d.unitId = c.id;
        core.data.markDirty(p.uuid());
        return null;
    }

    private void applyMultipliers(Unit u, UnitNode c) {
        if (!core.config.settings.units.statusMultipliers) return;
        // Скорость/урон: постоянный множитель в Mindustry задаётся только статус-эффектом.
        // Реализовано через готовые эффекты как грубое приближение (см. README).
        if (c.speedMultiplier > 1.05f || c.damageMultiplier > 1.05f) u.apply(StatusEffects.overdrive, 60f * 60f * 24f);
    }

    /** Освобождает слот игрока (смена юнита, выход, смерть). */
    public void release(Player p) {
        selected.remove(p.uuid());
        activeUnit.remove(p.uuid());
    }

    public boolean isOwnUnit(Player p, Unit u) {
        Integer id = activeUnit.get(p.uuid());
        return id != null && id == u.id;
    }

    /** true, если смерть юнита вызвана самим плагином (замена юнита) и должна игнорироваться. */
    public boolean consumeIgnored(Unit u) { return ignoredDeaths.remove(u.id); }

    public void clearAll() { selected.clear(); activeUnit.clear(); }

    // ---------- запрет выхода из юнита ----------
    /** Живой юнит, выданный плагином игроку (null — нет такого). */
    public Unit ownUnit(Player p) {
        Integer id = activeUnit.get(p.uuid());
        if (id == null) return null;
        Unit u = Groups.unit.getByID(id);
        return u != null && u.isAdded() && !u.dead() ? u : null;
    }

    /** Применяется ли к игроку запрет выхода из юнита (включён в настройках и игрок не освобождён). */
    public boolean lockApplies(Player p) {
        if (p == null || !core.config.settings.units.enabled || !core.config.settings.units.lockUnit) return false;
        return !(core.config.settings.units.lockExemptAdmins && core.isAdmin(p));
    }

    /** true, если игрок сейчас «заперт» в своём живом юните: любые попытки сменить юнит надо отклонять. */
    public boolean isLocked(Player p) {
        return lockApplies(p) && ownUnit(p) != null;
    }

    private final Map<String, Long> lockHintAt = new HashMap<>();

    /** Подсказка игроку, не чаще раза в 3 секунды. */
    public void lockHint(Player p) {
        long now = System.currentTimeMillis();
        Long last = lockHintAt.get(p.uuid());
        if (last != null && now - last < 3000) return;
        lockHintAt.put(p.uuid(), now);
        p.sendMessage("[scarlet]Выйти из юнита нельзя. [gray]Сменить юнита: /play <юнит>");
    }

    public void forgetLock(Player p) { lockHintAt.remove(p.uuid()); }

    /**
     * Серверная проверка (раз в 0,25 с): если игрок оказался не в своём юните (сел в турель, чужой юнит,
     * нажал «в ядро») — возвращает его обратно. Если выданный юнит исчез без события смерти
     * (перезагрузка карты) — освобождает слот и выдаёт юнит заново.
     */
    public void enforceLock() {
        for (Player p : Groups.player) {
            try {
                if (p.con == null || !lockApplies(p)) continue;
                Integer id = activeUnit.get(p.uuid());
                if (id == null) continue;
                Unit own = Groups.unit.getByID(id);
                if (own == null || !own.isAdded()) {
                    release(p);
                    final Player pl = p;
                    arc.util.Timer.schedule(() -> autoGive(pl), 1f);
                    continue;
                }
                if (own.dead()) continue; // смерть обработает GameEventListener
                if (p.unit() != own) {
                    Unit cur = p.unit();
                    p.unit(own);
                    // юнит, который игрок успел занять (например, свой «ядерный» или чужой) — не трогаем,
                    // но если это был выданный ядром юнит игрока, он больше не нужен
                    if (cur != null && cur != own && cur.spawnedByCore && !cur.dead() && cur.getPlayer() == null) {
                        ignoredDeaths.add(cur.id);
                        cur.kill();
                    }
                    lockHint(p);
                }
            } catch (Throwable t) {
                Log.err("[RawWar] enforceLock: " + t);
            }
        }
    }
}
