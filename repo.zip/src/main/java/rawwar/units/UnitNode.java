package rawwar.units;

/**
 * Запись списка юнитов (config/units.json). Дерева нет — это обычный список.
 *
 * id       — уникальное имя записи (на него ссылаются команды): "dagger", "my_boss";
 * unit     — internal-имя юнита Mindustry, в том числе из модов ("dagger", "fortress", "my-mod-unit");
 * name     — название в меню (пусто = id);
 * category — тип: air, legs, mech, tank, hover (пусто = определяется автоматически);
 * rank     — минимальный ранг игрока для ИССЛЕДОВАНИЯ;
 * xp       — сколько ВСЕГО опыта нужно для ИССЛЕДОВАНИЯ (опыт не тратится). 0 = юнит выдаётся сразу
 *            (при нужном ранге), -1 = исследовать нельзя, только купить;
 * price    — цена ПОКУПКИ в kys (списываются с баланса). Покупка не требует ранга и опыта. 0 = купить нельзя.
 */
public class UnitNode {
    public String id = "";
    public String unit = "";
    public String name = "";
    public String description = "";
    public String category = "";
    public int rank = 1;
    public int xp = 0;
    public int price = 0;
    public boolean enabled = true;
    public boolean canBuild = false;
    public float healthMultiplier = 1f, damageMultiplier = 1f, speedMultiplier = 1f;
    public int maxPlayers = 0;  // 0 = без ограничения
    public int teamLimit = 0;   // 0 = без ограничения

    public String displayName() { return name == null || name.isEmpty() ? id : name; }

    public boolean isBuilder() { return canBuild; }

    public boolean canResearch() { return xp >= 0; }
    public boolean canBuy() { return price > 0; }
}
