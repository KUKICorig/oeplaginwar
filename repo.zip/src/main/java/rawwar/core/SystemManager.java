package rawwar.core;

import arc.util.Log;

import java.util.ArrayList;
import java.util.List;

/** Жизненный цикл подсистем: запуск по порядку, остановка в обратном. */
public class SystemManager {
    public interface Sys { String name(); void start() throws Exception; void stop(); }

    private final List<Sys> systems = new ArrayList<>();

    public void add(String name, ThrowingRunnable start, Runnable stop) {
        systems.add(new Sys() {
            public String name() { return name; }
            public void start() throws Exception { start.run(); }
            public void stop() { if (stop != null) stop.run(); }
        });
    }

    public interface ThrowingRunnable { void run() throws Exception; }

    public void startAll() {
        for (Sys s : systems) {
            try { s.start(); Log.info("[RawWar] + " + s.name()); }
            catch (Throwable t) { Log.err("[RawWar] Ошибка запуска " + s.name() + ": " + t); }
        }
    }

    public void stopAll() {
        for (int i = systems.size() - 1; i >= 0; i--) {
            try { systems.get(i).stop(); } catch (Throwable t) { Log.err("[RawWar] Ошибка остановки " + systems.get(i).name() + ": " + t); }
        }
    }
}
