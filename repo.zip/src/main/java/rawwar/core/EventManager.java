package rawwar.core;

import arc.Events;
import arc.func.Cons;

import java.util.ArrayList;
import java.util.List;

/** Регистрация обработчиков событий Mindustry с возможностью полной отмены (reload/stop). */
public class EventManager {
    private static class Sub { Class<?> type; Cons<?> cons; }
    private final List<Sub> subs = new ArrayList<>();

    public <T> void on(Class<T> type, Cons<T> cons) {
        Events.on(type, cons);
        Sub s = new Sub();
        s.type = type;
        s.cons = cons;
        subs.add(s);
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public void clear() {
        for (Sub s : subs) Events.remove((Class) s.type, (Cons) s.cons);
        subs.clear();
    }
}
