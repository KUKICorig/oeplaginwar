package rawwar.core;

import arc.files.Fi;
import arc.util.Log;
import mindustry.Vars;
import rawwar.bank.BankManager;
import rawwar.bank.BankMenu;
import rawwar.commands.CommandManager;
import rawwar.config.ConfigManager;
import rawwar.data.DataManager;
import rawwar.events.GameEventListener;
import rawwar.mapgen.MapGenManager;
import rawwar.mapgen.MapGenMenu;
import rawwar.menus.HelpMenu;
import rawwar.menus.MenuManager;
import rawwar.modes.ModeManager;
import rawwar.spawn.SpawnManager;
import rawwar.teams.TeamManager;
import rawwar.units.UnitManager;

/** Core System: создаёт подсистемы и управляет их жизненным циклом. */
public class CoreManager {
    public Fi root;
    public final SystemManager systems = new SystemManager();
    public final EventManager events = new EventManager();

    public ConfigManager config;
    public DataManager data;
    public BankManager bank;
    public BankMenu bankMenu;
    public TeamManager teams;
    public UnitManager units;
    public SpawnManager spawns;
    public MapGenManager mapgen;
    public MapGenMenu mapgenMenu;
    public MenuManager menus;
    public HelpMenu helpMenu;
    public ModeManager modes;
    public CommandManager commands;
    public GameEventListener listener;

    public void start() {
        root = Vars.dataDirectory.child("rawwar");
        root.mkdirs();
        for (String d : new String[]{"config", "players", "modes", "statistics", "logs", "backups"}) root.child(d).mkdirs();

        config = new ConfigManager(this);
        bank = new BankManager(this);
        bankMenu = new BankMenu(this);
        data = new DataManager(this);
        teams = new TeamManager(this);
        units = new UnitManager(this);
        spawns = new SpawnManager(this);
        mapgen = new MapGenManager(this);
        mapgenMenu = new MapGenMenu(this);
        menus = new MenuManager(this);
        helpMenu = new HelpMenu(this);
        modes = new ModeManager(this);
        commands = new CommandManager(this);
        listener = new GameEventListener(this);

        systems.add("Configuration", config::load, null);
        systems.add("Data", data::load, data::stop);
        systems.add("Bank", bank::load, bank::stop);
        systems.add("BankMenu", bankMenu::load, null);
        systems.add("Teams", teams::load, null);
        systems.add("Units", units::load, units::clearAll);
        systems.add("Spawns", spawns::load, null);
        systems.add("MapGen", mapgen::load, null);
        systems.add("MapGenMenu", mapgenMenu::load, null);
        systems.add("Menus", menus::load, null);
        systems.add("HelpMenu", helpMenu::load, null);
        systems.add("Modes", modes::load, modes::stopAll);
        systems.add("Events", listener::register, () -> { listener.stop(); events.clear(); });
        systems.startAll();

        if (!config.settings.plugin.enabled) { Log.warn("[RawWar] Плагин выключен в settings.json"); events.clear(); return; }
        Log.info("[RawWar] Запущен. Версия " + config.settings.plugin.version);
    }

    /** Перезагрузка конфигураций, юнитов, точек и режимов без перезапуска сервера. */
    public void reload() {
        data.saveAll();
        data.backup();
        config.load();
        data.load();
        teams.load();
        units.load();
        spawns.load();
        mapgen.load();
        modes.load();
        listener.applyRules();
        Log.info("[RawWar] Конфигурация перезагружена");
    }

    private boolean bootstrapped;

    /** Первый запуск: выбрать режим, сгенерировать карту с ядром и стартовать матч (один раз за запуск сервера). */
    public void bootstrap() {
        if (bootstrapped) return;
        bootstrapped = true;
        if (!config.settings.plugin.enabled || !config.settings.autoBootstrap) return;
        if (!modes.select(config.settings.bootstrapMode, false)) {
            Log.warn("[RawWar] bootstrap: режим '" + config.settings.bootstrapMode + "' не найден");
            return;
        }
        newRound(0.1f);
    }

    /** Новый раунд: через delay секунд перегенерировать карту и запустить активный режим. */
    public void newRound(float delaySeconds) {
        if (delaySeconds > 1f) mindustry.gen.Call.sendMessage("[accent][RawWar] Новая карта через " + (int) delaySeconds + " с...");
        arc.util.Timer.schedule(() -> {
            try {
                String err = mapgen.generate(null);
                if (err != null) { Log.err("[RawWar] новый раунд: " + err); return; }
                arc.util.Timer.schedule(() -> { if (!modes.running() && modes.active() != null) modes.start(); }, 4f);
            } catch (Throwable t) {
                Log.err("[RawWar] новый раунд не удался", t);
            }
        }, delaySeconds);
    }

    public boolean bootstrapDone() { return bootstrapped; }

    public void stop() { systems.stopAll(); }

    // ---------- права ----------
    public boolean isOwner(mindustry.gen.Player p) {
        String o = config.settings.ownerUuid;
        return o != null && !o.isEmpty() && o.equals(p.uuid());
    }

    public boolean isAdmin(mindustry.gen.Player p) {
        return p.admin || isOwner(p) || data.server.admins.contains(p.uuid());
    }
}
